# DocumentFragment

The DocumentFragment interface represents a minimal document object that has no parent. It is used as a light-weight version of Document to store well-formed or potentially non-well-formed fragments of XML.

Various other methods can take a document fragment as an argument (e.g., any Node interface methods such as Node.appendChild and Node.insertBefore), in which case the children of the fragment are appended or inserted, not the fragment itself.

This interface is also of great use with Web components:  `<template>`  elements contains a DocumentFragment in their HTMLTemplateElement.content property.

An empty DocumentFragment can be created using the document.createDocumentFragment method or the constructor.

## Properties
This interface has no specific property, but inherits those of its parent, Node, and implements those of the ParentNode interface.

- ** `ParentNode.children`  Read only**

 Returns a live HTMLCollection containing all objects of type Element that are children of the DocumentFragment object.

- ** `ParentNode.firstElementChild`  Read only**

 Returns the Element that is the first child of the DocumentFragment object, or null if there is none.

- ** `ParentNode.lastElementChild`  Read only**

 Returns the Element that is the last child of the DocumentFragment object, or null if there is none.

- ** `ParentNode.childElementCount`  Read only**

 Returns an unsigned long giving the amount of children that the DocumentFragment has.


## Constructor
- **DocumentFragment() **

 Returns an empty DocumentFragment object.


## Methods
This interface inherits the methods of its parent, Node, and implements those of the ParentNode interface.

- **DocumentFragment.find() **

 Returns the first matching Element in the tree of the DocumentFragment.

- **DocumentFragment.findAll() **

 Returns a NodeList of matching Element in the tree of the DocumentFragment.

- **DocumentFragment.querySelector()**

 Returns the first Element node within the DocumentFragment, in document order, that matches the specified selectors.

- **DocumentFragment.querySelectorAll()**

 Returns a NodeList of all the Element nodes within the DocumentFragment that match the specified selectors.

- **DocumentFragment.getElementById()**

 Returns the first Element node within the DocumentFragment, in document order, that matches the specified ID.