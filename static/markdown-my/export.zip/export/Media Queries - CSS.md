# Media Queries - CSS
<table responsive="true">
<tbody><tr><th>Topic</th><th>Description</th></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771844(v=vs.85).aspx">aspect-ratio media feature</a>
</p>
</td><td data-th="Description">
<p>Defined as the ratio of value of the <a href="https://msdn.microsoft.com/en-us/library/hh772741(v=vs.85).aspx">width</a> media feature to the value of the <a href="https://msdn.microsoft.com/en-us/library/hh772070(v=vs.85).aspx">height</a> media feature.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771855(v=vs.85).aspx">color media feature</a>
</p>
</td><td data-th="Description">
<p>Describes the number of bits per color component of the output device.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771852(v=vs.85).aspx">color-index media feature</a>
</p>
</td><td data-th="Description">
<p>Describes the number of entries in the color lookup table of the output device.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772062(v=vs.85).aspx">device-aspect-ratio media feature</a>
</p>
</td><td data-th="Description">
<p>Defined as the ratio of value of the <a href="https://msdn.microsoft.com/en-us/library/hh772064(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">device-width</strong></a> media feature to the value of the <a href="https://msdn.microsoft.com/en-us/library/hh772063(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">device-height</strong></a> media feature.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772063(v=vs.85).aspx">device-height media feature</a>
</p>
</td><td data-th="Description">
<p>Describes the height of the rendering surface of the output device.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772064(v=vs.85).aspx">device-width media feature</a>
</p>
</td><td data-th="Description">
<p>Describes the width of the rendering surface of the output device.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772070(v=vs.85).aspx">height media feature</a>
</p>
</td><td data-th="Description">
<p>Describes the height of the targeted display area of the output device.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dn806241(v=vs.85).aspx">hover media feature</a>
</p>
</td><td data-th="Description">
<p>Describes the ability of a user to hover over elements on a page.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772375(v=vs.85).aspx">monochrome media feature</a>
</p>
</td><td data-th="Description">
<p>Describes the number of bits per pixel in a monochrome frame buffer.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771830(v=vs.85).aspx">-ms-high-contrast media feature</a>
</p>
</td><td data-th="Description">
<p>Describes whether the application is being displayed in high contrast mode, and with what color variation.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771842(v=vs.85).aspx">-ms-view-state media feature</a>
</p>
</td><td data-th="Description">
<p>This feature is deprecated as of Internet Explorer&nbsp;11 and Windows&nbsp;8.1 and should no longer be used. Use <a href="https://msdn.microsoft.com/en-us/library/ms530811(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">max-width</strong></a> and <a href="https://msdn.microsoft.com/en-us/library/ms530820(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">min-width</strong></a> instead.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772710(v=vs.85).aspx">orientation media feature</a>
</p>
</td><td data-th="Description">
<p>Describes whether the orientation of the targeted display area of the output device is portrait or landscape.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dn806274(v=vs.85).aspx">pointer media feature</a>
</p>
</td><td data-th="Description">
<p>Describes the existence and accuracy of a pointing device like a stylus or a mouse.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772722(v=vs.85).aspx">resolution media feature</a>
</p>
</td><td data-th="Description">
<p>Describes the resolution of the output device—that is, the density of the pixels.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dn760733(v=vs.85).aspx">-webkit-device-pixel-ratio</a>
</p>
</td><td data-th="Description">
<p>Describes the resolution in physical pixels per CSS pixel.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772741(v=vs.85).aspx">width media feature</a>
</p>
</td><td data-th="Description">
<p>Describes the width of the targeted display area of the output device.</p>
</td></tr>
</tbody></table>