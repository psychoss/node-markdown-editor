# Which database should I use for a killer web application: MongoDB, PostgreSQL, or MySQL?

I'm working on killer web application, and I am really interested and worked with MongoDB. Is it a choice to choose MongoDB as a premier database? Or Is it better to use MySQL (with MongoDB/Redis as secondary)?

Between PostgreSQL and MySQL, there is generally no good reason to use MySQL over PostgreSQL, so let's get that off the list.

SQLite3 is fantastic if you want an embedded database in a situation where you are resource constrained or need a seamless installation experience for the user. SQLite is the standard database in mobile apps on both Android and iOS (going all the way back to the original iPod) and is even embedded in some web browsers as WebSQL (though it's deprecated as the Chrome people wanted the standard to be based on the SQLite implementation, while the Mozilla people thought this was a ridiculous way to define standards).

Since you mentioned web apps, you should not be using SQLite. It requires blocking access to the database file for every write, and since it runs inside your app's process, that means you can only have one process running with database write access (although multiple threads are fine). Python has a Global Interpreter Lock, which means it can effectively use only one core in a multi-core CPU unless you run multiple processes, which you can't because SQLite doesn't support that. So: don't use SQLite if you are building web apps in Python.

Which leaves us PostgreSQL and MongoDB.

PostgreSQL, like all SQL databases (including SQLite), is a relational database. It specialises in tracking the relationships between pieces of data and helping you retrieve something if you know something related to it.

For example, if you have two database tables, say, “Users” for all users and “Posts” for all posts made by a given user, with “Posts.user_id” being a foreign key reference to “User. id”, you have a schema where one Post has only one User, and by corollary, one User can have many Posts (since Users itself defines no relationship with Posts, the relationship is from the other direction). SQL makes it really easy to work with such relationships. You can say “given a user, get me all posts that refer to this user”, or “given this post, get me the referred user”.

All SQL databases can do relational queries like this, but PostgreSQL is really, really good at this. There is however an advanced use case that PostgreSQL isn't that good for: graphs. We'll get to that in a minute.

The Users and Posts relationship above is an example of a “one-to-many” relationship (or “many-to-one” depending on which side you are looking from). There is something else called a “many-to-many” relationship which is basically a “many-to-one + one-to-many” combo. In our hypothetical Users and Posts example, if we wanted to make it possible for a Post to have more than one User, we’d do it like this: “Users <- Users_Posts -> Posts” where this new “Users_Posts” table has exactly two columns, one a foreign key reference to a row in Users, another a foreign key reference to a row in Posts. For every unique combination of User and Post, you can add another row in the Users_Posts table linking that user and post.

Here's a very common situation in which you need such a model: mapping Movies and their Actors. You have a table each for movies and actors, and a “many-to-many” join table linking them both.

Let's say you want to know which movies actors A and B both appeared in. That's easy: “SELECT * FROM Movies WHERE id IN (SELECT movies_id FROM Movies_Actors WHERE actors_id IN (A, B))”.

See what we did? This is a nested query. Starting from the inner, we first asked for all movie_ids in the join table that feature actors A or B, then we asked for all details from the Movies table where the movie's id is in the previous query's results.

Now what if you have a situation where A and B have never appeared in a movie together, but you want to know if they have common co-actors? This is like LinkedIn or Facebook, where you are looking at the profile of someone you are not friends with, but LinkedIn or Facebook is telling you that you have common friends. This is a graph search pattern and is the subject of an entirely different type of database called, appropriately enough, a graph database. Look up Neo4j for an example. Although graph data can be modelled using a relational database like PostgreSQL, you're better off using something specialised like Neo4j.

And finally, MongoDB. What's it for? MongoDB is not a graph database, or even a relational database. Like CouchDB, it's a document database and it represents the other end of the scale. What if you want to store all details of a movie in one place and you aren't interested in being able to cross-reference the data? The relational databases want you to “normalise” your data by storing every little detail in a separate table, but you find that annoying. You just want to store your data in one place without having to think it through too much. You're still figuring out what data you want to store, so for now you just want to dump it somewhere and worry about querying it later. That's exactly what document databases are for and MongoDB is king of that hill.

PostgreSQL introduced a JSON data type in version 9.2 and a more efficient JSONB type in 9.4 (the current release) so if you have a mix of relational and document data (which is very likely), you may want to stick with PostgreSQL itself (see What's new in PostgreSQL 9.4).

Hope that helps.