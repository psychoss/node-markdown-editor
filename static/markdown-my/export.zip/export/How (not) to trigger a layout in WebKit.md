# How (not) to trigger a layout in WebKit
As most web developers are aware, a significant amount of a script's running time may be spent performing DOM operations triggered by the script rather than executing the JS byte code itself. One such potentially costly operation is layout (aka reflow) -- the process of constructing a render tree from a DOM tree. The larger and more complex the DOM, the more expensive this operation may be.

An important technique for keeping a page snappy is to batch methods that manipulate the DOM separately from those that query the state. For example:

```
// Suboptimal, causes layout twice.
var newWidth = aDiv.offsetWidth + 10; // Read
aDiv.style.width = newWidth + 'px'; // Write
var newHeight = aDiv.offsetHeight + 10; // Read
aDiv.style.height = newHeight + 'px'; // Write

// Better, only one layout.
var newWidth = aDiv.offsetWidth + 10; // Read
var newHeight = aDiv.offsetHeight + 10; // Read
aDiv.style.width = newWidth + 'px'; // Write
aDiv.style.height = newHeight + 'px'; // Write
```

Stoyan Stefanov's [tome on repaint, relayout and restyle](http://www.phpied.com/rendering-repaint-reflowrelayout-restyle/) provides an excellent explanation of the topic.

This often leaves developers asking the question: What triggers layout? Last week Dimitri Glazkov answered this question with [this codesearch link](http://google.com/codesearch?hl=en&vert=chromium&lr=&q=%22-%3EupdateLayoutIgnorePendingStylesheets%28%29%22&sbtn=Search). Trying to understand it better myself, I went through and translated it into a list of properties and methods. Here they are:

## Element

    clientHeight, clientLeft, clientTop, clientWidth, focus(), getBoundingClientRect(), getClientRects(), innerText, offsetHeight, offsetLeft, offsetParent, offsetTop, offsetWidth, outerText, scrollByLines(), scrollByPages(), scrollHeight, scrollIntoView(), scrollIntoViewIfNeeded(), scrollLeft, scrollTop, scrollWidth
## Frame, Image

    height, width

## Range
    getBoundingClientRect(), getClientRects()

## SVGLocatable
    computeCTM(), getBBox()
## SVGTextContent
    getCharNumAtPosition(), getComputedTextLength(), getEndPositionOfChar(), getExtentOfChar(), getNumberOfChars(), getRotationOfChar(), getStartPositionOfChar(), getSubStringLength(), selectSubString()
## SVGUse
    instanceRoot
## window
    getComputedStyle(), scrollBy(), scrollTo(), scrollX, scrollY, webkitConvertPointFromNodeToPage(), webkitConvertPointFromPageToNode()
    
This list is almost certainly not complete, but it is a good start. The best way to check for over-layout is to watch for the purple layout bars in the [Timeline panel](http://www.webkit.org/blog/1091/more-web-inspector-updates/#timeline_panel) of Chrome or Safari's Inspector.