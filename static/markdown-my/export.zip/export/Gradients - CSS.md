# Gradients - CSS

<table responsive="true">
<tbody><tr><th>Function</th><th>Description</th></tr>
<tr><td data-th="Function">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj152126(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">linear-gradient</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a linear gradient, in which colors transition smoothly along a line, by specifying a gradient line and two or more stop colors and offsets.</p>
</td></tr>
<tr><td data-th="Function">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj152127(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">radial-gradient</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a radial gradient, in which colors transition smoothly from a single point, and then spread outward in a circle or ellipse. A radial gradient is specified by first defining a center point, then the size and shape (if an ellipse) of the final—or 100%—circle or ellipse, and then the color stops in between, separated by commas.</p>
</td></tr>
<tr><td data-th="Function">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj152128(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">repeating-linear-gradient</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a repeating linear gradient, in which colors transition smoothly from a starting point to one or more color stops, and then repeat indefinitely.</p>
</td></tr>
<tr><td data-th="Function">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj152129(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">repeating-radial-gradient</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a radial gradient, in which colors transition smoothly from a single point, and then spread outward in a circle or ellipse, repeating infinitely.</p>
</td></tr>
</tbody></table>