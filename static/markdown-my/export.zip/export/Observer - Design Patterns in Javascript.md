# Observer - Design Patterns in Javascript


```
var CurrentConditionsDisplay = function(oSubject){
	Observer.apply(this);
	Display.apply(this);
	this.nTemperature = 0;
	this.nHumidity = 0;
	this.nPressure = 0;
	this.oSubject = oSubject;
	oSubject.registerObserver(this);
	this.update = function(nTemperature, nHumidity, nPressure){
		this.nTemperature = nTemperature;
		this.nHumidity = nHumidity;
		this.nPressure = nPressure;
		this.display();
	};
	this.display = function(){
		console.log("Current conditions: " + this.nTemperature + "F degrees and " + this.nHumidity + "% humidity.");
	};
};
```


```

var Display = function(){
	this.display = function(){
		throw new Error("This method must be overwritten!");
	};
};
```


```

var Observer = function(){
	this.update = function(){
		throw new Error("This method must be overwritten!");
	};
};
```


```

var Subject = function(){
	this.registerObserver = function(){
		throw new Error("This method must be overwritten!");
	};
	this.removeObserver = function(){
		throw new Error("This method must be overwritten!");
	};
	this.notifyObservers = function(){
		throw new Error("This method must be overwritten!");
	};
};
```


```
var WeatherData = function(){
	Subject.apply(this);
	this.oObservers = {};
	this.nTemperature = 0;
	this.nHumidity = 0;
	this.nPressure = 0;
	this.registerObserver = function(oObserver){
		this.oObservers[oObserver.id] = oObserver;
	};
	this.removeObserver = function(oObserver){
		delete this.oObservers[oObserver.id];
	};
	this.notifyObservers = function(){
		var sObserverId = '';
		for(sObserverId in this.oObservers){
			if(this.oObservers.hasOwnProperty(sObserverId)){
				this.oObservers[sObserverId].update(this.nTemperature, this.nHumidity, this.nPressure);
			}
		}
	};
};
WeatherData.prototype.measurementsChanged = function(){
	this.notifyObservers();
};
WeatherData.prototype.setMeasurements = function(nTemperature, nHumidity, nPressure){
	this.nTemperature = nTemperature;
	this.nHumidity = nHumidity;
	this.nPressure = nPressure;

	this.measurementsChanged();
};
```

```
<html>
  <head>
    <link type="text/css" rel="stylesheet" href="../css/style.css"/>
	<title>Observer Pattern</title>
	<script type="text/javascript" src="Subject.js"></script>
	<script type="text/javascript" src="Observer.js"></script>
	<script type="text/javascript" src="Display.js"></script>
	<script type="text/javascript" src="WeatherData.js"></script>
	<script type="text/javascript" src="CurrentConditionsDisplay.js"></script>
  </head>
  <body>
    <div id="source">
      <h2>Source</h2>
      <pre>
var oWeatherData = new WeatherData();
var oCurrentConditionsDisplay = new CurrentConditionsDisplay(oWeatherData);
oWeatherData.setMeasurements(80, 65, 30.4);
      </pre>
    </div>
    <div id="console">
    	<h2>Console</h2>
	    <ul></ul>
	    <h1>OBSERVER</h1>
    </div>
    <script type="text/javascript" src="../js/utils.js"></script>
    <script type="text/javascript">
		var oWeatherData = new WeatherData();
		var oCurrentConditionsDisplay = new CurrentConditionsDisplay(oWeatherData);
		oWeatherData.setMeasurements(80, 65, 30.4);
    </script>
  </body>
</html>
```