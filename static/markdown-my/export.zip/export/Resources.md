# Resources
## Animation

<http://web-animations.github.io/web-animations-demos/>

## Database

<https://github.com/kripken/sql.js>

## Editor

* <https://github.com/Microsoft/vscode>

## Front-end JavaScript frameworks

* <https://github.com/angular/angular.js>
* <https://github.com/facebook/react>

## Go

* <http://research.swtch.com/godata>
* <http://research.swtch.com/interfaces>

## Highlight

<https://github.com/PrismJS/prism>

## Template

<https://github.com/ractivejs/ractive>

## Encyclopedia

<http://www.sitepoint.com/>

<http://www.zhihu.com/>


## Image Font

<https://www.google.com/design/icons/>

## Web application frameworks

<https://github.com/meteor/meteor>

<https://github.com/balderdashy/sails>


---

## Erotic

<http://literotic.com/>

## Google

<https://docs.google.com/>


## News

<http://nytimes.com/>


## Read

* <http://geeksquiz.com/>
* <http://www.html5rocks.com/>

## Searc Engine

<http://cn.bing.com/>

## Video

-   <http://www.iqiyi.com/dongman/20120604/ac02e198e286ac6e.html>

    蜡笔小新
-   <http://v.youku.com/v_show/id_XNTI4NjQ1MDMy.html?from=y1.2-2.4.12>

    火影忍者
  

---
  
## GitHub Group

<https://github.com/googlechrome>


<http://keycode.info/> 

获取 Javascript 按键码


<http://code.tutsplus.com/courses>

<https://github.com/v8/v8>

<https://github.com/typekit/webfontloader> 
		
<https://github.com/MaximAbramchuck/awesome-interviews>

<https://github.com/FreeCodeCamp/FreeCodeCamp>


<http://www.postgresql.org/>

 `window.requestAnimationFrame site: stackoverflow.com`
 
 
 `sqlite site: stackoverflow.com`