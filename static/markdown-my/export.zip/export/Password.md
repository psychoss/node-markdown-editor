# Password

|Where|Name|Password|
|---|---|---|
|Github|626377748@qq.com|640916aa|
|Opera|626377748@qq.com|640916|
|QQ|626377748|640916aa|
||1602030365|pickup123|
||240802111|pickup240802|
|Safari Online|asdsadsadas1|pickup123|
|百度网盘|psycho-a|640916a|
||psychochou|640916a|
|淘宝|psycho_euphoria|640917a|
||13422954076|640916a|
|知乎|QQ 1445747555|640916aa|
|Ubuntu||640916|

psycho_euphoria