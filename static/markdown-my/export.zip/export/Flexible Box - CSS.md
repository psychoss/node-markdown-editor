# Flexible Box - CSS

<table responsive="true">
<tbody><tr><th>Property</th><th>Description</th></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dn254946(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">flex-basis</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the initial main size of the flex item.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dn254947(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">flex-grow</strong></a>
</p>
</td><td data-th="Description">
<p>Sets the <em>flex grow factor</em> for the flex item.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dn254948(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">flex-shrink</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the <em>flex shrink factor</em> for the flex item.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127297(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">flex</strong></a>
</p>
</td><td data-th="Description">
<p>A shorthand property that specifies the parameter values of a flexible length, the positive and negative flexibility, and the preferred size specified by the <a href="https://msdn.microsoft.com/en-us/library/dn254947(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">flex-grow</strong></a>, <a href="https://msdn.microsoft.com/en-us/library/dn254948(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">flex-shrink</strong></a>, and <a href="https://msdn.microsoft.com/en-us/library/dn254946(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">flex-basis</strong></a> properties.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127298(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">align-items</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the alignment value (perpendicular to the layout axis defined by the <a href="https://msdn.microsoft.com/en-us/library/jj127299(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">flex-direction</strong></a> property) of flex items in the flex container.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127299(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">flex-direction</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the direction of the main axis which specifies how the flex items are displayed in the  flex container.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127300(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">flex-flow</strong></a>
</p>
</td><td data-th="Description">
<p>Shorthand property to specify both the <a href="https://msdn.microsoft.com/en-us/library/jj127299(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">flex-direction</strong></a> and <a href="https://msdn.microsoft.com/en-us/library/jj127305(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">flex-wrap</strong></a> properties of a flex container.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127301(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">align-self</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the alignment value (perpendicular to the layout axis defined by the <a href="https://msdn.microsoft.com/en-us/library/jj127299(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">flex-direction</strong></a> property) of flex items of the flex container.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127302(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">align-content</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies how a flex item's lines align within the flex container when there is extra space along the axis that is perpendicular to the axis defined by the <a href="https://msdn.microsoft.com/en-us/library/jj127299(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">flex-direction</strong></a> property.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127303(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">order</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the order in which a flex item within a flex container is displayed.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127304(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">justify-content</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a how flex items are aligned along the main axis of the flex container after any flexible lengths and auto margins are resolved. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127305(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">flex-wrap</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies whether flex items wrap and the direction they wrap onto multiple lines or columns  based on the space available in the flex container. </p>
</td></tr>
</tbody></table>