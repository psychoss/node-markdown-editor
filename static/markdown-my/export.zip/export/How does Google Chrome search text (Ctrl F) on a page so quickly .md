# How does Google Chrome search text (Ctrl F) on a page so quickly?
For example, go to any large Wikipedia article, and do a search on the page, the results are highlighted almost instantaneously. To get a perspective of how fast it is, you can try the same on firefox, you'll notice a lag. What algorithm does Google use? Do they do any preprocessing, like hash it or put it in a trie

The 'Ctrl+F' on chrome uses a search algorithm inspired by Boyer-Moore [1] and Boyer-Moore-Horspool [2]

The [algorithm](http://en.wikipedia.org/wiki/Algorithm) pre-processes the string being searched for the pattern, but not the string being searched in the text. It is thus well-suited for applications in which the text does not persist across multiple searches. The Boyer-Moore algorithm uses information gathered during the preprocess step to skip sections of the text, resulting in a lower constant factor than many other string algorithms. In general, the algorithm runs faster as the pattern length increases.

The implementation is part of the V8 string search package path in the chromium project - <http://goo.gl/KeTZW>

In general this is handled by the WebContents part of the chromium project [3]

I had read the chrome internals in a paper some time ago and found that Google does some amazing things in there to speeden up things. I can't find it right now but this 'Chrome Internals' talk [1] at Google I/O from 2009 mentions how they do it.


Update: The below is for searches in the History Context i.e the results that show up when you type a url or some text in the location bar. Thanks to User for pointing this out.

After a page loads,

Text is extracted and fed into the FTS index (sqlite)
Thumbnail is generated and stored

Full text search (FTS) 

The most common (and effective) way to describe full-text searches is "what Google, Yahoo, and Bing do with documents placed on the World Wide Web". Users input a term, or series of terms, perhaps connected by a binary operator or grouped together into a phrase, and the full-text query system finds the set of documents that best matches those terms considering the operators and groupings the user has specified.


In fact the Full Text Search (FTS) project of SQLite was a contribution from Scott Hess of Google to SQLite. Since SQLite is the de-facto database on Android and used within Chrome (and I'm sure several similar projects) it all makes sense.

You can read on FTS in the SQLite docs [2]

[1] [Boyer–Moore string search algorithm](http://en.wikipedia.org/wiki/Boyer%E2%80%93Moore_string_search_algorithm)
[2] [Boyer–Moore–Horspool algorithm](http://en.wikipedia.org/wiki/Boyer-Moore-Horspool_algorithm)
[3] [Find Bar - The Chromium Projects](http://www.chromium.org/developers/design-documents/find-bar)
[1] [Exploring Chrome Internals](http://www.google.com/events/io/2009/sessions/ExploringChromeInternals.html)
[2] [SQLite FTS3 and FTS4 Extensions](http://www.sqlite.org/fts3.html)