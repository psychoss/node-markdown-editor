# Visual Formatting Model - CSS

<table responsive="true">
<tbody><tr><th>Property</th><th>Description</th></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530745(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">bottom</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  the bottom position of the object in relation to the bottom of the next positioned object in the document hierarchy. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530747(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">clear</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  whether the object allows floating objects on its left side, right side, or both, so that the next text displays past the floating objects.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530751(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">display</strong></a>
</p>
</td><td data-th="Description">
<p>Gets or sets a value that indicates  whether and how the object is rendered.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530755(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">float</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  on which side of the object the text will flow.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530765(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">height</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  the height of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530778(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">left</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  the position of the object relative to the left edge of the next positioned object in the document hierarchy. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530784(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">line-height</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  the distance between lines in the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530809(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">max-height</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves the maximum height for an element.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530811(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">max-width</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves the maximum width for an element.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530815(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">min-height</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the minimum height for an element.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530820(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">min-width</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves the minimum width for an element.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531140(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">position</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  the type of positioning used for the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531149(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">right</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  the position of the object relative to the right edge of the next positioned object in the document hierarchy. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531177(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">top</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  the position of the object relative to the top of the next positioned object in the document hierarchy. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531179(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">vertical-align</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  the vertical alignment of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531183(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">width</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the width of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531188(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">z-index</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  the stacking order of positioned objects. </p>
</td></tr>
</tbody></table>