# Text - CSS

<table responsive="true">
<tbody><tr><th>Property</th><th>Description</th></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530780(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">letter-spacing</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the amount of additional space between letters in the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530782(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">line-break</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  
			line-breaking rules for text in selected languages
			such as Japanese, Chinese, and Korean.
    </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dd229917(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-block-progression</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the block progression and layout orientation.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771865(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-hyphenate-limit-chars</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies one to three values that indicates the minimum number of characters in a hyphenated word.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771867(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-hyphenate-limit-lines</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a value that indicates the maximum number of consecutive lines in an element that may be ended with a hyphenated word.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771869(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-hyphenate-limit-zone</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a value that defines the width of the hyphenation zone.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771871(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-hyphens</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a value that indicates whether additional break opportunities for the current line are created by hyphenating individual words within the line.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530767(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-ime-mode</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the state of an Input Method Editor (IME).</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530770(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-layout-flow</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the direction and flow of the content in the object.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530771(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-layout-grid</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the composite document grid properties that specify the layout of text characters.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530772(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-layout-grid-char</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the size of the character grid used for rendering the text content of an element.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530773(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-layout-grid-line</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the gridline value used for rendering the text content of an element.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530774(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-layout-grid-mode</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  whether the text layout grid uses two dimensions.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530775(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-layout-grid-type</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the type of grid used for rendering the text content of an element.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531163(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-text-align-last</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a value that indicates  how to align the last line or only line of text in the specified object.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531164(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-text-autospace</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the autospacing and narrow space width adjustment of text. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531172(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">text-justify</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the type of alignment used to justify text in the object.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531173(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-text-kashida-space</strong></a>
</p>
</td><td data-th="Description">
<p>Deprecated. Specifies  the ratio of kashida expansion to white space expansion when justifying lines of text in the object.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dn793579(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-text-size-adjust</strong></a>
</p>
</td><td data-th="Description">
<p>Adjusts the text size on a webpage on IE for Windows Phone.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531174(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">text-overflow</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a value that indicates whether to render ellipses (...) to indicate text overflow.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531176(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-text-underline-position</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the position of the underline decoration that is set through the  <a href="https://msdn.microsoft.com/en-us/library/ms531165(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">text-decoration</strong></a> property of the object.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531162(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">text-align</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  whether the text in the object is left-aligned, right-aligned, centered, or justified. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531165(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">text-decoration</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  a value that indicates whether the text in the object has blink, line-through, overline, or underline decorations. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531171(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">text-indent</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the indentation of the first line of text in the object. </p>
<p>This property is not supported for Windows Store apps using JavaScript.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771872(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">text-shadow</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a comma-separated list of shadows that attaches one or more drop shadows to the specified text.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531175(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">text-transform</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the rendering of the text in the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dn985709(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-webkit-text-fill-color</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a fill color for text.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531182(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">white-space</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a value that indicates whether lines are automatically broken inside the object.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531184(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">word-break</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies
      line-breaking behavior within words, particularly where multiple
      languages appear in the object.
    </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531185(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">word-spacing</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the amount of additional space between words in the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531186(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">word-wrap</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies whether to break words when the content exceeds the boundaries of its container.</p>
</td></tr>
</tbody></table>