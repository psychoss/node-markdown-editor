# 文件操作 Node.js - Code Snippets

## 创建序列文件
```
const fs = require('fs');
var c = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes">
  <meta http-equiv="Content-Language" content="zh">
  <meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible" />
  <title></title>
  <style></style>
</head>

<body>
  <script type="text/javascript"></script>
</body>

</html>`;

const padLeft = function (s, l, c) {
	s = s + '';
	c = c || '0';
	while (s.length < l) {
		s = c + s;
	}
	return s;
}


var i = 100;
for (; i > 3; i--) {
 
	 fs.writeFile(padLeft(i, 3)+".html",c);
}


```