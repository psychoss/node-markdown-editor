JavaScript Trick

1/0=Infinity
0|27.4=27
~~28.4=28
~-1=0


1. You can pass arguments into setTimeout and setInterval
Say you want to pass in two variables to the function you call in setTimeout.  You'd probably think this is the only way to do it:

var callback = function(a,b){
    console.log(a + b);  // 'foobar'
}
window.setTimeout(function(){
    callback('foo', 'bar');
}, 1000);



But you can accomplish the same thing with this:  

window.setTimeout(callback, 1000, 'foo', 'bar');


Note that this isn't supported on IE (not even IE9).


2. Old String functions
If you type in String.prototype into your console, you can see a bunch of old functions you can use to wrap the text in HTML tags (some deprecated HTML obviously):

'foo'.italics()

...will return this:

'<i>foo</i>'

Similarly for strike(), sub(), small(), link() (Brian Yee refers to this in his comment), etc.


3. An HTML element with an ID creates a JavaScript global with the same name
Surprising but true, and it's done by modern browsers as a means of backwards compatibility:

HTML: 
<div id="someInnocentDiv"></div>
  

JS:
console.log(someInnocentDiv);  // <div id="someInnocentDiv"></div>



4. You can read the text at any XY coordinate on a webpage
var x = 50, y = 100;
var range = document.caretRangeFromPoint(x, y);
if(range) {
    range.expand('word');
    var word = range.startContainer.textContent.substring(range.startOffset, range.endOffset);
    console.log(word);
}


A cross-browser compatible way of doing this: http://jsfiddle.net/heZ4z/


5. You can base64 encode files dropped onto the document from your desktop

document.ondrop = function (e) {
    e.preventDefault();  // prevent browser from trying to run/display the file
    var reader = new FileReader();
    reader.onload = function(e) {
      console.log(e.target.result);  // base64 encoded file data!
    };
    reader.readAsDataURL(e.dataTransfer.files[0]);
}