# Analysis of generators and other async patterns in node

Table of contents:

* A gentle introduction to generators
* The analysis
* The examples
* Complexity
* Performance (time and memory)
* Debuggability
    * Source maps support
    * Stack trace accuracy
* Conclusion

Async coding patterns are the subject of never-ending debates for us node.js developers. Everyone has their own favorite method or pet library as well as strong feelings and opinions on all the other methods and libraries. Debates can be heated: sometimes social pariahs may be declared or grave rolling may be induced.

The reason for this is that JavaScript never had any continuation mechanism to allow code to pause and resume across the event loop boundary.

Until now.


## A gentle introduction to generators
If you know how generators work, you can skip this and continue to the analysis

Generators are a new feature of ES6. Normally they would be used for iteration. Here is a generator that generates Fibonacci numbers. The example is taken from the ECMAScript harmony wiki:

```
function* fibonacci() {
    let [prev, curr] = [0, 1];
    for (;;) {
        [prev, curr] = [curr, prev + curr];
        yield curr;
    }
}
```

And here is how we iterate through this generator:

```
for (n of fibonacci()) {
    // truncate the sequence at 1000
    if (n > 1000) break;
    console.log(n);
}
```

What happens behind the scene?

Generator functions are actually constructors of iterators. The returned iterator object has a next() method. We can invoke that method manually:

```
var seq = fibonacci();
console.log(seq.next()); // 1
console.log(seq.next()); // 2 etc.
```

When next is invoked, it starts the execution of the generator. The generator runs until it encounters a yield expression. Then it pauses and the execution goes back to the code that called next

So in a way, yield works similarly to return. But there is a big difference. If we call next on the generator again, the generator will resume from the point where it left off - from the last yield line.

In our example, the generator will resume to the top of the endless for loop and calculate the next Fibonacci pair.

So how would we use this to write async code?

A great thing about the next() method is that it can also send values to the generator. Let's write a simple number generator that also collects the stuff it receives. When it gets two things it prints them using console.log:

```
function* numbers() {
    var stuffIgot = [];
    for (var k = 0; k < 2; ++k) {
        var itemReceived = yield k;
        stuffIgot.push(itemReceived);
    }
    console.log(stuffIgot);
}
```

This generator gives us 3 numbers using yield. Can we give something back?

Let's give two things to this generator:

```
var iterator = numbers();
// Cant give anything the first time: need to get to a yield first.
console.log(iterator.next()); // logs 0
console.log(iterator.next('present')); // logs 1
fs.readFile('file.txt', function(err, resultFromAnAsyncTask) {
    console.log(iterator.next(resultFromAnAsyncTask)); // logs 2
});
```

The generator will log the string 'present' and the contents of file.txt

Uh-oh.

Seems that we can keep the generator paused across the event loop boundary.

What if instead of numbers, we yielded some files to be read?

```
function* files() {
    var results = [];
    for (var k = 0; k < files.length; ++k)
        results.push(yield files[k]);
    return results;
}
```

We could process those file reading tasks asynchronously.

```
var iterator = files();
function process(iterator, sendValue) {
    var fileTask = iterator.next(sendValue);
    fs.readFile(fileTask, function(err, res) {
        if (err) iterator.throw(err);
        else process(iterator, res);
    });
}
process(iterator);
```

But from the generator's point of view, everything seems to be happening synchronously: it gives us the file using yield, then it waits to be resumed, then it receives the contents of the file and makes a push to the results array.

And there is also generator.throw(). It causes an exception to be thrown from inside the generator. How cool is that?

With next and throw combined together, we can easily run async code. Here is an example from one of the earliest ES6 async generators library task.js.

```
spawn(function* () {
    var data = yield $.ajax(url);
    $('#result').html(data);
    var status = $('#status').html('Download complete.');
    yield status.fadeIn().promise();
    yield sleep(2000);
    status.fadeOut();
});
```

This generator yields promises, which causes it to suspend execution. The spawn function that runs the generator takes those promises and waits until they're fulfilled. Then it resumes the generator by sending it the resulting value.

When used in this form, generators look a lot like classical threads. You spawn a thread, it issues blocking I/O calls using yield, then the code resumes execution from the point it left off.

There is one very important difference though. While threads can be suspended involuntarily at any point by the operating systems, generators have to willingly suspend themselves using yield. This means that there is no danger of variables changing under our feet, except after a yield.

Generators go a step further with this: it's impossible to suspend execution without using the yield keyword. In fact, if you want to call another generator you will have to write yield* anotherGenerator(args). This means that suspend points are always visible in the code, just like they are when using callbacks.

Amazing stuff! So what does this mean? What is the reduction of code complexity? What are the performance characteristics of code using generators? Is debugging easy? What about environments that don't have ES6 support?

I decided to do a big comparison of all existing node async code patterns and find the answers to these questions.


## The analysis
For the analysis, I took file.upload, a typical CRUD method extracted from [DoxBee](http://doxbee.com/) called when uploading files. It executes multiple queries to the database: a couple of selects, some inserts and one update. Lots of mixed sync / async action.

It looks like this:

```
function upload(stream, idOrPath, tag, done) {
    var blob = blobManager.create(account);
    var tx = db.begin();
    function backoff(err) {
        tx.rollback();
        return done(new Error(err));
    }
    blob.put(stream, function (err, blobId) {
        if (err) return done(err);
        self.byUuidOrPath(idOrPath).get(function (err, file) {
            if (err) return done(err);
            var previousId = file ? file.version : null;
            var version = {
                userAccountId: userAccount.id,
                date: new Date(),
                blobId: blobId,
                creatorId: userAccount.id,
                previousId: previousId
            };
            version.id = Version.createHash(version);
            Version.insert(version).execWithin(tx, function (err) {
                if (err) return backoff(err);
                if (!file) {
                    var splitPath = idOrPath.split('/');
                    var fileName = splitPath[splitPath.length - 1];
                    var newId = uuid.v1();
                    self.createQuery(idOrPath, {
                        id: newId,
                        userAccountId: userAccount.id,
                        name: fileName,
                        version: version.id
                    }, function (err, q) {
                        if (err) return backoff(err);
                        q.execWithin(tx, function (err) {
                            afterFileExists(err, newId);
                        });

                    })
                }
                else return afterFileExists(null, file.id);
            });
            function afterFileExists(err, fileId) {
                if (err) return backoff(err);
                FileVersion.insert({fileId: fileId,versionId: version.id})
                    .execWithin(tx, function (err) {
                        if (err) return backoff(err);
                        File.whereUpdate({id: fileId}, {
                            version: version.id
                        }).execWithin(tx, function (err) {
                            if (err) return backoff(err);
                            tx.commit(done);
                        });
                })
            }
        });
    });
}
```

Slightly pyramidal code full of callbacks.

This is how it looks like when written with generators:

```
var genny = require('genny');
module.exports = genny.fn(function* upload(resume, stream, idOrPath, tag) {
    var blob = blobManager.create(account);
    var tx = db.begin();
    try {
        var blobId = yield blob.put(stream, resume());
        var file = yield self.byUuidOrPath(idOrPath).get(resume());
        var previousId = file ? file.version : null;
        var version = {
            userAccountId: userAccount.id,
            blobId: blobId,
            creatorId: userAccount.id,
            previousId: previousId
        };
        version.id = Version.createHash(version);
        yield Version.insert(version).execWithin(tx, resume());
        if (!file) {
            var splitPath = idOrPath.split('/');
            var fileName = splitPath[splitPath.length - 1];
            var newId = uuid.v1();
            var file = {
                id: newId,
                userAccountId: userAccount.id,
                name: fileName,
                version: version.id
            }
            var q = yield self.createQuery(idOrPath, file, resume());
            yield q.execWithin(tx, resume());
        }
        yield FileVersion.insert({fileId: file.id, versionId: version.id})
            .execWithin(tx, resume());
        yield File.whereUpdate({id: file.id}, {version: version.id})
            .execWithin(tx, resume());
        yield tx.commit(resume());
    } catch (e) {
        tx.rollback();
        throw e;
    }
});
```

Shorter, very straight-forward code and absolutely no nesting of callback functions. Awesome.

Yet subjective adjectives are not very convincing. I want to have a measure of complexity, a number that tells me what I'm actually saving.

I also want to know what the performance characteristics are - how much time and memory would it take to execute a thousand of parallel invocations of this method? What about 2000 or 3000?

Also, what happens if an exception is thrown? Do I get a complete stack trace like in the original version?

I also wanted to compare the results with other alternatives, such as fibers, streamlinejs and promises (without generators).

So I wrote a lot of different versions of this method, and I will share my personal impressions before giving you the results of the analysis


## The examples
### [original.js](https://github.com/spion/async-compare/blob/blog/examples/original.js)

The original solution, presented above. Vanilla callbacks. Slightly pyramidal. I consider it acceptable, if a bit mediocre.

### [flattened.js](https://github.com/spion/async-compare/blob/blog/examples/flattened.js)

Flattened variant of the original via named functions. Taking the advice from callback hell, I flattened the pyramid a little bit. As I did that, I found that while the pyramid shrunk, the code actually grew.

### [catcher.js](https://github.com/spion/async-compare/blob/blog/examples/catcher.js)

I noticed that the first two vanilla solutions had a lot of common error handling code everywhere. So I wrote a tiny library called catcher.js which works very much like node's domain.intercept. This reduced the complexity and the number of lines further, but the pyramidal looks remained.

### [async.js](https://github.com/spion/async-compare/blob/blog/examples/async.js)

Uses the waterfall function from [caolan's async](https://github.com/caolan/async). Very similar to flattened.js but without the need to handle errors at every step.

### [flattened-class.js](https://github.com/spion/async-compare/blob/blog/examples/flattened-class.js), [flattened-noclosure.js](https://github.com/spion/async-compare/blob/blog/examples/flattened-noclosure.js), [flattened-class-ctx.js](https://github.com/spion/async-compare/blob/blog/examples/flattened-class-ctx.js)

See [this post](https://spion.github.io/posts/closures-are-unavoidable-in-node.html) for details


### [promises.js](https://github.com/spion/async-compare/blob/blog/examples-extra/promises.js)

I'll be honest. I've never written promise code in node before. Driven by [Gozalla's excellent post](https://jeditoolkit.com/2012/04/26/code-logic-not-mechanics.html#post) I concluded that everything should be a promise, and things that can't handle promises should also be rewritten.

Take for example this particular line in the original:

    var previousId = file ? file.version : null;
If file is a promise, we can't use the ternary operator or the property getter. Instead we need to write two helpers: a ternary operator helper and a property getter helper:

    var previousIdP = p.ternary(fileP, p.get(fileP, 'version'), null);
Unfortunately this gets out of hand quickly:

```
var versionP = p.allObject({
    userAccountId: userAccount.id,
    blobId: blobIdP,
    creatorId: userAccount.id,
    previousId: previousIdP,
    ...
});
versionP = p.set(versionP, p.allObject({
    id: fn.call(Version.createHash, versionP)
}));
// Even if Version.insert has been lifted to take promise arguments, it returns
// a promise and therefore we cannot call execWithinP. We have to wait for the
// promise  to resolve to invoke the function.
var versionInsert = p.eventuallyCall(
    Version.insert(versionP), 'execWithinP', tx);
var versionIdP = p.get(versionP, 'id');
```

So I decided to write a less aggressive version, promiseish.js

note: I used [when](https://github.com/cujojs/when) because i liked its function lifting API better than Q's

### [promiseish.js](https://github.com/spion/async-compare/blob/blog/examples/promiseish.js) and [promiseishQ.js](https://github.com/spion/async-compare/blob/blog/examples/promiseishQ.js)

Nothing fancy here, just some .then() chaining. In fact it feels less complex than the promise.js version, where I felt like I was trying to fight the language all the time.

The second file promiseishQ.js uses Q instead of when. No big difference there.

### [fibrous.js](https://github.com/spion/async-compare/blob/blog/examples/fibrous.js)

[Fibrous](https://github.com/goodeggs/fibrous) is a fibers library that creates "sync" methods out of your async ones, which you can then run in a fiber.

So if for example you had:

    fs.readFile(file, function(err, data){ ... });
Fibrous would generate a version that returns a future, suspends the running fiber and resumes execution when the value becomes available.

    var data = fs.sync.readFile(file);
I also needed to wrap the entire upload function:

    fibrous(function upload() { ... })
This felt very similar to the generators version above but with sync instead of yield to indicate the methods that will yield. The one benefit I can think of is that it feels more natural for chaining - less parenthesis are needed.

```
somefn.sync(arg).split('/')
// vs
(yield somefn(arg, resume)).split('/')
```

Major drawback: this will never be available outside of node.js or without native modules.

Library: [fibrous](https://github.com/goodeggs/fibrous)

### [suspend.js](https://github.com/spion/async-compare/blob/blog/examples/suspend.js) and [genny.js](https://github.com/spion/async-compare/blob/blog/examples-extra/promises.js)

[suspend](https://github.com/jmar777/suspend) and [genny](http://github.com/spion/genny) are generator-based solutions that can work directly with node-style functions.

I'm biased here since I wrote genny. I still think that this is objectively the best way to use generators in node. Just replace the callback with a placeholder generator-resuming function, then yield that. Comes back to you with the value.

Kudos to jmar777 for realizing that you don't need to actually yield anything and can resume the generator using the placeholder callback instead.

Both suspend and genny use generators roughly the same way. The resulting code is very clean, very straightforward and completely devoid of callbacks.

### [qasync.js](https://github.com/spion/async-compare/blob/blog/examples/qasync.js)

Q provides two methods that allow you to use generators: Q.spawn and Q.async. In both cases the generator yields promises and in turn receives resolved values.

The code didn't feel very different from genny and suspend. Its slightly less complicated: you can yield the promise instead of placing the provided resume function at every point where a callback is needed.

Caveat: as always with promises you will need to wrap all callback-based functions.

Library: Q

### [co.js](https://github.com/spion/async-compare/blob/blog/examples/co.js) and [gens.js](https://github.com/spion/async-compare/blob/blog/examples/gens.js)

Gens and co are generator-based libraries. Both can work by yielding thunk-style functions: that is, functions that take a single argument which is a node style callback in the format function (err, result)

The code looks roughly the same as qasync.js

The problem is, thunks still require wrapping. The recommended way to wrap node style functions is to use co.wrap for co and fn.bind for gens - so thats what I did.

[streamline.js](https://github.com/spion/async-compare/blob/blog/examples/src-streamline._js)

Uses streamlinejs CPS transformer and works very much like co and qasync, except without needing to write yield all the time.

Caveat: you will need to compile the file in order to use it. Also, even though it looks like valid JavaScript, it isn't JavaScript. Superficially, it has the same syntax, but it has very different semantics, particularly when it comes to the _ keyword, which acts like yield and resume combined in one.

The code however is really simple and straightforward: infact it has the lowest complexity.

## Complexity
To measure complexity I took the number of tokens in the source code found by Esprima's lexer (comments excluded). The idea is taken from Paul Graham's essay Succinctness is Power

I decided to allow all callback wrapping to happen in a separate file: In a large system, the wrapped layer will probably be a small part of the code.

Results:

<table>
<thead>
<tr>
<th style="text-align:left">name</th>
<th style="text-align:right">tokens</th>
<th style="text-align:right">complexity</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align:left">src-streamline._js</td>
<td style="text-align:right">302</td>
<td style="text-align:right">1.00</td>
</tr>
<tr>
<td style="text-align:left">co.js</td>
<td style="text-align:right">304</td>
<td style="text-align:right">1.01</td>
</tr>
<tr>
<td style="text-align:left">qasync.js</td>
<td style="text-align:right">314</td>
<td style="text-align:right">1.04</td>
</tr>
<tr>
<td style="text-align:left">fibrous.js</td>
<td style="text-align:right">317</td>
<td style="text-align:right">1.05</td>
</tr>
<tr>
<td style="text-align:left">suspend.js</td>
<td style="text-align:right">331</td>
<td style="text-align:right">1.10</td>
</tr>
<tr>
<td style="text-align:left">genny.js</td>
<td style="text-align:right">339</td>
<td style="text-align:right">1.12</td>
</tr>
<tr>
<td style="text-align:left">gens.js</td>
<td style="text-align:right">341</td>
<td style="text-align:right">1.13</td>
</tr>
<tr>
<td style="text-align:left">catcher.js</td>
<td style="text-align:right">392</td>
<td style="text-align:right">1.30</td>
</tr>
<tr>
<td style="text-align:left">promiseishQ.js</td>
<td style="text-align:right">396</td>
<td style="text-align:right">1.31</td>
</tr>
<tr>
<td style="text-align:left">promiseish.js</td>
<td style="text-align:right">411</td>
<td style="text-align:right">1.36</td>
</tr>
<tr>
<td style="text-align:left">original.js</td>
<td style="text-align:right">421</td>
<td style="text-align:right">1.39</td>
</tr>
<tr>
<td style="text-align:left">async.js</td>
<td style="text-align:right">442</td>
<td style="text-align:right">1.46</td>
</tr>
<tr>
<td style="text-align:left">promises.js</td>
<td style="text-align:right">461</td>
<td style="text-align:right">1.53</td>
</tr>
<tr>
<td style="text-align:left">flattened.js</td>
<td style="text-align:right">473</td>
<td style="text-align:right">1.57</td>
</tr>
<tr>
<td style="text-align:left">flattened-noclosure.js</td>
<td style="text-align:right">595</td>
<td style="text-align:right">1.97</td>
</tr>
<tr>
<td style="text-align:left">flattened-class-ctx.js</td>
<td style="text-align:right">674</td>
<td style="text-align:right">2.23</td>
</tr>
<tr>
<td style="text-align:left">flattened-class.js</td>
<td style="text-align:right">718</td>
<td style="text-align:right">2.38</td>
</tr>
<tr>
<td style="text-align:left">rx.js</td>
<td style="text-align:right">935</td>
<td style="text-align:right">3.10</td>
</tr>
</tbody>
</table>


Streamline and co have the lowest complexity. Fibrous, qasync, suspend, genny and gens are roughly comparable.

Catcher is comparable with the normal promise solutions. Both are roughly comparable to the original version with callbacks, but there is some improvement as the error handling is consolidated to one place.

It seems that flattening the callback pyramid increases the complexity a little bit. However, arguably the readability of the flattened version is improved.

Using caolan's async in this particular case doesn't seem to yield much improvement. Its complexity however is lower than the flattened version because it consolidates error handling.

Going promises-all-the-way as Gozala suggests also increases the complexity because we're fighting the language all the time.

The rx.js sample is still a work in progress - it can be made much better.


## Performance (time and memory)
All external methods are mocked using setTimeout to simulate waiting for I/O.

There are two variables that control the test:

* nn - the number of parallel "upload requests"
* tt - average wait time per async I/O operation

For the first test, I set the time for every async operation to 1ms then ran every solution for  `n∈{100,500,1000,1500,2000}` .

note: hover over the legend to highlight the item on the chart.

![](/images/2015-12-12/1.png) 

Wow. Promises seem really, really slow. Fibers are also slow, with time complexity O(n^2). Everything else seems to be much faster.

Update (Dec 20 2013): Promises not slow anymore. PetkaAntonov wrote Bluebird, which is faster than almost everything else and very low on memory usage. For more info read Why I am switching to Promises

Lets try removing all those promises and fibers to see whats down there.