# hover 事件 - Code Snippets


```
		var hover = function() {
			var items = self.holder.querySelectorAll(self.CONST.item);
			var i = items.length;
			for (; i--;) {
				items[i].addEventListener('mouseenter', function(ev) {
					if (!ev.target.classList.contains(self.CONST.itemHover))
						ev.target.classList.add(self.CONST.itemHover)
				});
				items[i].addEventListener('mouseleave', function(ev) {
					if (ev.target.classList.contains(self.CONST.itemHover))
						ev.target.classList.remove(self.CONST.itemHover)
				});
			}
		};
```