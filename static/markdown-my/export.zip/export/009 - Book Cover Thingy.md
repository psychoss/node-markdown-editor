# 009 - Book Cover Thingy


```
<div class="cover cover--container">
    <div class="cover--content cover--top">
        <h2>Edgar Allan Poe</h1>
    </div>
    <span class="cover--teaser">
        poe
    </span>
    <div class="cover--content cover--highlight">
        <h1>The Raven & Other Writings</h1>
        <hr/>
        <p>
            Around, by lifting winds forgot,<br/>
            Resignedly beneath the sky<br/>
            The melancholy waters lie.
        </p>
    </div>
</div>
```

```
@import url(https://fonts.googleapis.com/css?family=EB+Garamond|Crimson+Text:400,400italic,600,600italic,700,700italic|Libre+Baskerville:400,700|Droid+Serif|Playfair+Display|Open+Sans+Condensed:300,700);
@import url(https://fonts.googleapis.com/css?family=Alegreya&text=%26);

*, *:after, *:before {
    -webkit-box-sizing: border-box;
       -moz-box-sizing: border-box;
            box-sizing: border-box;
}

html, body {
    font-family: 'Alegreya', 'EB Garamond';
    font-size: 22px;
    line-height: 1.4rem;
    background: #FFF7FA url(http://subtlepatterns.com/patterns/groovepaper.png) repeat;
    height: 100%;
    padding: .5rem;
    -webkit-text-size-adjust: 100%;
       -moz-text-size-adjust: 100%;
        -ms-text-size-adjust: 100%;
         -o-text-size-adjust: 100%;
            text-size-adjust: 100%;
    -webkit-font-feature-settings: "kern" on, "calt" on, "liga" on;
       -moz-font-feature-settings: "kern" on, "calt" on, "liga" on;
         -o-font-feature-settings: "kern" on, "calt" on, "liga" on;
            font-feature-settings: "kern" on, "calt" on, "liga" on;
    text-rendering: optimizeLegibility;
    -moz-osx-font-smoothing: auto;
     -webkit-font-smoothing: antialiased;
             font-smoothing: antialiased;
    font-kerning: normal;
    color: #1A3140;
}

h1,
h2,
p {
    margin: 0;
    padding: 0;
    line-height: 1.4em;
}

h1 {
    font-size: 1.7rem;
}

h2 {
    font-size: 1.4rem;
}

.cover {
    height: 100%;
    background-color: #EDE3C5;
    overflow: hidden;
    position: relative;
}

.cover--container {
    max-width: 610px;
    margin: 0 auto;
}

.cover--content {
    text-shadow: 0 1px 0 rgba(#fff, .4);
    padding: 1rem;
}

.cover--top {
    padding: 3rem 1rem 4rem 1rem;
}

.cover--highlight {
    background-color: #F36E5B;
    color: #F9EFED;
    text-shadow: 0 -1px 0 rgba(#000, .2);
}

.cover--teaser {
    font-family: 'Open Sans Condensed';
    text-transform: uppercase;
    position: absolute;
    font-size: 6rem;
    line-height: 1em;
    font-weight: 700;
    transform: rotate(-90deg);
    top: 1.4rem;
    right: -2.2rem;
    opacity: .85;
}

hr {
    position: relative;
    border: none;
    border-top: 1px solid rgba(#fff, .5);
    border-bottom: 1px solid rgba(#000, .1);
    height: 1px;
    line-height: .2rem;
    margin: 1rem 0;
    
    &:before {
        content: '\2766';
        padding: 0 .3rem 0 0;
        background-color: #F36E5B;
        color: lighten(#F36E5B, 25);
    }
}
```