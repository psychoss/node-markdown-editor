# Basic UI - CSS

<table responsive="true">
<tbody><tr><th>Property</th><th>Description</th></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772367(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:invalid</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to specified <a href="http://go.microsoft.com/fwlink/p/?LinkID=219805">input</a> fields when the fields are invalid.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772745(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:-ms-input-placeholder</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to placeholder text in an <a href="http://go.microsoft.com/fwlink/p/?LinkID=219805">input</a> element.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772709(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:optional</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to specified <a href="http://go.microsoft.com/fwlink/p/?LinkID=219805">input</a> fields when the fields are optional.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772720(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:required</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to specified <a href="http://go.microsoft.com/fwlink/p/?LinkID=219805">input</a> fields when the fields are required.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772727(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:valid</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to specified <a href="http://go.microsoft.com/fwlink/p/?LinkID=219805">input</a> fields when the fields are valid.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/cc848869(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:visited</strong></a>
</p>
</td><td data-th="Description">
<p>
      Specifies the style of an <a href="https://msdn.microsoft.com/en-us/library/ms535173(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">a</strong></a> element if the link has been visited recently.
    </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dd183522(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">box-sizing</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies 
			the box model to use for object sizing.
    </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/cc304061(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">content</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies 
			generated content to insert before or after an element.
    </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/aa358795(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">cursor</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the type of cursor to display as the mouse pointer moves over the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530756(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">font</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a combination of separate <a href="https://msdn.microsoft.com/en-us/library/ms530756(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">font</strong></a> properties of the object. Alternatively, sets or retrieves one or more of six user-preference fonts.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh781491(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-progress-appearance</strong></a>
</p>
</td><td data-th="Description">
<p>This property is obsolete. Use <a href="https://msdn.microsoft.com/en-us/library/hh772236(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">animation-name</strong></a> instead. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531153(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-scrollbar-3dlight-color</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the color of the top and left edges of the scroll box and scroll arrows of a scroll bar.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531154(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scrollbar-arrow-color</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the color of the arrow elements of a scroll arrow.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531155(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scrollbar-base-color</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the base color of the main elements of a scroll bar.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531156(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-scrollbar-darkshadow-color</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the color of the gutter of a scroll bar.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531157(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scrollbar-face-color</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the color of the scroll box and scroll arrows of a scroll bar.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531158(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scrollbar-highlight-color</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the color of the slider tray, and the top and left edges of the scroll box and scroll arrows of a scroll bar.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531159(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-scrollbar-shadow-color</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the color of the bottom and right edges of the scroll box and scroll arrows of a scroll bar.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531160(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scrollbar-track-color</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the color of the track element of a scroll bar.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531174(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-text-overflow</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a value that indicates whether to render ellipses (...) to indicate text overflow.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh781492(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-user-select</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a keyword value that indicates where users are able to select text within an element.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531189(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">zoom</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the magnification scale of the object.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/cc304063(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">outline</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies 
			the color, style, and width of the outline frame.
    </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/cc304064(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">outline-color</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies 
			the color of the outline frame.
  </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/cc304065(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">outline-style</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies 
			the style of the outline frame.
    </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/cc304066(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">outline-width</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies 
			the width of the outline frame.
    </p>
</td></tr>
</tbody></table>