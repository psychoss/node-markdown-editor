# Color - CSS

<table responsive="true">
<tbody><tr><th>Property</th><th>Description</th></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530749(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">color</strong></a>
</p>
</td><td data-th="Description">
<p>The foreground color of the text of an object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127325(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">opacity</strong></a>
</p>
</td><td data-th="Description">
<p>Gets or sets a value that specifies object or group opacity in CSS or Scalable Vector Graphics (SVG).</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531197(v=vs.85).aspx">Color Table</a>
</p>
</td><td data-th="Description">
<p>Colors can be specified in HTML pages by using numbers to denote an RGB color value, or by using a color name. In Windows Internet Explorer&nbsp;9, you can define colors by hue, saturation, luminosity (HSL) values and alpha transparency. </p>
</td></tr>
</tbody></table>