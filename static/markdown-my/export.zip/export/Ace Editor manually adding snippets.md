# Ace Editor manually adding snippets


TL;DR

I am trying to manually trigger ace editor snippets through a function call, rather than the conventional approach (keyboard keys).

Explanation

I need a function that takes in the editor and a snippet string as the parameters, and adds that snippet to the editor.  `function addSnippet(editor, snippet)` .

Ace editor supports TextMate-ish snippets.

```
if (${1:condition_name}) {
     ${2:body}
}
```

So when we call this function, it should add the snippet, highlight the snippet markers and select the first one. After filling the first one and hitting tab, the editor should move to the next snippet marker. Just like in the Kitchen Sink example (but I want to add/trigger snippets via a function call instead).

I tried hacking my way through and made this function. But it's messy and incomplete (doesn't support markers and tab presses). Is there any native method for this? I've seen a few examples using `snippetManager` , but they use keyboard triggers, not manual functions.

Any help regarding this issue would be appreciated. Thanks.

----


After hours of hacks and research, I finally came across the insertSnippet function of snippetManager in  `ext-language_tools.js` , it works this way:

```
var snippetManager = ace.require("ace/snippets").snippetManager;
snippetManager.insertSnippet(editor, snippet);
```

Pretty easy actually, couldn't find it earlier due to lack of documentation.