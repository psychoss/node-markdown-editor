# DOM - Code Snippets

- document.createDocumentFragment()
  
  创建 DocumentFragment

## 事件

|关键字|描述|
|---|---|
|addEventListener|添加事件侦听|
|鼠标事件|mouseenter,mouseleave(类似于:hover)|