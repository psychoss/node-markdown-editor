# What are some simple strategies to enhance JavaScript performance?
In searching for ways to improve the performance of your JavaScript, you'll probably come across a whole bunch of in-depth articles ([A resource for open web HTML5 developers](http://html5rocks.com/) is a great example). I thought it would be nice to have brief synopses of what these strategies are, and if possible breifly, why they work.

>For raw js speed, get familiar with the internals of modern JS engines.  At their core, V8, Nitro, Jaegermonkey, etc... Are all similar, they are all jit compiling, adaptive optimizing vms.  All have similar triggers back to the slow path like megamorphic call sites.
>
>Some resources:
>* [http://wingolog.org/archives/201...](http://wingolog.org/archives/2011/07/05/v8-a-tale-of-two-compilers)
>* [http://floitsch.blogspot.com/201...](http://floitsch.blogspot.com/2012/03/optimizing-for-v8-hydrogen.html)
>
>All that said,measure to ensure raw js execution speed is actually your bottleneck.  If you're actually bottlenecked on DOM, none of this will help.

Write your code like it's C.

That is:

- Don't allocate a lot of objects/arrays
- Think of your variables and attributes as having types and don't change them
- Don't dynamically add attributes to your reusable objects unless you need to


Sorry for the digression, but from the point of view of a frontend web application developer, JS is rarely the bottleneck in the browser. Like others noted it is usually DOM manipulation. 

When I was a younger developer I would try to write the most efficient code. But, now I know now that this was at the sacrifice of expressiveness, simplicity and accuracy. 

This pertains to frontend and backend development alike.

To give an example, I would avoid the use of the forEach, filter, map and reduce functions, because I knew that iterating over an Array using a for loop performed substantially faster. 

Now I know that these types of optimization only make a difference in edge cases, like if you are iterating over hundreds of thousands of elements. It is far more important for the developer's intention to be obvious and their code to be accurate. When writing more imperative code like I described, there are more moving parts and greater chance for developer error. 

Many times a slower more expressive method will give the average developer a better performing system in the end because you can macro optimize over making micro optimizations. 

A great example of this is using immutable data structures. Even though libraries like mori and immutable.js are relatively slower than using native JS arrays and objects as maps. You can make great optimizations like detecting model changes by using equality by reference (===) with immutable data structures, over dirty checking a mutable one by traversal.

I do understand that this is the point of view of an application developer. When writing library code that will be reused by many different projects, like Pete Hunt working the core of React (JS Library), performance can be the apex.

I'll take my own stab at this to give an example of what I'm looking for:

This may be obvious: Don't Repeat Yourself. If you find yourself writing very similar pieces of code numerous times in a row, it's a common performance enhancement to abstract that code into a function that can accept parameters and vary it's output. As a general rule: less code == better performance.

Pass necessary objects into functions, rather than relying on higher-scoped variables. If variables are passed as parameters into a function, it saves the JS engine from having to do a scope lookup.

Utilize native and built in features and methods whenever possible. Example: native looping methods are faster than 3rd party looping methods, any day of the week. Anytime you're using a method that someone built to replicate a feature that is native to JS, that 3rd party method will be slower.

Bonus Client-side only strategy (thanks for catching this, Pete Hunt):
Modify the DOM all at once, and as infrequently as possible. Everytime the DOM is modified, the browser halts the rendering of the page. This can make the page feel slow -- especially if there's animation happening.