# 10 Commandments for Efficient CSS Architecture 

1. Keep File Sizes Small

 Thy height shalt remain greater than thy file sizes at all times

  - It helps keeping things modular.
  - Important for faster search in future because you know where things are when something needs to be changed.

2. Use Variables

  - Less error prone
  - Easy extensibility.

3. Component Abstraction

4. Keep Selector Strengths Low
5. Naming Convention

  - Block - .component
  - Element - .component__sub-part
  - Modifier - .component--variation
6. z-index Management
7. @extend - Avoid Selector Hell

<https://www.youtube.com/watch?v=FYcu-wWrNqo&list=PLUS3uVC08ZaqVEGFkl_dS_3FUzILkOIzA>