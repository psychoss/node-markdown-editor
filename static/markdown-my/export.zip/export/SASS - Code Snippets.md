# SASS - Code Snippets

### @extend Wrapper a.k.a Mixtend

When extending a selector with the  `@extend`  directive, Sass doesn’t take the CSS content from the extended selector to put it in the extending one. It works the other way around. It takes the extending selector and append it to the extended one.

Because of how it works, it makes it impossible to use it from different scopes. For instance, you can’t extend a placeholder that has been declared in a  `@media`  block, nor can you extend a placeholder from root if you’re within a  `@media`  directive.

Surely we can find a way to use  `@extend`  when possible, mixin otherwise. Indeed, it's doable but it's a bit tricky, I call this the mixtend hack. You might want to think twice before implementing everywhere in your project. Perhaps using mixins only would be easier. I'll leave you the judge of that.

#### Wrapping `@extend` 

The idea is actually quite simple to grasp. First we define the mixin. The only parameter is $extend, which defines whether or not the mixin should try extending rather than including. Obviously, it is a boolean (default to true).

If $extend is true, we extend a placeholder named after the mixin (unfortunately, this is not automagically computed). If it's false, we dump the CSS code as a regular mixin would do.

Out of the mixin, we define the aforementioned placeholder. To avoid repeating the CSS code in the placeholder, we only have to include the mixin by setting $extend to false so it dumps the CSS code in the placeholder’s core.

```
/// *Mixtend* hack
/// @author Hugo Giraudel
@mixin mixtend-boilerplate($extend: true) {
  @if $extend {
    @extend %mixtend-boilerplate-placeholder;
  } @else {
    // Mixtend content
  }
}

%mixtend-boilerplate-placeholder {
  @include mixtend-boilerplate($extend: false);
}
```

#### Example

As a simple example, we will use the micro-clearfix from Nicolas Gallagher.

```
@mixin clearfix($extend: true) {
  @if $extend {
    @extend %clearfix;
  } @else {
    &:after {
      content: '';
      display: table;
      clear: both;
    }
  }
}

%clearfix {
  @include clearfix($extend: false);
}
```

Using it is quite straightforward:

```
.a { @include clearfix; }
.b { @include clearfix; }

@media (min-width: 48em) {
  .c {
    @include clearfix(false);
  }
}
```

Result CSS:

```
.a:after, .b:after {
  content: '';
  display: table;
  clear: both;
}

@media (min-width: 48em) {
  .c:after {
    content: '';
    display: table;
    clear: both;
  }
}
```

#### Sublime Text Snippet

If you want to save the boilerplate in order to make it highly reusable, you will be pleased to know that it is very easy to create a Sublime Text snippet for this. In Sublime, head to Tools > New snippet... and paste the content below.

Feel free to change the  `<tabTrigger>`  key to put whatever floats your boat; it is the word to type before hitting tab to expand the snippet. I went with mixtend.

```
<snippet>
    <content><![CDATA[
@mixin ${1:mixtend}(\$extend: true) {
  @if $extend {
    @extend %${1:mixtend};
  } @else {
    ${2}
  }
}

%${1:mixtend} {
  @include ${1:mixtend}(\$extend: false);
}
]]></content>
    <tabTrigger>mixtend</tabTrigger>
    <scope>source.scss</scope>
</snippet>
```
### Advanced Type Checking

This collection of functions is for testing if the value of a variable is of a certain type. For instance, is 13rem a relative length? TRUE! Is "frosty the snowman" and integer? FALSE!

This is likely most useful for advanced mixin and framework creators who aim to make their code more fault tolerant.



```
////
// A collection of function for advanced type checking
// @author Hugo Giraudel
////

@function is-number($value) {
  @return type-of($value) == 'number';
}
 
@function is-time($value) {
  @return is-number($value) and index('ms' 's', unit($value)) != null;
}
 
@function is-duration($value) {
  @return is-time($value);
}
 
@function is-angle($value) {
  @return is-number($value) and index('deg' 'rad' 'grad' 'turn', unit($value)) != null;
}
 
@function is-frequency($value) {
  @return is-number($value) and index('Hz' 'kHz', unit($value)) != null;
}
 
@function is-integer($value) {
  @return is-number($value) and round($value) == $value;
}
 
@function is-relative-length($value) {
  @return is-number($value) and index('em' 'ex' 'ch' 'rem' 'vw' 'vh' 'vmin' 'vmax', unit($value)) != null;
}
 
@function is-absolute-length($value) {
  @return is-number($value) and index('cm' 'mm' 'in' 'px' 'pt' 'pc', unit($value)) != null;
}
 
@function is-percentage($value) {
  @return is-number($value) and unit($value) == '%';
}
 
@function is-length($value) {
  @return is-relative-length($value) or is-absolute-length($value);
}
 
@function is-resolution($value) {
  @return is-number($value) and index('dpi' 'dpcm' 'dppx', unit($value)) != null;
}
 
@function is-position($value) {
  @return is-length($value) or is-percentage($value) or index('top' 'right' 'bottom' 'left' 'center', $value) != null;
}
```

### BEM


```
/* === USAGE ===
.block {
    @include element('element') {
    }
    @include modifier('modifier') {
        @include element('element') {
        }
    }
}
*/

@mixin element($element) {
	&__#{$element} {
		@content;
	}
}

@mixin modifier($modifier) {
	&--#{$modifier} {
		@content;
	}
}
```
### Black and White Opacity Function


```
/* === USAGE ===

.half-black {
  background: black(0.5);
}
*/
@function black($opacity) {
  @return rgba(black, $opacity)
}
@function white($opacity) {
  @return rgba(white, $opacity)
}

```
### Centering

```
@mixin centerer {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
```