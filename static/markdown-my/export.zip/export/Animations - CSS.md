# Animations - CSS

<table responsive="true">
<tbody><tr><th>Property</th><th>Description</th></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772747(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">@keyframes</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a list of property animation keyframes for an object in the HTML document.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772212(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">animation</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies shorthand values  that define animation properties for object properties  identified in the <a href="https://msdn.microsoft.com/en-us/library/hh772747(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">@keyframes</strong></a> at-rule of the <a href="https://msdn.microsoft.com/en-us/library/hh772236(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">animations-name</strong></a> property. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772215(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">animation-delay</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the offset within an animation cycle (the amount of time from the start of a cycle) before  the animation  is displayed  for a set of corresponding object properties  identified in the CSS&nbsp;<a href="https://msdn.microsoft.com/en-us/library/hh772747(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">@keyframes</strong></a> at-rule specified by the <a href="https://msdn.microsoft.com/en-us/library/hh772236(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">animation-name</strong></a> property.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772217(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">animation-direction</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the direction of play for an animation cycle. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772219(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">animation-duration</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the length of time to complete one cycle of the animation.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772232(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">animation-fill-mode</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies whether the effects of an animation are visible before or after it plays.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772233(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">animation-iteration-count</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the number of times an animation cycle is played. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772236(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">animation-name</strong></a>
</p>
</td><td data-th="Description">
<p>Identifies one or more animation names. An animation name selects a  CSS&nbsp;<a href="https://msdn.microsoft.com/en-us/library/hh772747(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">@keyframes</strong></a> at-rule.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772238(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">animation-play-state</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies whether an animation is playing or paused. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772240(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">animation-timing-function</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the intermediate property values to be used during a single cycle of an animation on a set of corresponding object properties  identified in the CSS&nbsp;<a href="https://msdn.microsoft.com/en-us/library/hh772747(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">@keyframes</strong></a> at-rule specified by the <a href="https://msdn.microsoft.com/en-us/library/hh772236(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">animation-name</strong></a> property.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772376(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">CSSKeyframeRule</strong></a>
</p>
</td><td data-th="Description">
<p>Represents the style rule for a single key.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772382(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">CSSKeyframesRule</strong></a>
</p>
</td><td data-th="Description">
<p>Represents a complete set of keyframes for a single animation.</p>
</td></tr>
</tbody></table>