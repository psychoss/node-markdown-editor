# SQLite Full text search: Find rows that countains any of keywords

I have following tables:

```
-- table to keep articles titles
CREATE TABLE articles(id, title);
insert into articles (id,title) values (1,'sqlite example');
insert into articles (id,title) values (2,'sqlite query ');
insert into articles (id,title) values (3,'erlang example ');
insert into articles (id,title) values (3,'erlang otp ');

-- table to keep keywords that we would like to search.
create table keywords(id,keyword);
insert into keywords (id,keyword) values  (1,'sqlite');
insert into keywords (id,keyword) values  (2,'otp');


-- full text search table - copy of articles.

create virtual table articles_fts using fts4 (id,name);

-- populate table with articles titles.
insert into articles_fts(id,name) select id,title from articles;
```

Now I would like to find ALL articles that contains any of specified keywords.

Query like:

```
select * from articles_fts 
  where name match (select keyword from keywords);
```

returns only titles with sqlite in it (first keyword), so the other entries of keywords table are ignored.

Question: How could I find all articles that contains any of specified keywords? Thanks.

---

Use

```
select *
  from articles_fts
 WHERE articles_fts MATCH ( select group_concat(keyword, ' OR ')
                              from keywords
                             group by 'x' )
```

The group_concat function aggregates all keywords with a comma. If you replace commas with OR, it should produce a good FTS query.

Also see section 3 of [the full text search feature reference](http://www.sqlite.org/fts3.html) regarding the OR keyword and the [reference for aggregate functions](http://www.sqlite.org/lang_aggfunc.html).