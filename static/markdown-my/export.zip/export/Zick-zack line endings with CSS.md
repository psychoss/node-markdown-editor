# Zick-zack line endings with CSS


```
p {
  box-decoration-break: clone;
	display: inline;
  line-height: 2em;
  padding: .3em 1.5em .3em .5em;    
  font-family: sans-serif;
  background-image:
    linear-gradient(
      115deg,
      rgba(0,0,0,.1) calc(100% - 1em),
      transparent calc(100% - 1em)
    );
}



body {
	margin: 10% 20%;
	
  $background-color-1: #b9bc37;
  $background-color-2: #b1b435;

	/* Thanks @LeaVerou: http://lea.verou.me/css3patterns/#hearts */
  background:
		radial-gradient(circle closest-side at 60% 43%, $background-color-1 26%, rgba($background-color-1, 0) 27%),
		radial-gradient(circle closest-side at 40% 43%, $background-color-1 26%, rgba($background-color-1, 0) 27%),
		radial-gradient(circle closest-side at 40% 22%, $background-color-2 45%, rgba($background-color-2, 0) 46%),
		radial-gradient(circle closest-side at 60% 22%, $background-color-2 45%, rgba($background-color-2, 0) 46%),
		radial-gradient(circle closest-side at 50% 35%, $background-color-2 30%, rgba($background-color-2, 0) 31%),

		radial-gradient(circle closest-side at 60% 43%, $background-color-1 26%, rgba($background-color-1, 0) 27%) 50px 50px,
		radial-gradient(circle closest-side at 40% 43%, $background-color-1 26%, rgba($background-color-1, 0) 27%) 50px 50px,
		radial-gradient(circle closest-side at 40% 22%, $background-color-2 45%, rgba($background-color-2, 0) 46%) 50px 50px,
		radial-gradient(circle closest-side at 60% 22%, $background-color-2 45%, rgba($background-color-2, 0) 46%) 50px 50px,
		radial-gradient(circle closest-side at 50% 35%, $background-color-2 30%, rgba($background-color-2, 0) 31%) 50px 50px;
	background-color: $background-color-1;
	background-size: 100px 100px;
}

```

```
<article>
  <p>
    Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, 
  </p>
</article>
```