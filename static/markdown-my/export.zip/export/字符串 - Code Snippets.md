# 字符串 - Code Snippets


- String.concat

  连接字符串。