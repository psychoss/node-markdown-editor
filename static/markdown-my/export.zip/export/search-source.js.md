search-source.js

search-source
=============

#### Reactive Data Source for building search solutions with Meteor

If you are new to search source, it's a good idea to look at this introductory [article](https://meteorhacks.com/implementing-an-instant-search-solution-with-meteor.html) on MeteorHacks.

## Installation

```
meteor add meteorhacks:search-source
```

### Creating a source in client

```js
var options = {
  keepHistory: 1000 * 60 * 5,
  localSearch: true
};
var fields = ['packageName', 'description'];

PackageSearch = new SearchSource('packages', fields, options);
```

* First parameter for the source is the name of the source itself. You need to use it for defining the data source on the server.
* second arguments is the number of fields to search on the client (used for client side search and text transformation)
* set of options. Here are they
    * `keepHistory` - cache the search data locally. You need to give an expire time(in millis) to cache it on the client. Caching is done based on the search term. Then if you search again for that term, it search source won't ask the server to get data again.
    * `localSearch` - allow to search locally with the data it has.

### Define the data source on the server

In the server, get data from any backend and send those data to the client as shown below. You need to return an array of documents where each of those object consists of `_id` field.

> Just like inside a method, you can use `Meteor.userId()` and `Meteor.user()` inside a source definition.

```js
SearchSource.defineSource('packages', function(searchText, options) {
  var options = {sort: {isoScore: -1}, limit: 20};

  if(searchText) {
    var regExp = buildRegExp(searchText);
    var selector = {packageName: regExp, description: regExp};
    return Packages.find(selector, options).fetch();
  } else {
    return Packages.find({}, options).fetch();
  }
});

function buildRegExp(searchText) {
  var words = searchText.trim().split(/[ \-\:]+/);
  var exps = _.map(words, function(word) {
    return "(?=.*" + word + ")";
  });
  var fullExp = exps.join('') + ".+";
  return new RegExp(fullExp, "i");
}
```

### Get the reactive data source

You can get the reactive data source with the `PackageSearch.getData` api. This is an example usage of that:

```js
Template.searchResult.helpers({
  getPackages: function() {
    return PackageSearch.getData({
      transform: function(matchText, regExp) {
        return matchText.replace(regExp, "<b>$&</b>")
      },
      sort: {isoScore: -1}
    });
  }
});
```

`.getData()` api accepts an object with options (and an optional argument to ask for a cursor instead of a fetched array; see example below). These are the options you can pass:

* `transform` - a transform function to alter the selected search texts. See above for an example usage.
* `sort` - an object with MongoDB sort specifiers
* `limit` - no of objects to limit
* `docTransform` - a transform function to transform the documents in the search result. Use this for computed values or model helpers. (see example below)


```js
Template.searchResult.helpers({
  getPackages: function() {
    return PackageSearch.getData({
      docTransform: function(doc) {
        return _.extend(doc, {
          owner: function() {
            return Meteor.users.find({_id: this.ownerId})
          }
        })
      },
      sort: {isoScore: -1}
    }, true);
  }
});
```

### Searching

Finally we can invoke search queries by invoking following API.

```js
PackageSearch.search("the text to search");
```

### Status

You can get the status of the search source by invoking following API. It's reactive too.

```
var status = PackageSearch.getStatus();
```

Status has following fields depending on the status.

* loading - indicator when loading
* loaded - indicator after loaded
* error - the error object, mostly if backend data source throws an error

### Metadata

With metadata, you get some useful information about search along with the search results. These metadata can be time it takes to process the search or the number of results for this search term.

You can get the metadata with following API. It's reactive too.

```js
var metadata = PackageSearch.getMetadata();
```

Now we need a way to send metadata to the client. This is how we can do it. You need to change the server side search source as follows

```js
SearchSource.defineSource('packages', function(searchText, options) {
  var data = getSearchResult(searchText);
  var metadata = getMetadata();

  return {
    data: data,
    metadata: metadata
  }
});
```

### Passing Options with Search

We can also pass some options while searching. This is the way we can implement pagination and other extra functionality.

Let's pass some options to the server:

```js
// In the client
var options = {page: 10};
PackageSearch.search("the text to search", options);
```

Now you can get the options object from the server. See:

```js
// In the server
SearchSource.defineSource('packages', function(searchText, options) {
  // do anything with options
  console.log(options); // {"page": 10}
});
```

### Get Current Search Query

You can get the current search query with following API. It's reactive too.

```js
var searchText = PackageSearch.getCurrentQuery();
```

### Clean History

You can clear the stored history (if enabled the `keepHistory` option) via the following API.

```js
PackageSearch.cleanHistory();
```

### Defining Data Source in the Client

Sometime, we don't need to fetch data from the server. We need to get it from a data source aleady available on the client. So, this is how we do it:

```js
PackageSearch.fetchData = function(searchText, options, success) {
  SomeOtherDDPConnection.call('getPackages', searchText, options, function(err, data) {
    success(err, data);
  });
};
```

```
SearchSource = {};
SearchSource._sources = {};
var bodyParser = Npm.require('body-parser');

SearchSource.defineSource = function(name, callback) {
  SearchSource._sources[name] = callback;
};

Meteor.methods({
  "search.source": function(name, query, options) {
    check(name, String);
    check(query, Match.OneOf(String, null, undefined));
    check(options, Match.OneOf(Object, null, undefined));
    this.unblock();

    // we need to send the context of the method
    // that's why we use .call instead just invoking the function
    return getSourceData.call(this, name, query, options);
  }
});

var postRoutes = Picker.filter(function(req, res) {
  return req.method == "POST";
});

postRoutes.middleware(bodyParser.text({
  type: "text/ejson"
}));

postRoutes.route('/_search-source', function(params, req, res, next) {
  if(req.body) {
    var payload = EJSON.parse(req.body);
    try {
      // supporting the use of Meteor.userId()
      var data = DDP._CurrentInvocation.withValue({userId: null}, function() {
        return getSourceData(payload.source, payload.query, payload.options);
      });
      sendData(res, null, data);
    } catch(ex) {
      if(ex instanceof Meteor.Error) {
        var error = { code: ex.error, message: ex.reason };
      } else {
        var error = { message: ex.message };
      }
      sendData(res, error);
    }
  } else {
    next();
  }
});


function sendData(res, err, data) {
  var payload = {
    error: err,
    data: data
  };

  res.end(EJSON.stringify(payload));
}

function getSourceData(name, query, options) {
  var source = SearchSource._sources[name];
  if(source) {
    return source.call(this, query, options);
  } else {
    throw new Meteor.Error(404, "No such search source: " + name);
  }
}
```

```
SearchSource = function SearchSource(source, fields, options) {
  this.source = source;
  this.searchFields = fields;
  this.currentQuery = null;
  this.options = options || {};

  this.status =  new ReactiveVar({loaded: true});
  this.metaData = new ReactiveVar({});
  this.history = {};
  this.store = new Mongo.Collection(null);

  this._storeDep = new Tracker.Dependency();
  this._currentQueryDep = new Tracker.Dependency();
  this._currentVersion = 0;
  this._loadedVersion = 0;
}

SearchSource.prototype._loadData = function(query, options) {
  var self = this;
  var version = 0;
  var historyKey = query + EJSON.stringify(options);
  if(this._canUseHistory(historyKey)) {
    this._updateStore(this.history[historyKey].data);
    this.metaData.set(this.history[historyKey].metadata);
    self._storeDep.changed();
  } else {
    this.status.set({loading: true});
    version = ++this._currentVersion;
    this._fetch(this.source, query, options, handleData);
  }

  function handleData(err, payload) {
    if(err) {
      self.status.set({error: err});
      throw err;
    } else {
      if(payload instanceof Array) {
        var data = payload;
        var metadata = {};
      } else {
        var data = payload.data;
        var metadata = payload.metadata;
        self.metaData.set(payload.metadata || {});
      }

      if(self.options.keepHistory) {
        self.history[historyKey] = {data: data, loaded: new Date(), metadata: metadata};
      }

      if(version > self._loadedVersion) {
        self._updateStore(data);
        self._loadedVersion = version;
      }

      if(version == self._currentVersion) {
        self.status.set({loaded: true});
      }

      self._storeDep.changed();
    }
  }
};

SearchSource.prototype._canUseHistory = function(historyKey) {
  var historyItem = this.history[historyKey];
  if(this.options.keepHistory && historyItem) {
    var diff = Date.now() - historyItem.loaded.getTime();
    return diff < this.options.keepHistory;
  }

  return false;
};

SearchSource.prototype._updateStore = function(data) {
  var self = this;
  var storeIds = _.pluck(this.store.find().fetch(), "_id");
  var currentIds = [];
  data.forEach(function(item) {
    currentIds.push(item._id);
    self.store.update(item._id, item, {upsert: true});
  });

  // Remove items in client DB that we no longer need
  var currentIdMappings  = {};
  _.each(currentIds, function(currentId) {
    // to support Object Ids
    var str = (currentId._str)? currentId._str : currentId;
    currentIdMappings[str] = true;
  });

  _.each(storeIds, function(storeId) {
    // to support Object Ids
    var str = (storeId._str)? storeId._str : storeId;
    if(!currentIdMappings[str]) {
      self.store.remove(storeId);
    }
  });
};

SearchSource.prototype.search = function(query, options) {
  this.currentQuery = query;
  this._currentQueryDep.changed();

  this._loadData(query, options);

  if(this.options.localSearch) {
    this._storeDep.changed();
  }
};

SearchSource.prototype.getData = function(options, getCursor) {
  options = options || {};
  var self = this;
  this._storeDep.depend();
  var selector = {$or: []};

  var regExp = this._buildRegExp(self.currentQuery);

  // only do client side searching if we are on the loading state
  // once loaded, we need to send all of them
  if(this.getStatus().loading) {
    self.searchFields.forEach(function(field) {
      var singleQuery = {};
      singleQuery[field] = regExp;
      selector['$or'].push(singleQuery);
    });
  } else {
    selector = {};
  }

  function transform(doc) {
    if(options.transform) {
      self.searchFields.forEach(function(field) {
        if(self.currentQuery && doc[field]) {
          doc[field] = options.transform(doc[field], regExp, field, self.currentQuery);
        }
      });
    }
    if(options.docTransform) {
      return options.docTransform(doc);
    }

    return doc;
  }

  var cursor = this.store.find(selector, {
    sort: options.sort,
    limit: options.limit,
    transform: transform
  });

  if(getCursor) {
    return cursor;
  }

  return cursor.fetch();
};

SearchSource.prototype._fetch = function(source, query, options, callback) {
  if(typeof this.fetchData == 'function') {
    this.fetchData(query, options, callback);
  } else if(Meteor.status().connected) {
    this._fetchDDP.apply(this, arguments);
  } else {
    this._fetchHttp.apply(this, arguments);
  }
};

SearchSource.prototype._fetchDDP = function(source, query, options, callback) {
  Meteor.call("search.source", this.source, query, options, callback);
};

SearchSource.prototype._fetchHttp = function(source, query, options, callback) {
  var payload = {
    source: source,
    query: query,
    options: options
  };

  var headers = {
    "Content-Type": "text/ejson"
  };

  HTTP.post('/_search-source', {
    content: EJSON.stringify(payload),
    headers: headers
  }, function(err, res) {
    if(err) {
      callback(err);
    } else {
      var response = EJSON.parse(res.content);
      if(response.error) {
        callback(response.error);
      } else {
        callback(null, response.data);
      }
    }
  });
};

SearchSource.prototype.getMetadata = function() {
  return this.metaData.get();
};

SearchSource.prototype.getCurrentQuery = function() {
  this._currentQueryDep.depend();
  return this.currentQuery;
}

SearchSource.prototype.getStatus = function() {
  return this.status.get();
};

SearchSource.prototype.cleanHistory = function() {
  this.history = {};
};

SearchSource.prototype._buildRegExp = function(query) {
  query = query || "";

  var afterFilteredRegExpChars = query.replace(this._getRegExpFilterRegExp(), "\\$&");
  var parts = afterFilteredRegExpChars.trim().split(' ');

  return new RegExp("(" + parts.join('|') + ")", "ig");
};

SearchSource.prototype._getRegExpFilterRegExp = _.once(function() {
  var regExpChars = [
    "\\", "^", "$", "*", "+", "?", ".",
     "(", ")", ":", "|", "{", "}", "[", "]",
     "=", "!", ","
  ];
  var regExpCharsReplace = _.map(regExpChars, function(c) {
    return "\\" + c;
  }).join("|");
  return new RegExp("(" + regExpCharsReplace + ")", "g");
});
```