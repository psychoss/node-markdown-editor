# location object - DOM

## Methods

<table id="memberListMethods" class="members" responsive="true">
<tbody><tr><th>Method</th><th>Description</th></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536342(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">assign</strong></a>
</td><td data-th="Description">
<p>Loads a new HTML document. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536691(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">reload</strong></a>
</td><td data-th="Description">
<p>Reloads the current document.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536712(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">replace</strong></a>
</td><td data-th="Description">
<p>Replaces the current document by loading another document at the specified URL.</p>
</td></tr>
</tbody></table>


## Properties

<table id="memberListProperties" class="members" responsive="true">
<tbody><tr><th>Property</th><th>Access type</th><th>Description</th></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533775(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">hash</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or retrieves the subsection of the <a href="https://msdn.microsoft.com/en-us/library/cc848861(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">href</strong></a> property that follows the number sign (#).</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533784(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">host</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or retrieves the <a href="https://msdn.microsoft.com/en-us/library/ms533785(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">hostname</strong></a> and <a href="https://msdn.microsoft.com/en-us/library/ms534342(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">port</strong></a> number of the location or URL.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533785(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">hostname</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or retrieves the host name part of the location or URL. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533867(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">href</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or retrieves the entire URL as a string. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/dn760719(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">origin</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read-only</td><td data-th="Description">
<p>Returns the URL underlying the current webpage, including protocol scheme, domain, and port number (if any).</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534332(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pathname</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or retrieves the file name or path specified by the object. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534342(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">port</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or retrieves the port number associated with a URL.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534353(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">protocol</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or retrieves the protocol portion of a URL. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534620(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">search</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or retrieves the substring of the <a href="https://msdn.microsoft.com/en-us/library/ms533867(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">href</strong></a> property that follows the question mark. </p>
</td></tr>
</tbody></table>