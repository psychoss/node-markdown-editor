# Critical rendering path

* [Constructing the Object Model](https://developers.google.com/web/fundamentals/performance/critical-rendering-path/constructing-the-object-model?hl=en)
* [Render-tree construction, layout, and paint](https://developers.google.com/web/fundamentals/performance/critical-rendering-path/render-tree-construction?hl=en)
* [Render blocking CSS](https://developers.google.com/web/fundamentals/performance/critical-rendering-path/render-blocking-css?hl=en)
* [Adding interactivity with JavaScript](https://developers.google.com/web/fundamentals/performance/critical-rendering-path/adding-interactivity-with-javascript?hl=en)
* [Measuring the critical rendering path with Navigation Timing](https://developers.google.com/web/fundamentals/performance/critical-rendering-path/measure-crp?hl=en)
* [Analyzing critical rendering path performance](https://developers.google.com/web/fundamentals/performance/critical-rendering-path/analyzing-crp?hl=en)
* [Optimizing the critical rendering path](https://developers.google.com/web/fundamentals/performance/critical-rendering-path/optimizing-critical-rendering-path?hl=en)
* [PageSpeed rules and recommendations](https://developers.google.com/web/fundamentals/performance/critical-rendering-path/page-speed-rules-and-recommendations?hl=en)