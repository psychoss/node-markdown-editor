# window object - DOM

## Events

<table id="memberListEvents" class="members" responsive="true">
<tbody><tr><th>Event</th><th>Description</th></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536913(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml"> click</strong></a>
</td><td data-th="Description">
<p>Fires when the user clicks the left mouse button on the object. </p>
<div class="alert"><strong>Note</strong>&nbsp;&nbsp;Starting with IE11, this event fires a <a href="https://msdn.microsoft.com/en-us/library/hh772103(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">MSPointerEvent</strong></a> object instead of  <a href="https://msdn.microsoft.com/en-us/library/ff974344(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">MouseEvent</strong></a>. You can use the MouseEvent.<a href="https://msdn.microsoft.com/en-us/library/hh772359(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerType</strong></a> property to determine the type of contact that the click originated from (touch, mouse, or pen).</div>
<div>&nbsp;</div>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536785(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">abort</strong></a>
</td><td data-th="Description">
<p>Fires when the user aborts the download. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536788(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">afterprint</strong></a>
</td><td data-th="Description">
<p>Fires on the object immediately after its associated document prints or previews for printing. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536906(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">beforeprint</strong></a>
</td><td data-th="Description">
<p>Fires on the object before its associated document prints or previews for printing. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536907(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">beforeunload</strong></a>
</td><td data-th="Description">
<p>Fires prior to a document being unloaded. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536909(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">blur</strong></a>
</td><td data-th="Description">
<p>Fires when the object loses the input focus. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974144(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">canplay</strong></a>
</td><td data-th="Description">
<p>Occurs when playback is possible, but would require further buffering. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974147(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">canplaythrough</strong></a>
</td><td data-th="Description">
<p>Occurs when playback to end is possible without requiring a stop for further buffering. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536912(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">change</strong></a>
</td><td data-th="Description">
<p>Fires when the contents of the object or selection have changed. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/dn629487(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">compassneedscalibration</strong></a>
</td><td data-th="Description">
<p>Fires whenever the device magnetometer changes to a state of unreliable or approximate accuracy.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536914(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">contextmenu</strong></a>
</td><td data-th="Description">
<p>Fires when the user clicks the right mouse button in the client area, opening the context menu. </p>
<div class="alert"><strong>Note</strong>&nbsp;&nbsp;Starting with IE11, this event fires a <a href="https://msdn.microsoft.com/en-us/library/hh772103(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">MSPointerEvent</strong></a> object instead of <a href="https://msdn.microsoft.com/en-us/library/ff974344(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">MouseEvent</strong></a>. You can use the MouseEvent.<a href="https://msdn.microsoft.com/en-us/library/hh772359(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerType</strong></a> property to determine the type of contact that the click originated from (touch, mouse, or pen).</div>
<div>&nbsp;</div>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536921(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">dblclick</strong></a>
</td><td data-th="Description">
<p>Fires when the user double-clicks the object. </p>
<div class="alert"><strong>Note</strong>&nbsp;&nbsp;Starting with IE11, this event fires a <a href="https://msdn.microsoft.com/en-us/library/hh772103(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">MSPointerEvent</strong></a> object instead of a <a href="https://msdn.microsoft.com/en-us/library/ff974344(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">MouseEvent</strong></a>. You can use the MouseEvent.<a href="https://msdn.microsoft.com/en-us/library/hh772359(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerType</strong></a> property to determine the type of contact that the click originated from (touch, mouse, or pen).</div>
<div>&nbsp;</div>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536923(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">drag</strong></a>
</td><td data-th="Description">
<p>Fires on the source object continuously during a drag operation.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536924(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">dragend</strong></a>
</td><td data-th="Description">
<p>Fires on the source object when the user releases the mouse at the close of a drag operation.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536925(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">dragenter</strong></a>
</td><td data-th="Description">
<p>Fires on the target element when the user drags the object to a valid drop target.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536926(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">dragleave</strong></a>
</td><td data-th="Description">
<p>Fires on the target object when the user moves the mouse out of a valid drop target during a drag operation.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536927(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">dragover</strong></a>
</td><td data-th="Description">
<p>Fires on the target element continuously while the user drags the object over a valid drop target.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536928(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">dragstart</strong></a>
</td><td data-th="Description">
<p>Fires on the source object when the user starts to drag a text selection or selected object. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536929(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">drop</strong></a>
</td><td data-th="Description">
<p>Fires on the target object when the mouse button is released during a drag-and-drop operation.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974149(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">durationchange</strong></a>
</td><td data-th="Description">
<p>Occurs when the <a href="https://msdn.microsoft.com/en-us/library/ff974750(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">duration</strong></a> attribute is updated. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974151(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">emptied</strong></a>
</td><td data-th="Description">
<p>Occurs when the media element is reset to its initial state. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974154(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">ended</strong></a>
</td><td data-th="Description">
<p>Occurs when the end of playback is reached. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/cc197053(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">error</strong></a>
</td><td data-th="Description">
<p>Fires when an error occurs during object loading.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536934(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">focus</strong></a>
</td><td data-th="Description">
<p>Fires when the object receives focus. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536935(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">focusin</strong></a>
</td><td data-th="Description">
<p>Fires for an element just prior to setting focus on that element.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536936(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">focusout</strong></a>
</td><td data-th="Description">
<p>Fires for the current element with focus immediately after moving focus to another element. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/dn743642(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">gamepadconnected</strong></a>
</td><td data-th="Description">
<p>Fires when a gamepad device is connected or activated.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/dn743643(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">gamepaddisconnected</strong></a>
</td><td data-th="Description">
<p>Fired when a gamepad device is disconnected.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/hh771904(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">gotpointercapture</strong></a>
</td><td data-th="Description">
<p>Dispatched prior to the dispatch of the first event after pointer capture is set for a pointer. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/cc288209(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">hashchange</strong></a>
</td><td data-th="Description">
<p>Raised when there are changes to the portion of a
      URL that follows the number sign (#).
    </p>
<p>This event is not supported for Windows Store apps using JavaScript.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536937(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">help</strong></a>
</td><td data-th="Description">
<p>Fires when the user presses the F1 key while the client is the active window. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/gg592978(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">input</strong></a>
</td><td data-th="Description">
<p>Occurs when the text content of an element is changed through the user interface. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536938(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">keydown</strong></a>
</td><td data-th="Description">
<p>Fires when the user presses a key.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536939(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">keypress</strong></a>
</td><td data-th="Description">
<p>Fires when the user presses an alphanumeric key.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/cc197055(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">load</strong></a>
</td><td data-th="Description">
<p>Fires immediately after the client loads the object. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974155(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">loadeddata</strong></a>
</td><td data-th="Description">
<p>Occurs when media data is loaded at the current playback position. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974157(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">loadedmetadata</strong></a>
</td><td data-th="Description">
<p>Occurs when the duration and dimensions of the media have been determined. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974159(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">loadstart</strong></a>
</td><td data-th="Description">
<p>Occurs when Internet Explorer begins looking for media data. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/hh771907(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">lostpointercapture</strong></a>
</td><td data-th="Description">
<p>Dispatched after pointer capture is released for a pointer. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/cc197057(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">message</strong></a>
</td><td data-th="Description">
<p>Fires when the user sends a cross-document message or a message is sent from a <a href="https://msdn.microsoft.com/en-us/library/hh772809(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">Worker</strong></a> with <a href="https://msdn.microsoft.com/en-us/library/cc197015(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">postMessage</strong></a>.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536944(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">mousedown</strong></a>
</td><td data-th="Description">
<p>Fires when the user clicks the object with either mouse button. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536947(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">mousemove</strong></a>
</td><td data-th="Description">
<p>Fires when the user moves the mouse over the object. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536948(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">mouseout</strong></a>
</td><td data-th="Description">
<p>Fires when the user moves the mouse pointer outside the boundaries of the object. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536949(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">mouseover</strong></a>
</td><td data-th="Description">
<p>Fires when the user moves the mouse pointer into the object. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536950(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">mouseup</strong></a>
</td><td data-th="Description">
<p>Fires when the user releases a mouse button while the mouse is over the object. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536951(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">mousewheel</strong></a>
</td><td data-th="Description">
<p>Fires when the wheel button is rotated. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/hh771910(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">MSPointerHover</strong></a>
</td><td data-th="Description">
<p>Event that is triggered when a contact (normally a pen) moves over an element without touching the surface. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/cc304126(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">offline</strong></a>
</td><td data-th="Description">
<p>Raised when Internet Explorer is working offline.</p>
<p>This event is not supported for Windows Store apps using JavaScript.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536903(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">onbeforedeactivate</strong></a>
</td><td data-th="Description">
<p>Fires immediately before the <a href="https://msdn.microsoft.com/en-us/library/ms533065(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">activeElement</strong></a> is changed from the current object to another object in the parent document.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536940(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">onkeyup</strong></a>
</td><td data-th="Description">
<p>Fires when the user releases a key.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/cc304127(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">online</strong></a>
</td><td data-th="Description">
<p>Raised when Internet Explorer is working online.</p>
<p>This event is not supported for Windows Store apps using JavaScript.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536967(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">onselect</strong></a>
</td><td data-th="Description">
<p>Fires when the current selection changes.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/dn792851(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">ontouchcancel</strong></a>
</td><td data-th="Description">
<p>Event indicating that the touch point has been canceled/disrupted.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/dn792852(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">ontouchend</strong></a>
</td><td data-th="Description">
<p>Event indicating that the touch point has ceased to exist.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/dn792853(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">ontouchmove</strong></a>
</td><td data-th="Description">
<p>Event indicating that the touch point has moved along the touch surface.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/dn792854(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">ontouchstart</strong></a>
</td><td data-th="Description">
<p>Event indicating that the user has touched the surface of a touch capable device.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/dn760723(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">orientationchange</strong></a>
</td><td data-th="Description">
<p>Fires when the device is rotated.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974160(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pause</strong></a>
</td><td data-th="Description">
<p>Occurs when playback is paused. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974163(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">play</strong></a>
</td><td data-th="Description">
<p>Occurs when the <a href="https://msdn.microsoft.com/en-us/library/ff975194(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">play</strong></a> method is requested. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974166(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">playing</strong></a>
</td><td data-th="Description">
<p>Occurs when the audio or video has started playing. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/hh846776(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointercancel</strong></a>
</td><td data-th="Description">
<p> Dispatched when either (1) the system has determined that a pointer is unlikely to continue to produce events (for example, due to a hardware event), or (2) after having fired the <a href="https://msdn.microsoft.com/en-us/library/hh771909(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerdown</strong></a> event, the pointer is subsequently used to manipulate the page viewport (for example, panning or zooming). </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/hh771909(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerdown</strong></a>
</td><td data-th="Description">
<p>Dispatched when a pointer enters the state of having a non-zero value for the <a href="https://msdn.microsoft.com/en-us/library/ff974878(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">buttons</strong></a> property.  </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/dn254944(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerenter</strong></a>
</td><td data-th="Description">
<p>Dispatched when a pointing device is moved into the hit test boundaries of an element or one of its descendants, including as a result of a <a href="https://msdn.microsoft.com/en-us/library/hh771909(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerdown</strong></a> event from a device that does not support hover.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/dn254945(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerleave</strong></a>
</td><td data-th="Description">
<p>Dispatched when a pointing device is moved outside of the hit test boundaries of an element or one of its descendants, including as a result of a <a href="https://msdn.microsoft.com/en-us/library/hh771909(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerdown</strong></a> event from a device that does not support hover.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/hh771911(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointermove</strong></a>
</td><td data-th="Description">
<p>Dispatched when a pointer changes coordinates, button state, pressure, tilt, or contact geometry (for example, <a href="https://msdn.microsoft.com/en-us/library/dn255065(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">width</strong></a> and <a href="https://msdn.microsoft.com/en-us/library/dn255064(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">height</strong></a>). </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/hh771912(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerout</strong></a>
</td><td data-th="Description">
<p>Dispatched when any of the following occurs:</p>
<ul>
<li>A pointing device is moved out of the hit test boundaries of an element</li>
<li>After firing the <a href="https://msdn.microsoft.com/en-us/library/hh771914(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerup</strong></a> event for a device that does not support hover</li>
<li>After firing the <a href="https://msdn.microsoft.com/en-us/library/hh846776(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointercancel</strong></a> event</li>
</ul>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/hh771913(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerover</strong></a>
</td><td data-th="Description">
<p>Dispatched when a pointing device is moved into the hit test boundaries of an element. Also dispatched prior to a <a href="https://msdn.microsoft.com/en-us/library/hh771909(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerdown</strong></a> event for devices that do not support hover. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/hh771914(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerup</strong></a>
</td><td data-th="Description">
<p>Dispatched when a pointer leaves the state of having a non-zero value for the <a href="https://msdn.microsoft.com/en-us/library/ff974878(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">buttons</strong></a> property.

</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974168(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">progress</strong></a>
</td><td data-th="Description">
<p>Occurs to indicate progress while downloading media data. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974169(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">ratechange</strong></a>
</td><td data-th="Description">
<p>Occurs when the playback rate is increased or decreased. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536958(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">reset</strong></a>
</td><td data-th="Description">
<p>Fires when the user resets a form. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536966(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scroll</strong></a>
</td><td data-th="Description">
<p>Fires when the user repositions the scroll box in the scroll bar on the object. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974171(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">seeked</strong></a>
</td><td data-th="Description">
<p>Occurs when the seek operation ends. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974175(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">seeking</strong></a>
</td><td data-th="Description">
<p>Occurs when the current playback position is moved. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974179(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">stalled</strong></a>
</td><td data-th="Description">
<p>Occurs when the download has stopped. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/cc197059(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">storage</strong></a>
</td><td data-th="Description">
<p>Fires when a Web Storage area is updated.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974182(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">suspend</strong></a>
</td><td data-th="Description">
<p>Occurs if the load operation is  intentionally halted. Starting in Microsoft Edge, also occurs if the media network state becomes <strong>NETWORK_IDLE</strong>. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974185(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">timeupdate</strong></a>
</td><td data-th="Description">
<p>Occurs to indicate the current playback position.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536973(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">unload</strong></a>
</td><td data-th="Description">
<p>Fires immediately before the object is unloaded. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974188(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">volumechange</strong></a>
</td><td data-th="Description">
<p>Occurs when the volume is changed, or playback is muted or unmuted.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974190(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">waiting</strong></a>
</td><td data-th="Description">
<p>Occurs when playback stops because the next frame of a video resource is not available. </p>
</td></tr>
</tbody></table>


## Methods

<table id="memberListMethods" class="members" responsive="true">
<tbody><tr><th>Method</th><th>Description</th></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms535923(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">AddChannel</strong></a>
</td><td data-th="Description">
<p>Obsolete. Presents a dialog box that enables the user to add the specified channel, or to change the channel URL, if it is already installed.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975245(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">addEventListener</strong></a>
</td><td data-th="Description">
<p>Registers an event handler for the specified event type. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms535931(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">AddSearchProvider</strong></a>
</td><td data-th="Description">
<div class="alert"><strong>Warning</strong>&nbsp;&nbsp;This method has been deprecated since Internet Explorer&nbsp;8 and removed from Windows&nbsp;10.</div>
<div>&nbsp;</div>
<p>
<em>Deprecated.</em> Adds a search provider to the registry.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/cc197034(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">AddService</strong></a>
</td><td data-th="Description">
<p>Deprecated. User initiated action to add a service.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/cc289791(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">AddToFavoritesBar</strong></a>
</td><td data-th="Description">
<p>Deprecated. Adds
		a URL to the <strong>Favorites Bar</strong>.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms535933(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">alert</strong></a>
</td><td data-th="Description">
<p>Displays a dialog box containing an application-defined message.</p>
<p>
    This method is not supported for Windows Store apps using JavaScript.
  </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536343(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">attachEvent</strong></a>
</td><td data-th="Description">
<div class="alert"><strong>Note</strong>&nbsp;&nbsp;
<a href="https://msdn.microsoft.com/en-us/library/ms536343(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">attachEvent</strong></a>  is no longer supported. Starting with IE11, use <a href="https://msdn.microsoft.com/en-us/library/ff975245(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">addEventListener</strong></a>. For info, see <a href="https://msdn.microsoft.com/en-us/library/bg182625(v=vs.85).aspx">Compatibility changes</a>.</div>
<div>&nbsp;</div>
<p>Binds the specified function to an event, so that the function gets called whenever the event fires on the object.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536347(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">blur</strong></a>
</td><td data-th="Description">
<p>Causes the element to lose focus and fires the <a href="https://msdn.microsoft.com/en-us/library/ms536909(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">onblur</strong></a> event.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/aa744115(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">BrandImageUri</strong></a>
</td><td data-th="Description">
<p>Not supported. Retrieves the URI of an alternate product image.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/cc289792(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">BuildNewTabPage</strong></a>
</td><td data-th="Description">
<p>Not supported. Check user's settings to show tab list and/or activities list.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/dn469423(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">captureEvents </strong></a>
</td><td data-th="Description">
<p>No appreciable effect.  Do not use.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/hh924825(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">clearImmediate</strong></a>
</td><td data-th="Description">
<p>Cancels a function request created with <a href="https://msdn.microsoft.com/en-us/library/hh773176(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">setImmediate</strong></a>.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536353(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">clearInterval</strong></a>
</td><td data-th="Description">
<p>Cancels the interval previously started using the <a href="https://msdn.microsoft.com/en-us/library/ms536749(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">setInterval</strong></a> method. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536357(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">clearTimeout</strong></a>
</td><td data-th="Description">
<p>Cancels a time-out that was set with the <a href="https://msdn.microsoft.com/en-us/library/ms536753(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">setTimeout</strong></a> method. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536367(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">close</strong></a>
</td><td data-th="Description">
<p>Closes the current browser window or HTA. </p>
<p>Closes the app without prompting the user. To the user, it appears as though the app has crashed. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536376(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">confirm</strong></a>
</td><td data-th="Description">
<p>Displays a confirmation dialog box that contains an optional message as well as <strong>OK</strong> and <strong>Cancel</strong> buttons.</p>
<p>
    This method is not supported for Windows Store apps using JavaScript.
  </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/cc848921(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">ContentDiscoveryReset</strong></a>
</td><td data-th="Description">
<p>Resets the list of feeds, search providers, and Web Slices associated with the page.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/dd758055(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">create</strong></a>
</td><td data-th="Description">
<p>Creates a new <a href="https://msdn.microsoft.com/en-us/library/ms535259(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">img</strong></a> element of the specified width and height. This method cannot be called directly. See <a href="https://msdn.microsoft.com/en-us/library/dd757809(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">Image</strong></a> object. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/dd743027(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">create</strong></a>
</td><td data-th="Description">
<p>Initializes a new <a href="https://msdn.microsoft.com/en-us/library/ms535877(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">option</strong></a> element. This method cannot be called directly. See <a href="https://msdn.microsoft.com/en-us/library/dd757810(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">Option</strong></a> object. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536392(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">createPopup</strong></a>
</td><td data-th="Description">
<div class="alert"><strong>Note</strong>&nbsp;&nbsp;
<a href="https://msdn.microsoft.com/en-us/library/ms536392(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">createPopup</strong></a>  is no longer supported. Starting with IE11, use a <a href="https://msdn.microsoft.com/en-us/library/ms535240(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">div</strong></a>, <a href="https://msdn.microsoft.com/en-us/library/ms535258(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">iframe</strong></a>, or other element with a relatively high <a href="https://msdn.microsoft.com/en-us/library/ms531188(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">z-index</strong></a> value. For info, see <a href="https://msdn.microsoft.com/en-us/library/bg182625(v=vs.85).aspx">Compatibility changes</a>.</div>
<div>&nbsp;</div>
<p>Creates a <a href="https://msdn.microsoft.com/en-us/library/ms535882(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">popup</strong></a> window object.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/bb245715(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">CustomizeClearType</strong></a>
</td><td data-th="Description">
<p>Not supported. Sets a registry value to turn ClearType on or off.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/aa744116(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">CustomizeSettings</strong></a>
</td><td data-th="Description">
<p>Not supported. Saves the user settings from a "first run" page.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/bb245716(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">DefaultSearchProvider</strong></a>
</td><td data-th="Description">
<p>Not supported. Retrieves the name of the user's default search provider. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536411(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">detachEvent</strong></a>
</td><td data-th="Description">
<p>Unbinds the specified function from the event, so that the function stops receiving notifications when the event fires.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/bb245717(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">DiagnoseConnection</strong></a>
</td><td data-th="Description">
<p>Not supported. Attempts to diagnose problems with the network connection. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975247(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">dispatchEvent</strong></a>
</td><td data-th="Description">
<p>Sends an event to the current element. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536420(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">execScript</strong></a>
</td><td data-th="Description">
<div class="alert"><strong>Note</strong>&nbsp;&nbsp;
<a href="https://msdn.microsoft.com/en-us/library/ms536420(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">execScript</strong></a>  is no longer supported. Starting with IE11, use <a href="https://msdn.microsoft.com/en-us/library/12k71sw7(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">eval</strong></a>. For info, see <a href="https://msdn.microsoft.com/en-us/library/bg182625(v=vs.85).aspx">Compatibility changes</a>.</div>
<div>&nbsp;</div>
<p>Executes the specified script in the provided language.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536425(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">focus</strong></a>
</td><td data-th="Description">
<p>Causes the element to receive the focus and executes the code specified by the <a href="https://msdn.microsoft.com/en-us/library/ms536934(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">onfocus</strong></a> event. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975168(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">getComputedStyle</strong></a>
</td><td data-th="Description">
<p>Returns a <a href="https://msdn.microsoft.com/en-us/library/ms535231(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">currentStyle</strong></a> object containing the CSS settings that are applied to the specified element or a pseudo-element related to the specified element.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975169(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">getSelection</strong></a>
</td><td data-th="Description">
<p>Returns an object that represents the current <a href="https://msdn.microsoft.com/en-us/library/ff974359(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">selection</strong></a> of the document.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/dd425013(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">InPrivateFilteringEnabled</strong></a>
</td><td data-th="Description">
<p>Detects whether the user has enabled InPrivate Filtering.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/bb245718(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">IsSearchMigrated</strong></a>
</td><td data-th="Description">
<p>Not supported. Determines whether autosearch settings were migrated from a previous version of Internet Explorer. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/aa342526(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">IsSearchProviderInstalled</strong></a>
</td><td data-th="Description">
<div class="alert"><strong>Warning</strong>&nbsp;&nbsp;This method has been deprecated since Internet Explorer&nbsp;8 and removed from Windows&nbsp;10.</div>
<div>&nbsp;</div>
<p>
<em>Deprecated.</em> Determines if a search provider has been installed for the current user and whether it is set as default.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/cc197041(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">IsServiceInstalled</strong></a>
</td><td data-th="Description">
<p>Deprecated. Check if a service is already installed.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536460(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">item</strong></a>
</td><td data-th="Description">
<p>Retrieves an object from various collections, including the <a href="https://msdn.microsoft.com/en-us/library/ms537434(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">all</strong></a> collection.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/hh772743(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">matchMedia</strong></a>
</td><td data-th="Description">
<p>Accepts a string containing one or more media queries, and returns a <a href="https://msdn.microsoft.com/en-us/library/hh772454(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">MediaQueryList</strong></a> object.  </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536618(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">moveBy</strong></a>
</td><td data-th="Description">
<p>Moves the screen position of the window by the specified <em>x</em> and <em>y</em> offset values.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536626(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">moveTo</strong></a>
</td><td data-th="Description">
<p>Moves the screen position of the upper-left corner of the window to the specified <em>x</em> and <em>y</em> position. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/gg699456(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msActiveXFilteringEnabled</strong></a>
</td><td data-th="Description">
<p>Determines whether ActiveX Filtering is enabled by the user.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff976295(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msAddSiteMode</strong></a>
</td><td data-th="Description">
<p>Creates a pinned site shortcut to the current webpage on the Windows Start menu.</p>
<p>This method is not supported for Windows Store apps using JavaScript.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/gg593069(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msAddTrackingProtectionList</strong></a>
</td><td data-th="Description">
<p>Adds an external Tracking Protection list. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff976296(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msIsSiteMode</strong></a>
</td><td data-th="Description">
<p>Determines whether the current page was launched as a pinned site. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/gg593070(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msIsSiteModeFirstRun</strong></a>
</td><td data-th="Description">
<p>Determines whether a pinned site was launched for the first time.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/hh826030(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msIsStaticHTML</strong></a>
</td><td data-th="Description">
<p>Returns a Boolean value indicating whether or not the given HTML string is safe.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff976297(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msSiteModeActivate</strong></a>
</td><td data-th="Description">
<p>Flashes the pinned site taskbar button. </p>
<p>This method is not supported for Windows Store apps using JavaScript.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff976311(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msSiteModeAddButtonStyle</strong></a>
</td><td data-th="Description">
<p>Defines an alternate icon image and tooltip for the specified button. </p>
<p>This method is not supported for Windows Store apps using JavaScript.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff976299(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msSiteModeAddJumpListItem</strong></a>
</td><td data-th="Description">
<p>Adds a new entry to the Jump List of a taskbar button.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff976300(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msSiteModeAddThumbBarButton</strong></a>
</td><td data-th="Description">
<p>Adds a button to the Thumbnail Toolbar.</p>
<p>This method is not supported for Windows Store apps using JavaScript.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff976301(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msSiteModeClearIconOverlay</strong></a>
</td><td data-th="Description">
<p>Removes the icon overlay from the taskbar button. </p>
<p>This method is not supported for Windows Store apps using JavaScript.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff976302(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msSiteModeClearJumpList</strong></a>
</td><td data-th="Description">
<p>Deletes the Jump List. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff976303(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msSiteModeCreateJumpList</strong></a>
</td><td data-th="Description">
<p>Creates a new group of items on the Jump List. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff976304(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msSiteModeSetIconOverlay</strong></a>
</td><td data-th="Description">
<p>Adds an icon overlay to the pinned site taskbar button.</p>
<p>This method is not supported for Windows Store apps using JavaScript.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff976317(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msSiteModeShowButtonStyle</strong></a>
</td><td data-th="Description">
<p>Changes the icon image and tooltip of a Thumbnail Toolbar button. </p>
<p>This method is not supported for Windows Store apps using JavaScript.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff976318(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msSiteModeShowJumpList</strong></a>
</td><td data-th="Description">
<p>Shows updates to the list of items in a Jump List. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff976307(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msSiteModeShowThumbBar</strong></a>
</td><td data-th="Description">
<p>Enables the Thumbnail Toolbar in the thumbnail preview of a pinned site. </p>
<p>This method is not supported for Windows Store apps using JavaScript.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff976308(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msSiteModeUpdateThumbBarButton</strong></a>
</td><td data-th="Description">
<p>Changes the state of a Thumbnail Toolbar button. </p>
<p>This method is not supported for Windows Store apps using JavaScript.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/gg593071(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msTrackingProtectionEnabled</strong></a>
</td><td data-th="Description">
<p>Determines whether any Tracking Protection lists are enabled by the user. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/dd433074(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msWriteProfilerMark</strong></a>
</td><td data-th="Description">
<p>
			Writes a profiling event.
    </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536638(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">navigate</strong></a>
</td><td data-th="Description">
<p>Loads the specified URL to the current window.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536651(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">open</strong></a>
</td><td data-th="Description">
<p>Opens a new window and loads the document specified by a given URL.</p>
<p>Navigates the app window to the specified location. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/aa744121(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">PhishingEnabled</strong></a>
</td><td data-th="Description">
<p>Not supported. Determines whether Phishing Filter is enabled.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/cc197015(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">postMessage</strong></a>
</td><td data-th="Description">
<p>
			Sends a cross-document message.
    </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536672(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">print</strong></a>
</td><td data-th="Description">
<p>Prints the document associated with the window.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536673(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">prompt</strong></a>
</td><td data-th="Description">
<p>Displays a dialog box that prompts the user with a message and an input field.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/dn469425(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">releaseEvents</strong></a>
</td><td data-th="Description">
<p>No appreciable effect.  Do not use.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975250(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">removeEventListener</strong></a>
</td><td data-th="Description">
<p>Removes an event handler that  the  <a href="https://msdn.microsoft.com/en-us/library/ff975245(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">addEventListener</strong></a> method registered. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536722(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">resizeBy</strong></a>
</td><td data-th="Description">
<p>Changes the current size of the window by the specified x- and y-offset.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536723(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">resizeTo</strong></a>
</td><td data-th="Description">
<p>Sets the size of the window to the specified width and height values.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/bb245719(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">RunOnceHasShown</strong></a>
</td><td data-th="Description">
<p>Not supported. Determines whether the "first run" page has been shown. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/bb245720(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">RunOnceRequiredSettingsComplete</strong></a>
</td><td data-th="Description">
<p>Not supported. Sets a registry value to indicate whether the "first run" page completed successfully.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/aa744122(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">RunOnceShown</strong></a>
</td><td data-th="Description">
<p>Not supported. Sets a registry value to indicate that the "first run" page has been shown.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536726(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scroll</strong></a>
</td><td data-th="Description">
<p>Causes the window to scroll to the specified x- and y-offset at the upper-left corner of the window. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536728(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scrollBy</strong></a>
</td><td data-th="Description">
<p>Causes the window to scroll relative to the current scrolled position by the specified x- and y-pixel offset. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536731(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scrollTo</strong></a>
</td><td data-th="Description">
<p>Scrolls the window to the specified x- and y-offset. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/bb245721(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SearchGuideUrl</strong></a>
</td><td data-th="Description">
<p>Not supported. Retrieves the URL of a page that can be used to install additional search providers. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/cc289796(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetActivitiesVisible</strong></a>
</td><td data-th="Description">
<p>Not supported. A setting that notifies the <a href="https://msdn.microsoft.com/en-us/library/cc289792(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">IShellUIHelper3::BuildNewTabPage</strong></a> method whether to show or hide the activities list.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/hh773176(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">setImmediate</strong></a>
</td><td data-th="Description">
<p>Requests that a function be called when current or  pending tasks are complete, such as events or screen updates.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536749(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">setInterval</strong></a>
</td><td data-th="Description">
<p>Evaluates an expression each time a specified number of milliseconds has elapsed.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/cc289797(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SetRecentlyClosedVisible</strong></a>
</td><td data-th="Description">
<p>Not supported. A setting that notifies the <a href="https://msdn.microsoft.com/en-us/library/cc289792(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">IShellUIHelper3::BuildNewTabPage</strong></a> method whether to show or hide the list of recently closed tabs.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536753(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">setTimeout</strong></a>
</td><td data-th="Description">
<p>Evaluates an expression after a specified number of milliseconds has elapsed. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536758(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">showHelp</strong></a>
</td><td data-th="Description">
<p>Displays a Help file. This method can be used with Microsoft HTML Help. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536759(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">showModalDialog</strong></a>
</td><td data-th="Description">
<p>Creates a modal dialog box that displays the specified HTML document.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536761(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">showModelessDialog</strong></a>
</td><td data-th="Description">
<p>Creates a modeless dialog box that displays the specified HTML document.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/aa744124(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SkipRunOnce</strong></a>
</td><td data-th="Description">
<p>Not supported. Enables the user to select "first run" settings at a later time.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/aa744125(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SkipTabsWelcome</strong></a>
</td><td data-th="Description">
<p>Not supported. Disables the welcome screen that appears when opening a new tab in Internet Explorer&nbsp;7.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/aa744126(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">SqmEnabled</strong></a>
</td><td data-th="Description">
<p>Not supported. Determines whether SQM is enabled.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/cc848922(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">toStaticHTML</strong></a>
</td><td data-th="Description">
<p>Removes dynamic HTML elements and attributes from an HTML fragment. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/dn760734(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">webkitConvertPointFromNodeToPage</strong></a>
</td><td data-th="Description">
<p>Converts a point <em>pt</em> object from CSS node coordinates to page coordinates.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/dn760735(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">webkitConvertPointFromPageToNode</strong></a>
</td><td data-th="Description">
<p>Converts a point <em>pt</em> object from page coordinates to CSS node coordinates.</p>
</td></tr>
</tbody></table>

## Properties

<table id="memberListProperties" class="members" responsive="true">
<tbody><tr><th>Property</th><th>Access type</th><th>Description</th></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ff974676(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">ActiveXObject</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Returns a null value.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh972901(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">animationStartTime</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read-only</td><td data-th="Description">
<p>Obsolete.  Returns a timestamp of the start time of the current refresh interval, such that multiple animations can be synchronized with each other.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh771719(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">applicationCache</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read-only</td><td data-th="Description">
<p>Returns an <a href="https://msdn.microsoft.com/en-us/library/hh771703(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">ApplicationCache</strong></a> object.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533574(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">closed</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves whether the referenced window is closed.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772192(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">console</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read-only</td><td data-th="Description">
<p>Returns the windows console object to use to send messages. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/cc848898(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">constructor</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Returns a reference to the constructor of an object.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/dn302339(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">crypto</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read-only</td><td data-th="Description">
<p>Provides access to the  the global <a href="https://msdn.microsoft.com/en-us/library/dn280995(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">Crypto</strong></a> object for performing cryptographic operations.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533717(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">defaultStatus</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or retrieves the default message displayed in the status bar at the bottom of the window.    </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533723(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">dialogArguments</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets the variable or array of variables passed into the modal dialog window.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533724(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">dialogHeight</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or gets the height of the modal dialog window. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533725(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">dialogLeft</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or gets the left coordinate of the modal dialog window.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533726(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">dialogTop</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or gets the top coordinate of the modal dialog window. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533727(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">dialogWidth</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or gets the width of the modal dialog window.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533771(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">frameElement</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves the <a href="https://msdn.microsoft.com/en-us/library/ms535250(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">frame</strong></a> or <a href="https://msdn.microsoft.com/en-us/library/ms535258(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">iframe</strong></a> object that is hosting the <strong>window</strong> in the parent <a href="https://msdn.microsoft.com/en-us/library/ms535862(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">document</strong></a>.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh773167(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">hidden</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read-only</td><td data-th="Description">
<p>Returns whether a webpage is visible.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772512(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">indexedDB</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read-only</td><td data-th="Description">
<p>Allows access to the <a href="http://go.microsoft.com/fwlink/p/?LinkId=224519">Indexed Database API</a>, as implemented by Internet Explorer&nbsp;10.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ff974677(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">innerHeight</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets the height of the window, excluding user interface elements, such as the window frame, toolbars,  and so on.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ff974678(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">innerWidth</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets the width of the window, excluding user interface elements, such as the window frame.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534101(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">length</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or retrieves the number of objects in a collection.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/cc848902(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">localStorage</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves  the Web Storage area specific to the current document.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/dn793581(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">locationbar</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read-only</td><td data-th="Description">
<p>Used to determine if the location bar is visible to the user.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/cc197013(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">maxConnectionsPerServer</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>
			Retrieves the maximum number of concurrent connections to a Web server.
		</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/dn793582(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">menubar</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read-only</td><td data-th="Description">
<p>Used to determine if the menu bar is visible to the user.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534187(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">name</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or retrieves a value that indicates the window name.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534198(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">offscreenBuffering</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or retrieves whether objects are drawn offscreen before being made visible to the user.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534309(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">opener</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or retrieves a reference to the window that created the current window. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/dn760720(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">orientation</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read-only</td><td data-th="Description">
<p>Returns a numeric value representing the orientation of the device.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ff974681(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">outerHeight</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets the height of the window, including user interface elements, such as the window frame, toolbars, and so on.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ff974682(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">outerWidth</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets the width of the window, including user interface elements, such as the window frame.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ff974683(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pageXOffset</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets the distance, in pixels, that a document has scrolled horizontally.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ff974684(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pageYOffset</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets the distance, in pixels, that a document has scrolled vertically.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534326(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">parent</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves the parent of the <strong>window</strong> in the object hierarchy. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ff974680(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">performance</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Provides access to timing related information regarding navigation and performance for  the document that is loaded into the <strong>window</strong> object.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/dn793583(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">personalbar</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read-only</td><td data-th="Description">
<p>Used to determine if the personal bar is visible to the user.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534371(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">returnValue</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or gets the value returned from the modal dialog window.</p>
<p>This property is not supported for Windows Store apps using JavaScript.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534389(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">screenLeft</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves the x-coordinate of the upper left-hand corner of the window frame, relative to the upper left-hand corner of the screen. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534390(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">screenTop</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves the y-coordinate of the top corner of the client area, relative to the top corner of the screen.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534391(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">screenX</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or retrieves the x-coordinate of the mouse pointer's position relative to the user's screen. For the standards based property, see <a href="https://msdn.microsoft.com/en-us/library/ff974882(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">screenX</strong></a>.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534392(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">screenY</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or retrieves the y-coordinate of the mouse pointer's position relative to the user's screen. For the standards based property, see <a href="https://msdn.microsoft.com/en-us/library/ff974883(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">screenY</strong></a>. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/dn793584(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scrollbars</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read-only</td><td data-th="Description">
<p>Used to determine if the scrollbars are visible to the user.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/dn793585(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scrollX</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read-only</td><td data-th="Description">
<p>The distance the window was horizontally scrolled.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/dn793586(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scrollY</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read-only</td><td data-th="Description">
<p>The distance the window was vertically scrolled.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534627(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">self</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves a reference to the current window or frame. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/cc197020(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">sessionStorage</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves the Web Storage area for the session. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534648(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">status</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or retrieves the message in the status bar at the bottom of the window.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/dn793587(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">statusbar</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read-only</td><td data-th="Description">
<p>Used to determine if the status bar is visible to the user.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/gg592987(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">styleMedia</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets a <a href="https://msdn.microsoft.com/en-us/library/ff975074(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">StyleMedia</strong></a> object that contains methods and properties. These methods and properties determine the media types that are supported by the object that displays the <a href="https://msdn.microsoft.com/en-us/library/ms535862(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">document</strong></a> object.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/dn793588(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">toolbar</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read-only</td><td data-th="Description">
<p>Used to determine if the tool bar is visible to the user.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534687(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">top</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves the topmost ancestor window.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms535157(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">XMLHttpRequest</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">Instantiates the <a href="https://msdn.microsoft.com/en-us/library/ms535874(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">XMLHttpRequest</strong></a> object for the window.</td></tr>
</tbody></table>