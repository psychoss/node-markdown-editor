# How do I make an UPDATE while joining tables on SQLite?

I tried :

```
UPDATE closure JOIN item ON ( item_id = id ) 
SET checked = 0 
WHERE ancestor_id = 1
```

And:

```
UPDATE closure, item 
SET checked = 0 
WHERE ancestor_id = 1 AND item_id = id
```

Both works with MySQL, but those give me a syntax error in SQLite.

How can I make this UPDATE / JOIN works with SQLite version 3.5.9 ?

---

You can't. SQLite [doesn't support JOINs in UPDATE statements](http://sqlite.org/lang_update.html).

But, you can probably do this with a subquery instead:

UPDATE closure SET checked = 0 
WHERE item_id IN (SELECT id FROM item WHERE ancestor_id = 1);
Or something like that; it's not clear exactly what your schema is.