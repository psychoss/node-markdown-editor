# Promise - Javascript

## Properties

- **Promise.length**

 Length property whose value is 1 (number of constructor arguments).

- **Promise.prototype**

 Represents the prototype for the Promise constructor.

## Methods

- **Promise.all(iterable)**

 Returns a promise that resolves when all of the promises in the iterable argument have resolved. This is useful for aggregating results of multiple promises together.

- **Promise.race(iterable)**

 Returns a promise that resolves or rejects as soon as one of the promises in the iterable resolves or rejects, with the value or reason from that promise.

- **Promise.reject(reason)**

 Returns a Promise object that is rejected with the given reason.

- **Promise.resolve(value)**

 Returns a Promise object that is resolved with the given value. If the value is a thenable (i.e. has a then method), the returned promise will "follow" that thenable, adopting its eventual state; otherwise the returned promise will be fulfilled with the value. Generally, if you want to know if a value is a promise or not - Promise.resolve(value) it instead and work with the return value as a promise.

## Properties

- **Promise.prototype.constructor**

 Returns the function that created an instance's prototype. This is the Promise function by default.


Methods

- **Promise.prototype.catch(onRejected)**

 Appends a rejection handler callback to the promise, and returns a new promise resolving to the return value of the callback if it is called, or to its original fulfillment value if the promise is instead fulfilled.

- **Promise.prototype.then(onFulfilled, onRejected)**

 Appends fulfillment and rejection handlers to the promise, and returns a new promise resolving to the return value of the called handler, or to its original settled value if the promise was not handled (i.e. if the relevant handler onFulfilled or onRejected is undefined).