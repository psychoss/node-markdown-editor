# Singleton - Design Patterns in Javascript


```
var Singleton =
{
	toString : function()
	{
		return "[object Singleton]";
	}
};
```

```
var Singleton = function()
{
	if(Singleton.instance == null)
	{
		Singleton.instance = this;
	}
	return Singleton.instance;
};
Singleton.prototype.toString = function()
{
	return "[object Singleton]";
};
Singleton.getInstance = function()
{
	return new Singleton();
};
```


```
var Singleton = (function()
{
	return	{
		toString : function()
		{
			return "[object Singleton]";
		}
	};
}());
```


```
function Singleton(instance)
{
	if(!Singleton.getInstance)
	{
		Singleton.getInstance = function()
		{
			return instance;
		};
		instance = new Singleton;
	}
	this.toString = function()
	{
		return "[object Singleton]";
	};
}(new Singleton);
```