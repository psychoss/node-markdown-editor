# CSSOM View - CSS

<table responsive="true">
<tbody><tr><th>Property</th><th>Description</th></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ff974674(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">height</strong></a>
</p>
</td><td data-th="Description">
<p>Gets the height of the rectangle that surrounds the object content. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ff974677(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">innerHeight</strong></a>
</p>
</td><td data-th="Description">
<p>Gets the height of the window, excluding user interface elements, such as the window frame, toolbars,  and so on.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ff974678(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">innerWidth</strong></a>
</p>
</td><td data-th="Description">
<p>Gets the width of the window, excluding user interface elements, such as the window frame.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ff974653(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">offsetX</strong></a>
</p>
</td><td data-th="Description">
<p>Gets the x-coordinate of the mouse pointer, relative to the target node. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ff974654(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">offsetY</strong></a>
</p>
</td><td data-th="Description">
<p>Gets the y-coordinate of the mouse pointer, relative to the target node. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ff974681(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">outerHeight</strong></a>
</p>
</td><td data-th="Description">
<p>Gets the height of the window, including user interface elements, such as the window frame, toolbars, and so on.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ff974682(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">outerWidth</strong></a>
</p>
</td><td data-th="Description">
<p>Gets the width of the window, including user interface elements, such as the window frame.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ff974655(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pageX</strong></a>
</p>
</td><td data-th="Description">
<p>Gets the x-coordinate of the mouse pointer, relative to the upper-left corner of the page. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ff974656(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pageY</strong></a>
</p>
</td><td data-th="Description">
<p>Gets the y-coordinate of the mouse pointer, relative to the upper-left corner of the page. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ff974683(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pageXOffset</strong></a>
</p>
</td><td data-th="Description">
<p>Gets the distance, in pixels, that a document has scrolled horizontally.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ff974684(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pageYOffset</strong></a>
</p>
</td><td data-th="Description">
<p>Gets the distance, in pixels, that a document has scrolled vertically.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531125(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pixelBottom</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves the bottom position of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531127(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pixelHeight</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves the height of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531129(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pixelLeft</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves the left position of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531131(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pixelRight</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves the right position of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531133(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pixelTop</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves the top position of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531135(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pixelWidth</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves the width of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531137(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">posBottom</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves the bottom position of the object in the units specified by the <a href="https://msdn.microsoft.com/en-us/library/ms530745(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">bottom</strong></a> attribute. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531139(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">posHeight</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves the height of the object in the units specified by the <a href="https://msdn.microsoft.com/en-us/library/ms530765(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">height</strong></a> attribute. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531143(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">posLeft</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves the left position of the object in the units specified by the <a href="https://msdn.microsoft.com/en-us/library/ms530778(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">left</strong></a> attribute. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531146(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">posRight</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves the right position of the object in the units specified by the <a href="https://msdn.microsoft.com/en-us/library/ms531149(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">right</strong></a> attribute. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531147(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">posTop</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves the top position of the object in the units specified by the <a href="https://msdn.microsoft.com/en-us/library/ms531177(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">top</strong></a> attribute. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531148(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">posWidth</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves the width of the object in the units specified by the <a href="https://msdn.microsoft.com/en-us/library/ms531183(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">width</strong></a> attribute. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dn793585(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scrollX</strong></a>
</p>
</td><td data-th="Description">
<p>The distance the window was horizontally scrolled.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dn793586(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scrollY</strong></a>
</p>
</td><td data-th="Description">
<p>The distance the window was vertically scrolled.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ff974675(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">width</strong></a>
</p>
</td><td data-th="Description">
<p>Gets the width of the rectangle that surrounds the object content. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ff974658(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">x</strong></a>
</p>
</td><td data-th="Description">
<p>Gets the x-coordinate of the mouse pointer, relative to the last positioned ancestor element. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ff974659(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">y</strong></a>
</p>
</td><td data-th="Description">
<p>Gets the y-coordinate of the mouse pointer, relative to the last positioned ancestor element. </p>
</td></tr>
</tbody></table>