# Javascript - Experience

# 优化

- 在循环中不要重新声明只使用一次的变量。


## 字符串

- String.concat

  连接字符串。
  
  
## DOM

### Console

- **Console.assert()**

 Log a message and stack trace to console if first argument is false.

- **Console.count()**

 Log the number of times this line has been called with the given label.

- **Console.debug()**

 An alias for log();

- **Console.dir()**

 Displays an interactive listing of the properties of a specified JavaScript object. This listing lets you use disclosure triangles to examine the contents of child objects.

- **Console.dirxml()**

 Displays an XML/HTML Element representation of the specified object if possible or the JavaScript Object view if it is not.

- **Console.error()**

 Outputs an error message. You may use string substitution and additional arguments with this method.

- **Console._exception()**

 An alias for error();

- **Console.group()**

 Creates a new inline group, indenting all following output by another level. To move back out a level, call groupEnd().

- **Console.groupCollapsed()**

 Creates a new inline group, indenting all following output by another level; unlike group(), this starts with the inline group collapsed, requiring the use of a disclosure button to expand it. To move back out a level, call groupEnd().

- **Console.groupEnd()**

 Exits the current inline group.

- **Console.info()**

 Informative logging information. You may use string substitution and additional arguments with this method.

- **Console.log()**

 For general output of logging information. You may use string substitution and additional arguments with this method.

- **Console.profile()**

 Starts the browser's build-in profiler (for example, the Firefox performance tool). You can specify an optional name for the profile.

- **Console.profileEnd()**

 Stops the profiler. You can see the resulting profile in the browser's performance tool (for example, the Firefox performance tool).

- **Console.table()**

 Displays tabular data as a table.

- **Console.time()**

 Starts a timer with a name specified as an input parameter. Up to 10,000 simultaneous timers can run on a given page.

- **Console.timeEnd()**

 Stops the specified timer and logs the elapsed time in seconds since its start.

- **Console.timeStamp()**

 Adds a marker to the browser's Timeline or Waterfall tool.

- **Console.trace()**

 Outputs a stack trace.

- **Console.warn()**

 Outputs a warning message. You may use string substitution and additional arguments with this method.

### FileReader

#### Properties

- **FileReader.error**

 A DOMError representing the error that occurred while reading the file.

- **FileReader.readyState**

 A number indicating the state of the FileReader. This will be one of the State constants.

- **FileReader.result**

 The file's contents. This property is only valid after the read operation is complete, and the format of the data depends on which of the methods was used to initiate the read operation.

#### Event handlers

- **FileReader.onabort**

 A handler for the abort event. This event is triggered each time the reading operation is aborted.

- **FileReader.onerror**

 A handler for the error event. This event is triggered each time the reading operation encounter an error.

- **FileReader.onload**

 A handler for the load event. This event is triggered each time the reading operation is successfully completed.

- **FileReader.onloadstart**

 A handler for the loadstart event. This event is triggered each time the reading is starting.

- **FileReader.onloadend**

 A handler for the loadend event. This event is triggered each time the reading operation is completed (either in success or failure).

- **FileReader.onprogress**

 A handler for the progress event. This event is triggered while reading a Blob content.

### Request

#### Properties

- **Request.method**

 Contains the request's method (GET, POST, etc.)

- **Request.url**

 Contains the URL of the request.

- **Request.headers**

 Contains the associated Headers object of the request.

- **Request.context**

 Contains the context of the request (e.g., audio, image, iframe, etc.)

- **Request.referrer**

 Contains the referrer of the request (e.g., client).

- **Request.mode**

 Contains the mode of the request (e.g., cors, no-cors, same-origin).

- **Request.credentials**

 Contains the credentials of the request (e.g., omit, same-origin).

- **Request.redirect**

 Contains the mode for how redirects are handled. It may be one of follow, error, or manual.

- **Request.integrity**

 Contains the subresource integrity value of the request (e.g., sha256-BpfBw7ivV8q2jLiT13fxDYAe2tJllusRSZ273h2nFSE=).

- **Request.cache**

 Contains the cache mode of the request (e.g., default, reload, no-cache).


Request implements Body, so it also has the following property available to it:


- Body.bodyUsed

 Stores a Boolean that declares whether the body has been used in a response yet.

#### Methods

- **Request.clone()**

 Creates a copy of the current Request object.


Request implements Body, so it also has the following methods available to it:

- **Body.arrayBuffer()**

 Takes a Response stream and reads it to completion. It returns a promise that resolves with an ArrayBuffer.

- **Body.blob()**

 Takes a Response stream and reads it to completion. It returns a promise that resolves with a Blob.

- **Body.formData()**

 Takes a Response stream and reads it to completion. It returns a promise that resolves with a FormData object.

- **Body.json()**

 Takes a Response stream and reads it to completion. It returns a promise that resolves with a JSON object.

- **Body.text()**

 Takes a Response stream and reads it to completion. It returns a promise that resolves with a USVString (text).



### 查找元素

-   **document.querySelector( *selectors* )** 

 返回第一个与选择器匹配的元素。
 
 - 传入的选择器必须遵循 CSS 语法
 - 如果无匹配结果，返回 null.
 - 如果传入的选择器非法，将抛出错误。
 - 使用伪元素选择器查找，不会返回任何元素。
 - 如果选择器中包含不恰当的字符( `:` ),应该使用(`\\`)逃逸。
 
-  **document.querySelectorAll( *selectors* )** 

 返回所有与选择器匹配的元素(Node List)

### 动画

-  **window.requestAnimationFrame** 

 The Window.requestAnimationFrame() method tells the browser that you wish to perform an animation and requests that the browser call a specified function to update an animation before the next repaint. The method takes as an argument a callback to be invoked before the repaint.
 
### 事件对象

-  **event.bubbles** 

 Indicates whether the given event bubbles up through the DOM or not.

-  **Event.createEvent** 

 Creates a new event, which must then be initialized by calling its init() method.

-  **Event.currentTarget** 

 Identifies the current target for the event, as the event traverses the DOM. It always refers to the element the event handler has been attached to as opposed to event.target which identifies the element on which the event occurred.

-  **Event.eventPhase** 

 Indicates which phase of the event flow is currently being evaluated.

-  **event.preventDefault();** 

 Cancels the event if it is cancelable, without stopping further propagation of the event.

-  **event.stopImmediatePropagation();** 

 Prevents other listeners of the same event from being called.
 
- **event.stopPropagation();** 

 Prevents further propagation of the current event.

-  **Event.target** 

 A reference to the object that dispatched the event. It is different from event.currentTarget when the event handler is called during the bubbling or capturing phase of the event.

-  **Event.timeStamp** 

 Returns the time (in milliseconds since the epoch) at which the event was created.

-  **target.addEventListener(type, listener[, useCapture]);** 

 The EventTarget.addEventListener() method registers the specified listener on the EventTarget it's called on. The event target may be an Element in a document, the Document itself, a Window, or any other object that supports events (such as XMLHttpRequest).
 
-  **target.dispatchEvent(event)** 

 Dispatches an Event at the specified EventTarget, invoking the affected EventListeners in the appropriate order. The normal event processing rules (including the capturing and optional bubbling phase) apply to events dispatched manually with dispatchEvent().

-  **target.removeEventListener(type, listener[, useCapture])** 

 Removes the event listener previously registered with EventTarget.addEventListener().

#### KeyboardEvent

- **KeyboardEvent.altKey**

 Returns a Boolean that is true if the Alt ( Option or ⌥ on OS X) key was active when the key event was generated.

-  **KeyboardEvent.char** 

 Returns a DOMString representing the character value of the key. If the key corresponds to a printable character, this value is a non-empty Unicode string containing that character. If the key doesn't have a printable representation, this is an empty string.
 
 Note: If the key is used as a macro that inserts multiple characters, this attribute's value is the entire string, not just the first character.

 Warning: This has been dropped from DOM Level 3 Events. This is supported only on IE9+.

-  **KeyboardEvent.charCode** 

 Returns a Number representing the Unicode reference number of the key; this attribute is used only by the keypress event. For keys whose char attribute contains multiple characters, this is the Unicode value of the first character in that attribute. In Firefox 26 this returns codes for printable characters.

 Warning: This attribute is deprecated; you should use KeyboardEvent.key instead, if available.
 
- **KeyboardEvent.code**

 Returns a DOMString with the code value of the key represented by the event.

- **KeyboardEvent.ctrlKey**

 Returns a Boolean that is true if the Ctrl key was active when the key event was generated.

- **KeyboardEvent.isComposing**

 Returns a Boolean that is true if the event is fired between after compositionstart and before compositionend.

- **KeyboardEvent.key**

 Returns a DOMString representing the key value of the key represented by the event.


- **KeyboardEvent.keyCode**

 Returns a Number representing a system and implementation dependent numerical code identifying the unmodified value of the pressed key.

 Warning: This attribute is deprecated; you should use KeyboardEvent.key instead, if available.

- **KeyboardEvent.keyIdentifier**

 This property is non-standard and has been deprecated in favor of KeyboardEvent.key. It was part of an old version of DOM Level 3 Events.

- **KeyboardEvent.keyLocation**

 This is a non-standard deprecated alias for KeyboardEvent.location. It was part of an old version of DOM Level 3 Events.

- **KeyboardEvent.locale**

 Returns a DOMString representing a locale string indicating the locale the keyboard is configured for. This may be the empty string if the browser or device doesn't know the keyboard's locale.

 Note: This does not describe the locale of the data being entered. A user may be using one keyboard layout while typing text in a different language.

- **KeyboardEvent.location**

 Returns a Number representing the location of the key on the keyboard or other input device.

- **KeyboardEvent.metaKey**

 Returns a Boolean that is true if the Meta key (on Mac keyboards, the ⌘ Command key; on Windows keyboards, the Windows key (⊞)) was active when the key event was generated.

- **KeyboardEvent.repeat**

 Returns a Boolean that is true if the key is being held down such that it is automatically repeating.

- **KeyboardEvent.shiftKey**

 Returns a Boolean that is true if the Shift key was active when the key event was generated.

- **KeyboardEvent.which**

 Returns a Number representing a system and implementation dependent numeric code identifying the unmodified value of the pressed key; this is usually the same as keyCode.

 Warning: This attribute is deprecated; you should use KeyboardEvent.key instead, if available.

#### MouseEvent

- **MouseEvent.altKey**

 Returns true if the alt key was down when the mouse event was fired.

- **MouseEvent.button**

 The button number that was pressed when the mouse event was fired.

- **MouseEvent.buttons**

 The buttons being pressed when the mouse event was fired

- **MouseEvent.clientX**

 The X coordinate of the mouse pointer in local (DOM content) coordinates.

- **MouseEvent.clientY**

 The Y coordinate of the mouse pointer in local (DOM content) coordinates.

- **MouseEvent.ctrlKey**

 Returns true if the control key was down when the mouse event was fired.

- **MouseEvent.metaKey**

 Returns true if the meta key was down when the mouse event was fired.

- **MouseEvent.movementX**

 The X coordinate of the mouse pointer relative to the position of the last mousemove event.

- **MouseEvent.movementY**

 The Y coordinate of the mouse pointer relative to the position of the last mousemove event.

- **MouseEvent.offsetX**

 The X coordinate of the mouse pointer relative to the position of the padding edge of the target node.

- **MouseEvent.offsetY**

 The Y coordinate of the mouse pointer relative to the position of the padding edge of the target node.

- **MouseEvent.pageX**

 The X coordinate of the mouse pointer relative to the whole document.

- **MouseEvent.pageY**

 The Y coordinate of the mouse pointer relative to the whole document.

- **MouseEvent.region**

 Returns the id of the hit region affected by the event. If no hit region is affected, null is returned.

- **MouseEvent.relatedTarget**

 The secondary target for the event, if there is one.

- **MouseEvent.screenX**

 The X coordinate of the mouse pointer in global (screen) coordinates.

- **MouseEvent.screenY**

 The Y coordinate of the mouse pointer in global (screen) coordinates.

- **MouseEvent.shiftKey**

 Returns true if the shift key was down when the mouse event was fired.

- **MouseEvent.which**

 The button being pressed when the mouse event was fired.

- **MouseEvent.mozPressure**

 The amount of pressure applied to a touch or tablet device when generating the event; this value ranges between 0.0 (minimum pressure) and 1.0 (maximum pressure).

- **MouseEvent.mozInputSource**

 The type of device that generated the event (one of the MOZ_SOURCE_* constants listed below). This lets you, for example, determine whether a mouse event was generated by an actual mouse or by a touch event (which might affect the degree of accuracy with which you interpret the coordinates associated with the event).

- **MouseEvent.x**

 Alias for MouseEvent.clientX.

- **MouseEvent.y**

 Alias for MouseEvent.clientY


### 属性

-  **element.setAttribute( *name* ,  *value* );** 

 Adds a new attribute or changes the value of an existing attribute on the specified element.

-  **element.setAttributeNode( *attribute* );** 

 setAttributeNode() adds a new Attr node to the specified element.

### 元素尺寸和位置

-  **element.getBoundingClientRect()** 

 The  `Element.getBoundingClientRect()`  method returns the size of an element and its position relative to the viewport.

-  **element.getClientRects()** 

 The  **Element.getClientRects()**  method returns a collection of rectangles that indicate the bounding rectangles for each box in a client.

-  **element.clientHeight** 

 The Element.clientHeight read-only property is zero for elements with no CSS or inline layout boxes, otherwise it's the inner height of an element in pixels, including padding but not the horizontal scrollbar height, border, or margin.

 clientHeight can be calculated as CSS height + CSS padding - height of horizontal scrollbar (if present).

-  **element.scrollHeight** 

 The Element.scrollHeight read-only attribute is a measurement of the height of an element's content, including content not visible on the screen due to overflow. The scrollHeight value is equal to the minimum clientHeight the element would require in order to fit all the content in the viewpoint without using a vertical scrollbar. It includes the element padding but not its margin.

-  **HTMLElement.offsetHeight** 

 The  `HTMLElement.offsetHeight`  read-only property is the height of the element including vertical padding and borders, in pixels, as an integer.

 Typically, an element's offsetHeight is a measurement which includes the element borders, the element vertical padding, the element horizontal scrollbar (if present, if rendered) and the element CSS height.

 For the document body object, the measurement includes total linear content height instead of the element CSS height. Floated elements extending below other linear content are ignored.
 
-  **window.innerHeight** 

 Height (in pixels) of the browser window viewport including, if rendered, the horizontal scrollbar.
 
-  **window.innerWidth** 
-  **window.screenX** 

 The Window.screenX read-only property returns the horizontal distance, in CSS pixels, of the left border of the user's browser from the left side of the screen.


-  **window.scrollX** 

 Returns the number of pixels that the document has already been scrolled horizontally.

## JSON

### JSON 格式文本转换成对象

```
var jsonobject = new Function('return ' + jsonstring)();
```





## 数学

### 乘

```
1<<3 //8
```

### 比较

```
+"5"===5 // true
!(0^1) //false
!(0^0) //true
~0 //-1
~-1 //0
```

### 除

```
8>>2 //2
1/0 //Infinity
-1/0 //-Infinity
1/-0 //-Infinity
0/.1 //0
""/0 //NaN
```

### 获取整数


```
0|28.8 //28
~~28.8 //28
```

### 四舍五入

```
var a=1.4;
a+.5|0;

//a=> 1

```