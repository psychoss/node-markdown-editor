# Full text search - Sqlite3

    CREATE TABLE `markdown` (
    	`_id`	INTEGER,
    	`title`	TEXT,
    	`category`	TEXT,
    	`content`	TEXT,
    	`create`	INTEGER,
    	`modified`	INTEGER,
    	PRIMARY KEY(_id)
    );

    INSERT INTO markdown VALUES (null,'abc','abc','abc','abc','abc')
    
    CREATE VIRTUAL TABLE notes USING fts4(content="markdown",id,content);
     INSERT INTO markdown VALUES (null,'abc','abc','abc','abc','abc')
    CREATE VIRTUAL TABLE notes USING fts4(
    	`_id`	INTEGER PRIMARY KE,
    	`content`	TEXT);
    
    SELECT * FROM markdown WHERE title MATCH 'a';
    
    CREATE TRIGGER logs_bu BEFORE UPDATE ON logs BEGIN
  DELETE FROM logs_fts WHERE docid=old.rowid;
END;
CREATE TRIGGER logs_bd BEFORE DELETE ON logs BEGIN
  DELETE FROM logs_fts WHERE docid=old.rowid;
END;

CREATE TRIGGER logs_au AFTER UPDATE ON logs BEGIN
  INSERT INTO logs_fts(docid, b, c) VALUES(new.rowid, new.b, new.c);
END;
CREATE TRIGGER logs_ai AFTER INSERT ON logs BEGIN
  INSERT INTO logs_fts(docid, b, c) VALUES(new.rowid, new.b, new.c);
END;

INSERT INTO logs_fts(logs_fts) VALUES('rebuild');

```
    CREATE VIRTUAL TABLE notes USING fts4(content="markdown",_id,content);
    
    INSERT INTO notes(notes) VALUES('rebuild');
    
    SELECT * FROM notes WHERE notes MATCH 'a';
    
    CREATE TRIGGER notes_bu BEFORE UPDATE ON markdown BEGIN
      DELETE FROM notes WHERE docid=old.rowid;
    END;
    
    CREATE TRIGGER notes_au AFTER UPDATE ON markdown BEGIN
      INSERT INTO notes(docid, _id, content) VALUES(new.rowid, new._id, new.content);
    END;
    
    CREATE TRIGGER notes_ai AFTER INSERT ON markdown BEGIN
      INSERT INTO notes(docid, _id, content) VALUES(new.rowid, new._id, new.content);
    END;
```