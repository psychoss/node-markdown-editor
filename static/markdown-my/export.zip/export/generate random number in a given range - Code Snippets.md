# generate random number in a given range - Code Snippets


Total noob, teaching myself how to code. 

I just spent an hour trying to figure out how to generate a random number from a given range using the go programming language(golang).

Here's the best that I've found so far...

```
package main
import(
    "fmt"
    "math/rand"
    "time"
)

func random(min, max int) int {

    return rand.Intn(max - min) + min
}

func main() {
    rand.Seed(time.Now().UTC().UnixNano())
    myrand := random(1, 6)
    fmt.Println(myrand)
}
```


func random defines how to create the random number. 
rand.Seed ensures that the number that is generated is random(almost). 
func main gives you that random number within any two positive numbers that you specify (in this case, 1 and 6).