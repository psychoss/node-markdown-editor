# Fonts - CSS

<table responsive="true">
<tbody><tr><th>Property</th><th>Description</th></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530756(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">font</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a combination of separate <a href="https://msdn.microsoft.com/en-us/library/ms530756(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">font</strong></a> properties of the object. Alternatively, sets or retrieves one or more of six user-preference fonts.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530758(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">font-family</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the name of the font used for text in the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh869409(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">font-feature-settings</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies one or more values that specify glyph substitution and positioning in fonts that include OpenType layout features.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530759(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">font-size</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  a value that indicates the font size used for text in the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127324(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">font-stretch</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a value that indicates a normal, condensed, or expanded face of a font family.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530760(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">font-style</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the font style of the object as <strong>italic</strong>, <strong>normal</strong>, or <strong>oblique</strong>. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530761(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">font-variant</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  whether the text of the object is in small capital letters.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530762(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">font-weight</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the weight of the font of the object. </p>
</td></tr>
</tbody></table>