# clearfix - SCSS Mixin 

```
@mixin clearfix() {
  &::after {
    content: "";
    display: table;
    clear: both;
  }
}
```