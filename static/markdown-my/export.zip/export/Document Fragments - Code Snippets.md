# Document Fragments - Code Snippets

```

<div class="row">
  <div class="large-8 columns">
    <h1>Document Fragments</h1>
    <blockquote>
      <p>DocumentFragments are DOM Nodes. They are never part of the main DOM tree. The usual use case is to create the document fragment, append elements to the document fragment and then append the document fragment to the DOM tree. In the DOM tree, the document fragment is replaced by all its children.</p>
      <p>Since the document fragment is in memory and not part of the main DOM tree, appending children to it does not cause page reflow (computation of element's position and geometry). Consequently, using document fragments often results in better performance.</p>
      <p>documentFragment are supported in all browsers, even Internet Explorer 6, so there is no reason to not use them.</p>
    </blockquote>
    <p><a href="https://developer.mozilla.org/en-US/docs/Web/API/document.createDocumentFragment">Link to MDN</a></p>
  </div>
  <div class="buttonwrap large-4 columns">
    <button id="button" class="button radius expand">click to add</button>
    <ul class="list"></ul>
  </div>
</div>
```


```
.button {
  margin: 1vw auto;
}

.list {
  margin: 1vw;
}

blockquote p {
  font-style: italic;
}

```



```
var clicky = function() {
  
  var ul = document.getElementsByTagName("ul")[0]; // assuming it exists
  var docfrag = document.createDocumentFragment();
  var gatorList = ["Alligator mississippiensis", "Alligator sinensis", "Caiman crocodilus", "Caiman latirostris", "Caiman yacare"];

  gatorList.forEach(function(e) {
    var li = document.createElement("li");
    li.textContent = e;
    docfrag.appendChild(li);
  });

  ul.appendChild(docfrag);
};

var btn = document.getElementById("button");
btn.addEventListener("click", clicky, false);

```