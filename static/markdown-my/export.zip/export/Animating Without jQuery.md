# Animating Without jQuery

There’s a false belief in the web development community that CSS animation is the only performant way to animate on the web. This myth has coerced many developers to abandon JavaScript-based animation altogether, thereby (1) forcing themselves to manage complex UI interaction within style sheets, (2) locking themselves out of supporting Internet Explorer 8 and 9, and (3) forgoing the beautiful motion design physics that are possible only with JavaScript.

Reality check: JavaScript-based animation is often as fast as CSS-based animation — sometimes even faster. CSS animation only appears to have a leg up because it’s typically compared to jQuery’s $.animate(), which is, in fact, very slow. However, JavaScript animation libraries that bypass jQuery deliver incredible performance by avoiding DOM manipulation as much as possible. These libraries can be up to 20 times faster than jQuery.

So, let’s smash some myths, dive into some real-world animation examples and improve our design skills in the process. If you love designing practical UI animations for your projects, this article is for you.

## Why JavaScript? 

CSS animations are convenient when you need to sprinkle property transitions into your style sheets. Plus, they deliver fantastic performance out of the box — without your having to add libraries to the page. However, when you use CSS transitions to power rich motion design (the kind you see in the latest versions of iOS and Android), they become too difficult to manage or their features simply fall short.

Ultimately, CSS animations limit you to what the specification provides. In JavaScript, by the very nature of any programming language, you have an infinite amount of logical control. JavaScript animation engines leverage this fact to provide novel features that let you pull off some very useful tricks:

* cross-browser SVG support,
* physics-based loader animations,
* timeline control,
* Bezier translations.

Note: If you’re interested in learning more about performance, you can read Julian Shapiro’s “[CSS vs. JS Animation: Which Is Faster?](http://davidwalsh.name/css-js-animation)” and Jack Doyle’s “[Myth Busting: CSS Animations vs. JavaScript.](http://css-tricks.com/myth-busting-css-animations-vs-javascript/)” For performance demos, refer to the [performance pane](http://velocityjs.org/) in Velocity’s documentation and GSAP’s “[Library Speed Comparison](http://codepen.io/GreenSock/full/srfxA/)” demo.

## Velocity and GSAP 

The two most popular JavaScript animation libraries are [Velocity.js](http://velocityjs.org/) and [GSAP](http://greensock.com/gsap/). They both work with and without jQuery. When these libraries are used alongside jQuery, there is no performance degradation because they completely bypass jQuery’s animation stack.

If jQuery is present on your page, you can use Velocity and GSAP just like you would jQuery’s $.animate(). For example, $element.animate({ opacity: 0.5 }); simply becomes $element.velocity({ opacity: 0.5 }).

These two libraries also work when jQuery is not present on the page. This means that instead of chaining an animation call onto a jQuery element object — as just shown — you would pass the target element(s) to the animation call:
```
/* Working without jQuery */

Velocity(element, { opacity: 0.5 }, 1000); // Velocity

TweenMax.to(element, 1, { opacity: 0.5 }); // GSAP
```

As shown, Velocity retains the same syntax as jQuery’s $.animate(), even when it’s used without jQuery; just shift all arguments rightward by one position to make room for passing in the targeted elements in the first position.

GSAP, in contrast, uses an object-oriented API design, as well as convenient static methods. So, you can get full control over animations.

In both cases, you’re no longer animating a jQuery element object, but rather a raw DOM node. As a reminder, you access raw DOM nodes by using document.getElementByID, document.getElementsByTagName, document.getElementsByClassName or document.querySelectorAll (which works similarly to jQuery’s selector engine). We’ll briefly work with these functions in the next section.

## Working Without jQuery 

(Note: If you need a basic primer on working with jQuery’s $.animate(), refer to the first few panes in Velocity’s documentation.)

Let’s explore querySelectorAll further because it will likely be your weapon of choice when selecting elements without jQuery:

```
document.querySelectorAll("body"); // Get the body element
document.querySelectorAll(".squares"); // Get all elements with the "square" class
document.querySelectorAll("div"); // Get all divs
document.querySelectorAll("#main"); // Get the element with an id of "main"
document.querySelectorAll("#main div"); // Get the divs contained by "main"
```


As shown, you simply pass querySelectorAll a CSS selector (the same selectors you would use in your style sheets), and it will return all matched elements in an array. Hence, you can do this:

```
/* Get all div elements. */
var divs = document.querySelectorAll("div");

/* Animate all divs at once. */
Velocity(divs, { opacity: 0.5 }, 1000); // Velocity
TweenMax.to(divs, 1, { opacity: 0.5 }); // GSAP
```

Because we’re no longer attaching animations to jQuery element objects, you may be wondering how we can chain animations back to back, like this:
```
$element // jQuery element object
	.velocity({ opacity: 0.5 }, 1000)
	.velocity({ opacity: 1 }, 1000);
```

In Velocity, you simply call animations one after another:
```
/* These animations automatically chain onto one another. */
Velocity(element, { opacity: 0.5 }, 1000);
Velocity(element, { opacity: 1 }, 1000);
```

Animating this way has no performance drawback (as long as you cache the element being animated to a variable, instead of repeatedly doing querySelectorAll lookups for the same element).

(Tip: With Velocity’s UI pack, you can create your own multi-call animations and give them custom names that you can later reference as Velocity’s first argument. See Velocity’s UI Pack documentation for more information.)

This one-Velocity-call-at-a-time process has a huge benefit: If you’re using promises with your Velocity animations, then each Velocity call will return an actionable promise object. You can learn more about working with promises in Jake Archibald’s article. They’re incredibly powerful.

In the case of GSAP, its expressive object-oriented API allows you to place your animations in a timeline, giving you control over scheduling and synchronization. You’re not limited to one-after-the-other chained animations; you can nest timelines, make animations overlap, etc:
```
var tl = new TimelineMax();
/* GSAP tweens chain by default, but you can specify exact insertion points in the timeline, including relative offsets. */
tl
  .to(element, 1, { opacity: 0.5 })
  .to(element, 1, { opacity: 1 });
```

## JavaScript Awesomeness: Workflow 

Animation is inherently an experimental process in which you need to play with timing and easings to get exactly the feel that your app needs. Of course, even once you think a design is perfect, a client will often request non-trivial changes. In these situations, a manageable workflow becomes critical.

While CSS transitions are impressively easy to sprinkle into a project for effects such as hovers, they become unmanageable when you attempt to sequence even moderately complex animations. That’s why CSS provides keyframe animations, which allow you to group animation logic into sections.

However, a core deficiency of the keyframes API is that you must define sections in percentages, which is unintuitive. For example:
```
@keyframes myAnimation {
   0% {
      opacity: 0;
      transform: scale(0, 0);
   }
   25% {
      opacity: 1;
      transform: scale(1, 1);
   }
   50% {
      transform: translate(100px, 0);
   }
   100% {
      transform: translate(100px, 100px);
   }
}

#box {
   animation: myAnimation 2.75s;
}
```

What happens if the client asks you to make the translateX animation 1 second longer? Yikes. That requires redoing the math and changing all (or most) of the percentages.

Velocity has its UI pack to deal with multi-animation complexity, and GSAP offers nestable timelines. These features allow for entirely new workflow possibilities.

But let’s stop preaching about workflow and actually dive into fun animation examples.

## JavaScript Awesomeness: Physics

Many powerful effects are achievable exclusively via JavaScript. Let’s examine a few, starting with physics-based animation.

The utility of physics in motion design hits upon the core principle of what makes for a great UX: interfaces that flow naturally from the user’s input — in other words, interfaces that adhere to how motion works in the real world.

GSAP offers physics plugins that adapt to the constraints of your UI. For example, the ThrowPropsPlugin tracks the dynamic velocity of a user’s finger or mouse, and when the user releases, ThrowPropsPlugin matches that corresponding velocity to naturally glide the element to a stop. The resulting animation is a standard tween that can be time-manipulated (paused, reversed, etc.):


```
HTML  CSS  JS  Result
Edit on 
<link href='http://fonts.googleapis.com/css?family=Asap:400,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Signika+Negative:300,400,700' rel='stylesheet' type='text/css'>
<div class="demo">
  <div id="knob-head">Spin the Knob</div>
  <div id="knob"></div>
<div id="container">
        <div class="box" id="box1">Drag and throw me</div>
        <div class="box" id="box2" style="left:375px; background-color:red;">Drag and throw me</div>
</div>
<div class="controls">
                <ul>
                    <li class="controlsTitle">Options</li>
                    <li>
                        <label><input type="checkbox" name="snap" id="snap" value="1" /> Snap end position to grid</label>
                    </li>
                    <li>
                        <label><input type="checkbox" name="liveSnap" id="liveSnap" value="1" /> Live snap</label>
                    </li>
                </ul>
            </div>
  </div>
```


```
HTML  CSS  JS  Result
Edit on 
body {
  background-color: black;
}

.demo {
  font-family: Signika Negative, Asap, sans-serif;
  position:relative;

}
#container {
  height:801px; 
  overflow:visible; 
  padding:0; 
  position:relative;
}
.demo {position:relative;}

.box {
  background-color: #91e600;
  text-align: center;
  font-family: Asap, Avenir, Arial, sans-serif;

  font-size:12px;
  width: 150px;
  height: 75px;
  line-height: 75px;
  color: black;
  position: absolute;
  top:0;
  -webkit-border-radius: 10px;
  -moz-border-radius: 10px;
  border-radius: 10px;
}

.controls {
  background-color: #222;
  border: 1px solid #555;
  color: #bbb;
  font-size: 18px;
  margin: -1px 0 0 0;
  width:749px;
}
.controls ul {
  list-style: none;
  padding: 0;
  margin: 0;
}
.controls li {
  display: inline-block;
  padding: 8px 0 8px 10px;
  margin:0;
}
.controls input {
  vertical-align:middle;
  cursor: pointer;
}
.controls .controlsTitle {
  border-right:1px solid #555; 
  border-bottom:none; 
  padding-right:10px;
}

#knob {
  position:absolute;
  width:140px;
  height:140px;
  top:75px;
  left:770px;
  border-radius:50%;
  line-height:140px;
  text-align:center;
  color:black;
  background:url(http://www.greensock.com/wp-content/uploads/custom/draggable/img/knob_small.png);
}

#knob-head {
  position:absolute;
  width:140px;
  height:140px;
  color:#bbb;
  top:35px;
  left:770px;
  text-align:center;
  
}
```

```
HTML  CSS  JS  Result
Edit on 
/*
See http://www.greensock.com/draggable/ for details. 
*/
var $snap = $("#snap"),
  $liveSnap = $("#liveSnap"),
    $container = $("#container"),
    gridWidth = 125,
    gridHeight = 70,
    gridRows = 4,
    gridColumns = 6,
    i, x, y;

//loop through and create the grid (a div for each cell). Feel free to tweak the variables above
for (i = 0; i < gridRows * gridColumns; i++) {
    y = Math.floor(i / gridColumns) * gridHeight;
    x = (i * gridWidth) % (gridColumns * gridWidth);
    $("<div/>").css({position:"absolute", border:"1px solid #454545", width:gridWidth-1, height:gridHeight-1, top:y, left:x}).prependTo($container);
}

//set the container's size to match the grid, and ensure that the box widths/heights reflect the variables above
TweenLite.set($container, {height: gridRows * gridHeight + 1, width: gridColumns * gridWidth + 1});
TweenLite.set(".box", {width:gridWidth, height:gridHeight, lineHeight:gridHeight + "px"});

//the update() function is what creates the Draggable according to the options selected (snapping).
function update() {
  var snap = $snap.prop("checked"),
      liveSnap = $liveSnap.prop("checked");
    Draggable.create(".box", {
        bounds:$container,
        edgeResistance:0.65,
        type:"x,y",
        throwProps:true,
        liveSnap:liveSnap,
        snap:{
            x: function(endValue) {
                return (snap || liveSnap) ? Math.round(endValue / gridWidth) * gridWidth : endValue;
            },
            y: function(endValue) {
                return (snap || liveSnap) ? Math.round(endValue / gridHeight) * gridHeight : endValue;
            }
        }
    });
}

//spin the knob
Draggable.create("#knob", {
  type:"rotation",
  throwProps:true
})

//when the user toggles one of the "snap" modes, make the necessary updates...
$snap.on("change", applySnap);
$liveSnap.on("change", applySnap);

function applySnap() {
    if ($snap.prop("checked") || $liveSnap.prop("checked")) {
        $(".box").each(function(index, element) {
            TweenLite.to(element, 0.5, {
                x:Math.round(element._gsTransform.x / gridWidth) * gridWidth,
                y:Math.round(element._gsTransform.y / gridHeight) * gridHeight,
                delay:0.1,
                ease:Power2.easeInOut
            });
        });
    }
    update();
}

update();

//This demo uses ThrowPropsPlugin which is a membership benefit of Club GreenSock, http://www.greensock.com/club/
```

Velocity offers an easing type based on spring physics. Typically with easing options, you pass in a named easing type; for example, ease, ease-in-out or easeInOutSine. With spring physics, you pass a two-item array consisting of tension and friction values (in brackets below):

    Velocity(element, { left: 500 }, [ 500, 20 ]); // 500 tension, 20 friction

A higher tension (a default of 500) increases the total speed and bounciness. A lower friction (a default of 20) increases ending vibration speed. By tweaking these values, you can separately fine-tune your animations to have different personalities. Try it out:

```
HTML  SCSS  JS  Result
Edit on 
<!-- Created by Bennett Feely. -->

<main>
  <h1>Spring Physics and Velocity.js</h1>
  <section>
    <span>[<div class="tension" contenteditable>500</div>, <div class="friction" contenteditable>20</div>]</span>
    <button>Run</button>
    <small>[tension, friction]</small></section>
    <br>
    <div id="box"></div>
    <br>
  <pre><code>$element.velocity({
  "left": "500px"
}, 625, [<b id="code_tension">tension</b>, <b id="code_friction">friction</b>]);</code></pre>  
</main>
```

```
@import url(http://fonts.googleapis.com/css?family=Source+Code+Pro:300,400,500,600,700);

$radius : .5rem;

body {
  font-family: "Source Code pro", monospace;
  background: whitesmoke;
}

h1 {
  text-transform: uppercase;
  font-size: 1.4rem;
  font-weight: 300;
}

main {
  width: 30rem;
  margin: 0 auto;
}

section {
  text-align: left;
  position: relative;
  display: inline-block;
  background: white;
  padding: .75rem 1rem;
  padding-right: 5rem;
  font-size: 2em;
  font-family: monospace;
  border-radius: .5rem;
  box-shadow: 0 .125rem lightgray;
  overflow: hidden;
}

small {
  display: block;
  font-size: .8rem;
  margin-top: 1em;
  padding-bottom: .25rem;
  transition: .3s;

  section:hover & {
    color: black;
  }
}

[contenteditable] {
  display: inline-block;
  text-align: center;
  min-width: 1em;
  border: 0;
  background: white;
  border-radius: $radius;
  transition: .3s;
  vertical-align: -10%;
  
  span:hover & {
    background: #ffa;
  }
  
  &:focus,
  section:hover &:focus {
    outline: 0;
    background: yellow;
    padding: 0 .25em;
  }
}

button {
  display: inline-block;
  position: absolute;
  top: 0;
  right: 0;
  border: 0;
  background: lightgreen;
  padding: .25em .5em;
  border-top-right-radius: $radius;
  box-shadow: inset 0 -.125rem rgba(0,0,0,.1);
  transition: .4s;
  transform-origin: top right;
  
  &:hover {
    background: darken(lightgreen, 20%);
    transition: .2s;
  }
  &:active {
    transform: scale(1.1);
    transition: 0;
  }
  &:focus {
    outline: 0;
  }
}

#box {
  width: 100px;
  height: 100px;
  margin-top: 1em;
  transform-origin: 0 0;
  background: darkgray;
  border-radius: $radius;
  position: relative;
}

pre {
  display: inline-block;
  font-size: .9rem;
  text-align: left;
  background: rgba(black, .05);
  margin-top: 1rem;
  padding: 1.5rem 2rem;
  border-radius: $radius;
  box-shadow: inset 0 .125rem gainsboro;
}
```


```
var $box = $("#box");

$("button").click(spring);

function spring() {
  var tension = $(".tension").text(),
      friction = $(".friction").text();
  
  $box
    .velocity({
      left: "300px"  
    }, 625, [tension, friction])
    .velocity("reverse");
  
  $("#code_tension").text(tension);
  $("#code_friction").text(friction);
}
```

## JavaScript Awesomeness: Scrolling 
In Velocity, you can enable the user to scroll the browser to the edge of any element by passing in scroll as Velocity’s first argument (instead of a properties map). The scroll command behaves identically to a standard Velocity call; it can take options and can be queued.

    Velocity(element, "scroll", { duration: 1000 };


```
<p>
  Refresh this page to re-run the demo.
</p>

<div id="container">
    <div id="element1">
      First element. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.
    </div>
    <div id="element2">
      Second element. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.
    </div>
    <div id="element3">
      Third element. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.
    </div>
    <div id="element4">
      Fourth element. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.
    </div>
    <div id="element5">
      Fifth element. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.
    </div>
    <div id="element6">
      Sixth element. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.
    </div>
</div>
```

```
body {
  font-family: "Helvetica Neue", Helvetica;
  width: 90%;
  font-weight: 200;
  letter-spacing: 1px;
  margin: 25px auto 0 auto;
  background: rgb(234, 235, 235);
  color: rgb(25, 25, 25);
}

div, p {
  margin: 0 auto;
}

p {
  color: rgb(125, 125, 125);
  font-size: 0.85rem;
  text-align: center;
  margin-bottom: 17px;
}

#container {
  border: 1px solid gray;
  height: 200px;
  overflow-x: hidden;
  overflow-y: auto;
  /* Remember that a scrolling container element must have a position set. */
  position: relative;
  width: 50%;
}

#container div {
  padding-bottom: 10px;
}
```

```
/* jquery.velocity.js */

// Use scroll with the container option.
// Note: When you want to scroll the browser window itself, do not pass in a container.
$("#element3").velocity("scroll", { 
  container: $("#container"),
  duration: 800,
  delay: 500
});
```
You can also scroll elements within containers, and you can scroll horizontally. See Velocity’s scroll documentation for further information.

GSAP has ScrollToPlugin, which offers similar functionality and can automatically relinquish control when the user interacts with the scroll bar.

## JavaScript Awesomeness: Reverse 
Both Velocity and GSAP have reverse commands that enable you to animate an element back to the values prior to its last animation.

In Velocity, pass in reverse as Velocity’s first argument:

```
// Reverse defaults to the last call's options, which you can extend
Velocity(element, "reverse", { duration: 500 });
```

Click on the “JS” tab to see the code that powers this demo:


```
<p>
  Refresh this page to re-run the demo.
</p>

<div>
  Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.
</div>
```



```
body {
  font-family: "Helvetica Neue", Helvetica;
  width: 90%;
  font-weight: 200;
  letter-spacing: 1px;
  margin: 25px auto 0 auto;
  background: rgb(234, 235, 235);
  color: rgb(25, 25, 25);
}

div, p {
  margin: 0 auto;
}

p {
  color: rgb(125, 125, 125);
  font-size: 0.85rem;
  text-align: center;
  margin-bottom: 17px;
}

div {
  width: 35%;
  overflow: hidden;
}
```


```
/* jquery.js */
/* jquery.velocity.js */

// Animate opacity toward 0 then reverse back to 1.
$("div")
  .velocity( { opacity: 0 }, 2000)
  .velocity("reverse");
```
In GSAP, you can retain a reference to the animation object, then invoke its reverse() method at any time:

```
var tween = TweenMax.to(element, 1, {opacity:0.5});
tween.reverse();
```
## JavaScript Awesomeness: Transform Control
With CSS animation, all transform components — scale, translation, rotation and skew — are contained in a single CSS property and, consequently, cannot be animated independently using different durations, easings and start times.

For rich motion design, however, independent control is imperative. Let’s look at the dynamic transform control that’s achievable only in JavaScript. Click the buttons at any point during the animation:


```
<link href='//fonts.googleapis.com/css?family=Signika+Negative:300,400,700' rel='stylesheet' type='text/css'>

<div id="demo">
  
  <div id="field">
    <p>Notice that scale, rotation, and position can be animated independently using different eases and partially overlapping start/end times (impossible with CSS animations).</p>
    <div id="box">Independent transforms</div>
    
    <div id="controls">
      <button id="rotation">Spin rotation</button>
      <button id="rotationX">Spin rotationX</button>
      <button id="rotationY">Spin rotationY</button>
      <button id="move">wander (position)</button>
    </div>
  </div>
</div>
```

```
body {
  background-color:black;
  margin: 0;
  padding: 0;
  font-family: Signika Negative, sans-serif;
  font-weight: 300;
}
html, body {
  height: 100%;
}
#demo {
  display:table;
  width:100%;
  height:100%;
}
#field {
  position:relative;
  display:table-cell;
  height: 100%;
    overflow:hidden;
  text-align: center;
  vertical-align: middle;
}
#box {
  color: black;
  font-size:24px;
  padding: 10px 16px;
  border: 2px solid black;
  background: #9af600;
  background: linear-gradient(to bottom, #9af600 0%,#71B200 100%);
  display:inline-block;
  border-radius: 10px;
}
#field p {
  position: absolute;
  color: #999;
  top: 0px;
  padding: 0px 20px;
  text-align: left;
  z-index: -1000;
}
#controls {
  position:absolute;
  color: #999;
  width: 100%;
  bottom: 20px;
  text-align: center;
}
button {
  margin: 2px;
}
```

```
var $box = $("#box"),
    $field = $("#field"),
    rotation = 0,
    rotationX = 0, 
    rotationY = 0,
    wanderTween, ignoreRollovers;

//set a perspective on the container so we can see the 3D-ness
TweenLite.set($field, {perspective: 500});
//offset the origin on the z-axis to make the spins more interesting.
TweenLite.set($box, {transformOrigin:"center center -150px"});
//pulsate the box using scaleX and scaleY
TweenMax.to($box, 1.2, {scaleX:0.8, scaleY:0.8, force3D:true, yoyo:true, repeat:-1, ease:Power1.easeInOut});

//on rollover, rotate the box but to avoid excessive spinning, we'll desensitize rollovers during the first second of animation.
$box.hover(function() {
  if (!ignoreRollovers) {
    rotation += 360;
    ignoreRollovers = true;
    TweenLite.to($box, 2, {rotation:rotation, ease:Elastic.easeOut});
    TweenLite.delayedCall(1, function() {
      ignoreRollovers = false;
    });
  }
}, function() {});

$("#rotation").click(function() {
  rotation += 360;
  TweenLite.to($box, 2, {rotation:rotation, ease:Elastic.easeOut});
});

$("#rotationX").click(function() {
  rotationX += 360;
  TweenLite.to($box, 2, {rotationX:rotationX, ease:Power2.easeOut});
});

$("#rotationY").click(function() {
  rotationY += 360;
  TweenLite.to($box, 2, {rotationY:rotationY, ease:Power1.easeInOut});
});

$("#move").click(function() {
  if (wanderTween) {
    wanderTween.kill();
    wanderTween = null;
    TweenLite.to($box, 0.5, {x:0, y:0});
  } else {
    wander();
  }
});

//randomly choose a place on the screen and animate there, then do it again, and again.
function wander() {
  var x = (($field.width() - $box.width()) / 2) * (Math.random() * 1.8 - 0.9),
      y = (($field.height() - $box.height()) / 2) * (Math.random() * 1.4 - 0.7);
  wanderTween = TweenLite.to($box, 2.5, {x:x, y:y, ease:Power1.easeInOut, onComplete:wander});
}
```
Both Velocity and GSAP allow you to individually animate transform components:

```
// Velocity
/* First animation */
Velocity(element, { translateX: 500 }, 1000);
/* Trigger a second (concurrent) animation after 500 ms */
Velocity(element, { rotateZ: 45 }, { delay: 500, duration: 2000, queue: false });

// GSAP
/* First animation */
TweenMax.to(element, 1, { x: 500 });
/* Trigger a second (concurrent) animation after 500 ms */
TweenMax.to(element, 2, { rotation: 45, delay: 0.5 });
```
Wrapping Up Link

* Compared to CSS animation, JavaScript animation has better browser support and typically more features, and it provides a more manageable workflow for animation sequences.
* Animating in JavaScript doesn’t entail sacrificing speed (or hardware acceleration). Both Velocity and GSAP deliver blistering speed and hardware acceleration under the hood. No more messing around with null-transform hacks.
* You don’t need to use jQuery to take advantage of dedicated JavaScript animation libraries. However, if you do, you will not lose out on performance.

---

CSS-based animations that only trigger compositing can typically proceed without main thread intervention so should you get a GC pause or some other main thread halt, the CSS-based animation can continue. This is where the “myth” has originated and that assertion is not incorrect (and hence not a myth), but it is an incomplete picture.

What matters is _what exactly_ you animate with either JS or CSS, as that will govern your performance characteristics. If your animation changes a property that triggers layout or paint (which many do: http://csstriggers.com) it will be difficult to achieve 60fps, particularly on mobile. My hope is that in the future that’s not the case, but today that’s true.
In any case it’s nice to see pretty animations delivered through Velocity or GSAP. I still get frustrated that jQuery animates without requestAnimationFrame, but I guess that’s a topic for another day! :)