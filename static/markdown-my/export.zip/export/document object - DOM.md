# document object - DOM

## Events

<table id="memberListEvents" class="members" responsive="true">
<tbody><tr><th>Event</th><th>Description</th></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536913(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml"> click</strong></a>
</td><td data-th="Description">
<p>Fires when the user clicks the left mouse button on the object. </p>
<div class="alert"><strong>Note</strong>&nbsp;&nbsp;Starting with IE11, this event fires a <a href="https://msdn.microsoft.com/en-us/library/hh772103(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">MSPointerEvent</strong></a> object instead of  <a href="https://msdn.microsoft.com/en-us/library/ff974344(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">MouseEvent</strong></a>. You can use the MouseEvent.<a href="https://msdn.microsoft.com/en-us/library/hh772359(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerType</strong></a> property to determine the type of contact that the click originated from (touch, mouse, or pen).</div>
<div>&nbsp;</div>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536785(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">abort</strong></a>
</td><td data-th="Description">
<p>Fires when the user aborts the download. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536787(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">activate</strong></a>
</td><td data-th="Description">
<p>Fires when the object is set as the <a href="https://msdn.microsoft.com/en-us/library/ms533065(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">active element</strong></a>.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536791(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">beforeactivate</strong></a>
</td><td data-th="Description">
<p>Fires immediately before the object is set as the <a href="https://msdn.microsoft.com/en-us/library/ms533065(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">active element</strong></a>.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536904(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">beforeeditfocus</strong></a>
</td><td data-th="Description">
<p>Fires before an object contained in an editable element enters a <em>UI Activation</em> state or when an editable container object is <em>control selection</em>.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536909(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">blur</strong></a>
</td><td data-th="Description">
<p>Fires when the object loses the input focus. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974144(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">canplay</strong></a>
</td><td data-th="Description">
<p>Occurs when playback is possible, but would require further buffering. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974147(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">canplaythrough</strong></a>
</td><td data-th="Description">
<p>Occurs when playback to end is possible without requiring a stop for further buffering. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536911(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">cellchange</strong></a>
</td><td data-th="Description">
<p>Fires when data changes in the data provider.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536912(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">change</strong></a>
</td><td data-th="Description">
<p>Fires when the contents of the object or selection have changed. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536914(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">contextmenu</strong></a>
</td><td data-th="Description">
<p>Fires when the user clicks the right mouse button in the client area, opening the context menu. </p>
<div class="alert"><strong>Note</strong>&nbsp;&nbsp;Starting with IE11, this event fires a <a href="https://msdn.microsoft.com/en-us/library/hh772103(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">MSPointerEvent</strong></a> object instead of <a href="https://msdn.microsoft.com/en-us/library/ff974344(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">MouseEvent</strong></a>. You can use the MouseEvent.<a href="https://msdn.microsoft.com/en-us/library/hh772359(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerType</strong></a> property to determine the type of contact that the click originated from (touch, mouse, or pen).</div>
<div>&nbsp;</div>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536915(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">controlselect</strong></a>
</td><td data-th="Description">
<p>Fires when the user is about to make a <em>control selection</em> of the object.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536918(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">dataavailable</strong></a>
</td><td data-th="Description">
<p>Fires periodically as data arrives from data source objects that asynchronously transmit their data. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536919(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">datasetchanged</strong></a>
</td><td data-th="Description">
<p>Fires when the data set exposed by a data source object changes. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536921(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">dblclick</strong></a>
</td><td data-th="Description">
<p>Fires when the user double-clicks the object. </p>
<div class="alert"><strong>Note</strong>&nbsp;&nbsp;Starting with IE11, this event fires a <a href="https://msdn.microsoft.com/en-us/library/hh772103(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">MSPointerEvent</strong></a> object instead of a <a href="https://msdn.microsoft.com/en-us/library/ff974344(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">MouseEvent</strong></a>. You can use the MouseEvent.<a href="https://msdn.microsoft.com/en-us/library/hh772359(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerType</strong></a> property to determine the type of contact that the click originated from (touch, mouse, or pen).</div>
<div>&nbsp;</div>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536922(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">deactivate</strong></a>
</td><td data-th="Description">
<p>Fires when the <a href="https://msdn.microsoft.com/en-us/library/ms533065(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">activeElement</strong></a> is changed from the current object to another object in the parent document.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/hh869434(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">DOMContentLoaded</strong></a>
</td><td data-th="Description">
<p>Fires when a webpage has been parsed, but before all resources have been fully downloaded.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536923(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">drag</strong></a>
</td><td data-th="Description">
<p>Fires on the source object continuously during a drag operation.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536924(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">dragend</strong></a>
</td><td data-th="Description">
<p>Fires on the source object when the user releases the mouse at the close of a drag operation.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536925(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">dragenter</strong></a>
</td><td data-th="Description">
<p>Fires on the target element when the user drags the object to a valid drop target.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536926(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">dragleave</strong></a>
</td><td data-th="Description">
<p>Fires on the target object when the user moves the mouse out of a valid drop target during a drag operation.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536927(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">dragover</strong></a>
</td><td data-th="Description">
<p>Fires on the target element continuously while the user drags the object over a valid drop target.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536928(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">dragstart</strong></a>
</td><td data-th="Description">
<p>Fires on the source object when the user starts to drag a text selection or selected object. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536929(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">drop</strong></a>
</td><td data-th="Description">
<p>Fires on the target object when the mouse button is released during a drag-and-drop operation.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974149(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">durationchange</strong></a>
</td><td data-th="Description">
<p>Occurs when the <a href="https://msdn.microsoft.com/en-us/library/ff974750(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">duration</strong></a> attribute is updated. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974151(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">emptied</strong></a>
</td><td data-th="Description">
<p>Occurs when the media element is reset to its initial state. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974154(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">ended</strong></a>
</td><td data-th="Description">
<p>Occurs when the end of playback is reached. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/cc197053(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">error</strong></a>
</td><td data-th="Description">
<p>Fires when an error occurs during object loading.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536931(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">errorupdate</strong></a>
</td><td data-th="Description">
<p>Fires on a databound object when an error occurs while updating the associated data in the data source object. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536934(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">focus</strong></a>
</td><td data-th="Description">
<p>Fires when the object receives focus. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536935(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">focusin</strong></a>
</td><td data-th="Description">
<p>Fires for an element just prior to setting focus on that element.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536936(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">focusout</strong></a>
</td><td data-th="Description">
<p>Fires for the current element with focus immediately after moving focus to another element. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/dn312066(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">fullscreenChange</strong></a>
</td><td data-th="Description">
<p>Fires when an element enters or exits full-screen mode. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/dn312067(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">fullscreenError</strong></a>
</td><td data-th="Description">
<p>Fires when an element can't be displayed in full-screen mode.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/hh771904(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">gotpointercapture</strong></a>
</td><td data-th="Description">
<p>Dispatched prior to the dispatch of the first event after pointer capture is set for a pointer. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536937(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">help</strong></a>
</td><td data-th="Description">
<p>Fires when the user presses the F1 key while the client is the active window. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/gg592978(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">input</strong></a>
</td><td data-th="Description">
<p>Occurs when the text content of an element is changed through the user interface. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536938(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">keydown</strong></a>
</td><td data-th="Description">
<p>Fires when the user presses a key.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536939(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">keypress</strong></a>
</td><td data-th="Description">
<p>Fires when the user presses an alphanumeric key.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/cc197055(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">load</strong></a>
</td><td data-th="Description">
<p>Fires immediately after the client loads the object. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974155(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">loadeddata</strong></a>
</td><td data-th="Description">
<p>Occurs when media data is loaded at the current playback position. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974157(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">loadedmetadata</strong></a>
</td><td data-th="Description">
<p>Occurs when the duration and dimensions of the media have been determined. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974159(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">loadstart</strong></a>
</td><td data-th="Description">
<p>Occurs when Internet Explorer begins looking for media data. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/hh771907(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">lostpointercapture</strong></a>
</td><td data-th="Description">
<p>Dispatched after pointer capture is released for a pointer. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536944(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">mousedown</strong></a>
</td><td data-th="Description">
<p>Fires when the user clicks the object with either mouse button. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536947(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">mousemove</strong></a>
</td><td data-th="Description">
<p>Fires when the user moves the mouse over the object. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536948(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">mouseout</strong></a>
</td><td data-th="Description">
<p>Fires when the user moves the mouse pointer outside the boundaries of the object. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536949(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">mouseover</strong></a>
</td><td data-th="Description">
<p>Fires when the user moves the mouse pointer into the object. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536950(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">mouseup</strong></a>
</td><td data-th="Description">
<p>Fires when the user releases a mouse button while the mouse is over the object. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536951(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">mousewheel</strong></a>
</td><td data-th="Description">
<p>Fires when the wheel button is rotated. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/hh771910(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">MSPointerHover</strong></a>
</td><td data-th="Description">
<p>Event that is triggered when a contact (normally a pen) moves over an element without touching the surface. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536903(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">onbeforedeactivate</strong></a>
</td><td data-th="Description">
<p>Fires immediately before the <a href="https://msdn.microsoft.com/en-us/library/ms533065(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">activeElement</strong></a> is changed from the current object to another object in the parent document.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536920(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">ondatasetcomplete</strong></a>
</td><td data-th="Description">
<p>Fires to indicate that all data is available from the data source object. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536940(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">onkeyup</strong></a>
</td><td data-th="Description">
<p>Fires when the user releases a key.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff975580(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">onmssitemodejumplistitemremoved</strong></a>
</td><td data-th="Description">
<p>Occurs when <a href="https://msdn.microsoft.com/en-us/library/ff976318(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msSiteModeShowJumpList</strong></a> is called, and an item has been removed from a Jump List by the user. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff975582(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">onmsthumbnailclick</strong></a>
</td><td data-th="Description">
<p>Occurs when a user clicks a button in a Thumbnail Toolbar.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536967(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">onselect</strong></a>
</td><td data-th="Description">
<p>Fires when the current selection changes.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/dn792851(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">ontouchcancel</strong></a>
</td><td data-th="Description">
<p>Event indicating that the touch point has been canceled/disrupted.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/dn792852(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">ontouchend</strong></a>
</td><td data-th="Description">
<p>Event indicating that the touch point has ceased to exist.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/dn792853(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">ontouchmove</strong></a>
</td><td data-th="Description">
<p>Event indicating that the touch point has moved along the touch surface.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/dn792854(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">ontouchstart</strong></a>
</td><td data-th="Description">
<p>Event indicating that the user has touched the surface of a touch capable device.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974160(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pause</strong></a>
</td><td data-th="Description">
<p>Occurs when playback is paused. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974163(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">play</strong></a>
</td><td data-th="Description">
<p>Occurs when the <a href="https://msdn.microsoft.com/en-us/library/ff975194(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">play</strong></a> method is requested. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974166(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">playing</strong></a>
</td><td data-th="Description">
<p>Occurs when the audio or video has started playing. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/hh846776(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointercancel</strong></a>
</td><td data-th="Description">
<p> Dispatched when either (1) the system has determined that a pointer is unlikely to continue to produce events (for example, due to a hardware event), or (2) after having fired the <a href="https://msdn.microsoft.com/en-us/library/hh771909(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerdown</strong></a> event, the pointer is subsequently used to manipulate the page viewport (for example, panning or zooming). </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/hh771909(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerdown</strong></a>
</td><td data-th="Description">
<p>Dispatched when a pointer enters the state of having a non-zero value for the <a href="https://msdn.microsoft.com/en-us/library/ff974878(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">buttons</strong></a> property.  </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/dn254944(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerenter</strong></a>
</td><td data-th="Description">
<p>Dispatched when a pointing device is moved into the hit test boundaries of an element or one of its descendants, including as a result of a <a href="https://msdn.microsoft.com/en-us/library/hh771909(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerdown</strong></a> event from a device that does not support hover.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/dn254945(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerleave</strong></a>
</td><td data-th="Description">
<p>Dispatched when a pointing device is moved outside of the hit test boundaries of an element or one of its descendants, including as a result of a <a href="https://msdn.microsoft.com/en-us/library/hh771909(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerdown</strong></a> event from a device that does not support hover.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/mt560349(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerlockchange</strong></a>
</td><td data-th="Description">
<p>Fired upon a successful pointer lock request.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/mt560350(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerlockerror</strong></a>
</td><td data-th="Description">
<p>Fired .</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/hh771911(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointermove</strong></a>
</td><td data-th="Description">
<p>Dispatched when a pointer changes coordinates, button state, pressure, tilt, or contact geometry (for example, <a href="https://msdn.microsoft.com/en-us/library/dn255065(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">width</strong></a> and <a href="https://msdn.microsoft.com/en-us/library/dn255064(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">height</strong></a>). </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/hh771912(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerout</strong></a>
</td><td data-th="Description">
<p>Dispatched when any of the following occurs:</p>
<ul>
<li>A pointing device is moved out of the hit test boundaries of an element</li>
<li>After firing the <a href="https://msdn.microsoft.com/en-us/library/hh771914(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerup</strong></a> event for a device that does not support hover</li>
<li>After firing the <a href="https://msdn.microsoft.com/en-us/library/hh846776(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointercancel</strong></a> event</li>
</ul>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/hh771913(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerover</strong></a>
</td><td data-th="Description">
<p>Dispatched when a pointing device is moved into the hit test boundaries of an element. Also dispatched prior to a <a href="https://msdn.microsoft.com/en-us/library/hh771909(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerdown</strong></a> event for devices that do not support hover. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/hh771914(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerup</strong></a>
</td><td data-th="Description">
<p>Dispatched when a pointer leaves the state of having a non-zero value for the <a href="https://msdn.microsoft.com/en-us/library/ff974878(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">buttons</strong></a> property.

</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974168(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">progress</strong></a>
</td><td data-th="Description">
<p>Occurs to indicate progress while downloading media data. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536956(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">propertychange</strong></a>
</td><td data-th="Description">
<p>Fires when a property changes on the object.</p>
<div class="alert"><strong>Note</strong>&nbsp;&nbsp;The <a href="https://msdn.microsoft.com/en-us/library/ms536956(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">onpropertychange</strong></a> event is only supported in conjunction with the legacy <a href="https://msdn.microsoft.com/en-us/library/ms536343(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">attachEvent</strong></a> IE-only   event registration model, which has  <a href="https://msdn.microsoft.com/en-us/library/ff986080(v=vs.85).aspx">deprecated</a> since  Internet Explorer&nbsp;9 in favor of the  W3C standard "<a href="https://msdn.microsoft.com/en-us/library/ff975245(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">addEventListener</strong></a>" event model.</div>
<div>&nbsp;</div>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974169(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">ratechange</strong></a>
</td><td data-th="Description">
<p>Occurs when the playback rate is increased or decreased. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536957(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">readystatechange</strong></a>
</td><td data-th="Description">
<p>Fires when the state of the object has changed. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536958(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">reset</strong></a>
</td><td data-th="Description">
<p>Fires when the user resets a form. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536962(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">rowenter</strong></a>
</td><td data-th="Description">
<p>Fires to indicate that the current row has changed in the data source and new data values are available on the object. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536963(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">rowexit</strong></a>
</td><td data-th="Description">
<p>Fires just before the data source control changes the current row in the object. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536964(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">rowsdelete</strong></a>
</td><td data-th="Description">
<p>Fires when rows are about to be deleted from the recordset. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536965(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">rowsinserted</strong></a>
</td><td data-th="Description">
<p>Fires just after new rows are inserted in the current recordset.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536966(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scroll</strong></a>
</td><td data-th="Description">
<p>Fires when the user repositions the scroll box in the scroll bar on the object. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974171(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">seeked</strong></a>
</td><td data-th="Description">
<p>Occurs when the seek operation ends. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974175(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">seeking</strong></a>
</td><td data-th="Description">
<p>Occurs when the current playback position is moved. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536968(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">selectionchange</strong></a>
</td><td data-th="Description">
<p>Fires when the selection state of a document changes.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974179(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">stalled</strong></a>
</td><td data-th="Description">
<p>Occurs when the download has stopped. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ms536971(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">stop</strong></a>
</td><td data-th="Description">
<p>Fires when the user clicks the <strong>Stop</strong> button or leaves the document.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/cc197059(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">storage</strong></a>
</td><td data-th="Description">
<p>Fires when a Web Storage area is updated.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/cc197060(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">storagecommit</strong></a>
</td><td data-th="Description">
<p>Fires when a local Web Storage area is written to disk. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974182(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">suspend</strong></a>
</td><td data-th="Description">
<p>Occurs if the load operation is  intentionally halted. Starting in Microsoft Edge, also occurs if the media network state becomes <strong>NETWORK_IDLE</strong>. </p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974185(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">timeupdate</strong></a>
</td><td data-th="Description">
<p>Occurs to indicate the current playback position.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/hh772093(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">visibilitychange</strong></a>
</td><td data-th="Description">
<p>Triggered when the <a href="https://msdn.microsoft.com/en-us/library/hh773170(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">visibilityState</strong></a> property changes.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974188(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">volumechange</strong></a>
</td><td data-th="Description">
<p>Occurs when the volume is changed, or playback is muted or unmuted.</p>
</td></tr>
<tr data="declared;"><td data-th="Event">
<a href="https://msdn.microsoft.com/en-us/library/ff974190(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">waiting</strong></a>
</td><td data-th="Description">
<p>Occurs when playback stops because the next frame of a video resource is not available. </p>
</td></tr>
</tbody></table>


## Methods

<table id="memberListMethods" class="members" responsive="true">
<tbody><tr><th>Method</th><th>Description</th></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975245(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">addEventListener</strong></a>
</td><td data-th="Description">
<p>Registers an event handler for the specified event type. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975209(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">adoptNode</strong></a>
</td><td data-th="Description">
<p>Tries to move a node from one document to the document  that  the <strong>document</strong> object displays.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536343(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">attachEvent</strong></a>
</td><td data-th="Description">
<div class="alert"><strong>Note</strong>&nbsp;&nbsp;
<a href="https://msdn.microsoft.com/en-us/library/ms536343(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">attachEvent</strong></a>  is no longer supported. Starting with IE11, use <a href="https://msdn.microsoft.com/en-us/library/ff975245(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">addEventListener</strong></a>. For info, see <a href="https://msdn.microsoft.com/en-us/library/bg182625(v=vs.85).aspx">Compatibility changes</a>.</div>
<div>&nbsp;</div>
<p>Binds the specified function to an event, so that the function gets called whenever the event fires on the object.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/dn469423(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">captureEvents </strong></a>
</td><td data-th="Description">
<p>No appreciable effect.  Do not use.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536361(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">clear</strong></a>
</td><td data-th="Description">
<p> To clear all elements in the current document, use <strong>document</strong>.<a href="https://msdn.microsoft.com/en-us/library/ms536782(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">write</strong></a>(""), followed by <strong>document</strong>.<a href="https://msdn.microsoft.com/en-us/library/ms536369(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">close</strong></a>.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536369(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">close</strong></a>
</td><td data-th="Description">
<p>Closes an output stream and forces the sent data to display.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975125(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">compareDocumentPosition</strong></a>
</td><td data-th="Description">
<p>Compares the position of two nodes in a document.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536379(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">createAttribute</strong></a>
</td><td data-th="Description">
<p>Creates an <a href="https://msdn.microsoft.com/en-us/library/ms535187(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">attribute</strong></a> object&nbsp;with a specified <a href="https://msdn.microsoft.com/en-us/library/ms534184(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">name</strong></a>.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975211(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">createAttributeNS</strong></a>
</td><td data-th="Description">
<p>Creates a reference to an <a href="https://msdn.microsoft.com/en-us/library/ms535187(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">attribute</strong></a> object that is associated with an XML namespace.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975212(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">createCDATASection</strong></a>
</td><td data-th="Description">
<p>Creates a CDATA section  that contains   the specified text. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536383(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">createComment</strong></a>
</td><td data-th="Description">
<p>Creates a <a href="https://msdn.microsoft.com/en-us/library/ms535229(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">comment</strong></a> object&nbsp;with the specified <a href="https://msdn.microsoft.com/en-us/library/ms533702(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">data</strong></a>.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536387(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">createDocumentFragment</strong></a>
</td><td data-th="Description">
<p>Creates a new document.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536389(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">createElement</strong></a>
</td><td data-th="Description">
<p>Creates an instance of the element for the specified tag.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975213(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">createElementNS</strong></a>
</td><td data-th="Description">
<p>Creates an element from the specified namespace.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975304(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">createEvent</strong></a>
</td><td data-th="Description">
<p>Creates a DOM event of the specified type. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536390(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">createEventObject</strong></a>
</td><td data-th="Description">
<p>Generates an <a href="https://msdn.microsoft.com/en-us/library/ms535863(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">event</strong></a> object to pass event context information when you use the <a href="https://msdn.microsoft.com/en-us/library/ms536423(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">fireEvent</strong></a> method.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975301(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">createNodeIterator</strong></a>
</td><td data-th="Description">
<p>Creates a <a href="https://msdn.microsoft.com/en-us/library/ff974357(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">NodeIterator</strong></a> object that you can use to traverse filtered lists of nodes or elements in a document.  </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975215(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">createProcessingInstruction</strong></a>
</td><td data-th="Description">
<p>Creates a <a href="https://msdn.microsoft.com/en-us/library/ff975123(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">processing instruction</strong></a> for an XML parser. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975303(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">createRange</strong></a>
</td><td data-th="Description">
<p>Returns an empty range object that has both of its boundary points positioned at the beginning of the document.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms531194(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">createStyleSheet</strong></a>
</td><td data-th="Description">
<div class="alert"><strong>Note</strong>&nbsp;&nbsp;
<a href="https://msdn.microsoft.com/en-us/library/ms531194(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">createStyleSheet</strong></a>  is no longer supported. Starting with IE11, use document.<a href="https://msdn.microsoft.com/en-us/library/ms536389(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">createElement</strong></a>('style'). For info, see <a href="https://msdn.microsoft.com/en-us/library/bg182625(v=vs.85).aspx">Compatibility changes</a>.</div>
<div>&nbsp;</div>
<p>Creates a style sheet for the document. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536400(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">createTextNode</strong></a>
</td><td data-th="Description">
<p>Creates a text string from the specified value. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/dn792849(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">createTouch</strong></a>
</td><td data-th="Description">
<p>Creates a <a href="https://msdn.microsoft.com/en-us/library/dn792855(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">Touch</strong></a> object with the specified attributes.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/dn792850(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">createTouchList</strong></a>
</td><td data-th="Description">
<p>Creates a <a href="https://msdn.microsoft.com/en-us/library/dn792864(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">TouchList</strong></a> array consisting of zero or more <a href="https://msdn.microsoft.com/en-us/library/dn792855(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">Touch</strong></a> objects. Calling this method with no arguments creates a <strong>TouchList</strong> array with no objects in it whose <code>length</code> is 0 (zero). </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975302(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">createTreeWalker</strong></a>
</td><td data-th="Description">
<p>Creates a <a href="https://msdn.microsoft.com/en-us/library/ff974360(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">TreeWalker</strong></a> object that you can use to traverse filtered lists of nodes or elements in a document. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536411(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">detachEvent</strong></a>
</td><td data-th="Description">
<p>Unbinds the specified function from the event, so that the function stops receiving notifications when the event fires.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975247(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">dispatchEvent</strong></a>
</td><td data-th="Description">
<p>Sends an event to the current element. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536417(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">elementFromPoint</strong></a>
</td><td data-th="Description">
<p>Returns the element for the specified <em>x</em> coordinate and the specified <em>y</em> coordinate. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536419(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">execCommand</strong></a>
</td><td data-th="Description">
<p>Executes a command on the current document, current selection, or the given range.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/dd758061(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">execCommandShowHelp</strong></a>
</td><td data-th="Description">
<p>Displays help information for the given command identifier.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/dn254936(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">exitFullscreen</strong></a>
</td><td data-th="Description">
<p>Causes an element to stop being displayed in  full-screen mode.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/mt560344(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">exitPointerLock</strong></a>
</td><td data-th="Description">
<p>Exits the document out of pointer lock state.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536425(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">focus</strong></a>
</td><td data-th="Description">
<p>Causes the element to receive the focus and executes the code specified by the <a href="https://msdn.microsoft.com/en-us/library/ms536934(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">onfocus</strong></a> event. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536437(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">getElementById</strong></a>
</td><td data-th="Description">
<p>Returns a reference to the first object with the specified 
		value of the <a href="https://msdn.microsoft.com/en-us/library/ms533880(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">ID</strong></a> or <a href="https://msdn.microsoft.com/en-us/library/ms534184(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">NAME</strong></a> attribute.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536438(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">getElementsByName</strong></a>
</td><td data-th="Description">
<p>Gets a collection of objects based on the value of the <a href="https://msdn.microsoft.com/en-us/library/ms534184(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">NAME</strong></a> or <a href="https://msdn.microsoft.com/en-us/library/ms533880(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">ID</strong></a> attribute.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536439(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">getElementsByTagName</strong></a>
</td><td data-th="Description">
<p>Retrieves a collection of objects based on the specified element name.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975218(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">getElementsByTagNameNS</strong></a>
</td><td data-th="Description">
<p>Gets a collection of nodes  that match  an element name from the specified namespace.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975169(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">getSelection</strong></a>
</td><td data-th="Description">
<p>Returns an object that represents the current <a href="https://msdn.microsoft.com/en-us/library/ff974359(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">selection</strong></a> of the document.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536447(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">hasFocus</strong></a>
</td><td data-th="Description">
<p>Gets a value indicating whether the object currently has focus.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/gg130964(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">importNode</strong></a>
</td><td data-th="Description">
<p>Imports a node from another document into the the document that the <strong>document</strong> object displays.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975127(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">isDefaultNamespace</strong></a>
</td><td data-th="Description">
<p>Indicates whether or not a namespace is the default namespace for a document.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975128(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">isEqualNode</strong></a>
</td><td data-th="Description">
<p>Determines if two nodes are equal.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975129(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">isSameNode</strong></a>
</td><td data-th="Description">
<p>Determines if two node references refer to the same node.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975130(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">isSupported</strong></a>
</td><td data-th="Description">
<p>Returns a value indicating whether or not the object supports a specific DOM standard.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975158(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">lookupNamespaceURI</strong></a>
</td><td data-th="Description">
<p>Gets the URI of the namespace associated with a namespace prefix, if any.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975159(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">lookupPrefix</strong></a>
</td><td data-th="Description">
<p>Gets the namespace prefix associated with a URI, if any.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536646(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">normalize</strong></a>
</td><td data-th="Description">
<p>Merges adjacent DOM objects to produce a normalized document object model.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536652(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">open</strong></a>
</td><td data-th="Description">
<p>Opens a <strong>document</strong> for writing. </p>
<div class="alert"><strong>Note</strong>&nbsp;&nbsp;Can also be used to behave like the <a href="https://msdn.microsoft.com/en-us/library/ms536651(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">open</strong></a> method of the <a href="https://msdn.microsoft.com/en-us/library/ms535873(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">window</strong></a> object  if the <em>url</em>, <em>name</em>, <em>features</em>, and <em>replace</em> parameters are specified using the following syntax:</div>
<div>&nbsp;</div>
<p>var retval = document.open(url, name, features, replace);</p>
<p>Refer to the window.<a href="https://msdn.microsoft.com/en-us/library/ms536651(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">open</strong></a> reference for usage.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536676(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">queryCommandEnabled</strong></a>
</td><td data-th="Description">
<p>Returns a Boolean value that indicates whether a specified command can be successfully executed using <a href="https://msdn.microsoft.com/en-us/library/ms536419(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">execCommand</strong></a>, given the current state of the document.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536678(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">queryCommandIndeterm</strong></a>
</td><td data-th="Description">
<p>Returns a Boolean value that indicates whether the specified command is in the indeterminate state.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536679(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">queryCommandState</strong></a>
</td><td data-th="Description">
<p>Returns a Boolean value that indicates the current state of the command.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536681(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">queryCommandSupported</strong></a>
</td><td data-th="Description">
<p>Returns a Boolean value that indicates whether the current command is supported on the current range.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/dd758063(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">queryCommandText</strong></a>
</td><td data-th="Description">
<p>Retrieves the string associated with a command.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536683(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">queryCommandValue</strong></a>
</td><td data-th="Description">
<p>Returns the current value of the document, range, or current selection for the given command.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/cc288169(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">querySelector</strong></a>
</td><td data-th="Description">
<p>
	        Retrieves the first DOM 
		    element node from descendants of the starting element node
			that match any selector within the supplied selector string.
    </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/cc304115(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">querySelectorAll</strong></a>
</td><td data-th="Description">
<p>
		    Retrieves all DOM 
		    element nodes from descendants of the starting element node 
		    that match any selector within the supplied selector strings.
    </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536685(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">recalc</strong></a>
</td><td data-th="Description">
<p>This element is obsolete and should no longer be used. Recalculates all dynamic properties in the current document.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536689(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">releaseCapture</strong></a>
</td><td data-th="Description">
<p>Removes mouse capture from the object in the current document.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/dn469425(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">releaseEvents</strong></a>
</td><td data-th="Description">
<p>No appreciable effect.  Do not use.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ff975250(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">removeEventListener</strong></a>
</td><td data-th="Description">
<p>Removes an event handler that  the  <a href="https://msdn.microsoft.com/en-us/library/ff975245(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">addEventListener</strong></a> method registered. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536742(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">setCapture</strong></a>
</td><td data-th="Description">
<p>Sets the mouse capture to the object that belongs to the current document. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/cc848923(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">updateSettings</strong></a>
</td><td data-th="Description">
<p>Allows updating the print settings for the page.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536782(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">write</strong></a>
</td><td data-th="Description">
<p>Writes one or more HTML expressions to a document in the specified window. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536783(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">writeln</strong></a>
</td><td data-th="Description">
<p>Writes one or more HTML expressions, followed by a carriage return, to a document in the specified window. </p>
</td></tr>
</tbody></table>

## Properties

<table id="memberListProperties" class="members" responsive="true">
<tbody><tr><th>Property</th><th>Access type</th><th>Description</th></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533065(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">activeElement</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets the object that has the focus when the parent <strong>document</strong> has focus.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533071(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">alinkColor</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or gets the color of all active links in the document. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms537435(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">anchors</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves a collection of all <a href="https://msdn.microsoft.com/en-us/library/ms535173(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">a</strong></a> objects that have a <a href="https://msdn.microsoft.com/en-us/library/ms534182(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">name</strong></a> and/or <a href="https://msdn.microsoft.com/en-us/library/ms533880(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">id</strong></a> property. Objects in this collection are in HTML source order.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533506(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">bgColor</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Deprecated. Sets or retrieves a value that indicates the background color behind the object. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/gg592985(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">body</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets an interface pointer to the document <a href="https://msdn.microsoft.com/en-us/library/ms535205(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">body</strong></a> object. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ff974774(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">characterSet</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets the name of the character set that is  used to encode  the document.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533553(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">charset</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or retrieves the character set used to encode the object.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/cc196984(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">compatible</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves the collection of user agents and versions declared in the <code>X-UA-Compatible</code>&nbsp;<a href="https://msdn.microsoft.com/en-us/library/ms535853(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">meta</strong></a> tag. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533687(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">compatMode</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>
      Gets a value that indicates whether standards-compliant mode is switched on for the object.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/cc848898(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">constructor</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Returns a reference to the constructor of an object.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533693(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">cookie</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or gets the string value of a cookie.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533714(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">defaultCharset</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets the default character set from the current regional language settings.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ff974775(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">defaultView</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets  a reference to the <a href="https://msdn.microsoft.com/en-us/library/ms535873(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">window</strong></a> object for the document.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533720(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">designMode</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or gets a value that indicates whether the document can be edited.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533731(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">dir</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or retrieves a value that indicates the reading order of the object. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533737(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">doctype</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets an object that represents the <a href="https://msdn.microsoft.com/en-us/library/ms535242(v=vs.85).aspx">document type declaration</a> that is associated with the current <strong>document</strong>.   </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533739(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">documentElement</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets a reference to the root node of the document. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/cc196988(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">documentMode</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves the document compatibility mode of the document.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533740(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">domain</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or gets the security domain of the document. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533747(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">expando</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or retrieves a value indicating whether arbitrary variables can be created within the object.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533749(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">fgColor</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or gets the foreground (text) color of the document. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533750(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">fileCreatedDate</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves the date the file was created. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533751(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">fileModifiedDate</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves the date the file was last modified. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533752(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">fileSize</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<div class="alert"><strong>Note</strong>&nbsp;&nbsp;
<a href="https://msdn.microsoft.com/en-us/library/ms533752(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">fileSize</strong></a>  is no longer supported. Starting with IE11, use <a href="https://msdn.microsoft.com/en-us/library/ms535874(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">XMLHttpRequest</strong></a> to get the resource. For info, see <a href="https://msdn.microsoft.com/en-us/library/bg182625(v=vs.85).aspx">Compatibility changes</a>.</div>
<div>&nbsp;</div>
<p>Retrieves the file size. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/dn254937(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">fullscreenElement</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read-only</td><td data-th="Description">
<p>Returns the current full-screen  element. If there's more than one element in the full-screen mode element stack, then this property returns the top element.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/dn254938(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">fullscreenEnabled</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read-only</td><td data-th="Description">
<p>Returns true if an element is in full-screen mode; otherwise returns false.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/gg593004(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">head</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets the <a href="https://msdn.microsoft.com/en-us/library/ms535252(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">head</strong></a> element of the document. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh826023(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">images</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves a collection, in source order, of <a href="https://msdn.microsoft.com/en-us/library/ms535259(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">img</strong></a> objects in the document.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533884(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">implementation</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets the <a href="https://msdn.microsoft.com/en-us/library/ms535865(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">implementation</strong></a> object of the current <strong>document</strong>. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ff974776(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">inputEncoding</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets  the character encoding  that is used for the text that is loaded into the <strong>document</strong> object.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533946(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">lastModified</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets the date that the document was last modified, if the document supplies one. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534117(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">linkColor</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or gets the color of the document links. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ff974770(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">localName</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves the local name of the fully qualified XML declaration for a node.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ff974771(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">namespaceURI</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves the namespace URI of the fully qualified XML declaration for a node.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534331(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">parentWindow</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets a reference to the container object of the window.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/mt560345(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerLockElement</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves the  target element for mouse events under pointer lock state.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ff974772(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">prefix</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves the local name of the fully qualified XML declaration for a node.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534353(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">protocol</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or retrieves the protocol portion of a URL. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534359(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">readyState</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves a value that indicates the current state of the object.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534365(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">referrer</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets the URL of the location that referred the user to the current document.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ff971995(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">rootElement</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets the root <a href="https://msdn.microsoft.com/en-us/library/ff972122(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">svg</strong></a> element in the document hierarchy.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/mt171558(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scrollingElement</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read-only</td><td data-th="Description">
<p>Gets a reference to the element that scrolls in the document.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ff974773(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">textContent</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or retrieves the text content of an object and any child objects.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534683(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">title</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or retrieves advisory information (a ToolTip) for the object. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534704(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">uniqueID</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves an autogenerated, unique identifier for the object. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534708(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">URL</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or gets the URL for the current document. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534709(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">URLUnencoded</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets the URL for the <strong>document</strong>, stripped of any character encoding.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh773170(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">visibilityState</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read-only</td><td data-th="Description">
<p>Returns the visibility state of a webpage. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms535139(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">vlinkColor</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Sets or gets the color of the links that the user has visited.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ff974778(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">xmlEncoding</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets  a value  that represents  the character encoding  that is specified in the declaration of an XML document.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ff974779(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">xmlStandalone</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets or sets the value of the <strong>standalone    </strong> attribute in the declaration of an XML document.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ff974780(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">xmlVersion</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets or sets the <strong>version</strong> attribute  that is specified in the declaration of an XML document. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms535163(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">XSLDocument</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves a reference to the top-level node of the XSL document.</p>
</td></tr>
</tbody></table>