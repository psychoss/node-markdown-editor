# Generated and Replaced Content - CSS

<table responsive="true">
<tbody><tr><th>Property</th><th>Description</th></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/cc304061(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">content</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies 
			generated content to insert before or after an element.
    </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/cc848858(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">counter-increment</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves 
			a list of counters to increment.
    </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/cc848859(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">counter-reset</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves 
			a list of counters to create or reset to zero.
    </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530751(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">display</strong></a>
</p>
</td><td data-th="Description">
<p>Gets or sets a value that indicates  whether and how the object is rendered.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dd229918(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">quotes</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  the pairs of strings to be used as quotes in generated content.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530789(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">list-style</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves up to three separate <a href="https://msdn.microsoft.com/en-us/library/ms530789(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">list-style</strong></a> properties of the object.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530793(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">list-style-image</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  a value that indicates which image to use as a list-item marker for the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530795(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">list-style-position</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  a variable that indicates how the list-item marker is drawn relative to the content of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530797(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">list-style-type</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  the predefined type of the line-item marker for the object. </p>
</td></tr>
</tbody></table>