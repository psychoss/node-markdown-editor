# 005 - Canvas 蝴蝶结


```
html,body{
				height: 100%;
				background: #000;
			}
```


```
var W = window.innerWidth;
		var H = window.innerHeight;
		var sin = Math.sin;
		var cos = Math.cos;
		var PI = Math.PI;
		var canvas = document.createElement("canvas");
		var pen = canvas.getContext("2d");
		var t = 0;
		canvas.height = H;
		canvas.width =W;
		document.body.appendChild(canvas);
		var grad = pen.createRadialGradient(W/2,H/2,0,W/2,H/2,500);
		grad.addColorStop(0,"red");
		grad.addColorStop(.5,"yellow");
		grad.addColorStop(1,"green");
		pen.strokeStyle=grad;
		draw();
		function draw(){
		  pen.clearRect(0,0,W,H);
		  pen.beginPath();
			for(var i = 0; i <= 100 * Math.PI; i+= .1){
				var θ = i;
				var a = 50;
      var constantPart = Math.pow(Math.E,cos(θ+PI/2)) - 2 * cos(4*θ) + Math.pow(sin(θ/12*t),5);
					var x = a*cos(θ) * constantPart + W/2;
					var y = a*sin(θ)*constantPart + H/2;
				pen.lineTo(x,y);
			}
			pen.lineWidth = .1;
			pen.stroke();
			t += .01;
			if(t >= 2 * PI){
				t = 0;
			}
			window.requestAnimationFrame(draw);
		}
```