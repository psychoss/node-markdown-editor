# window.performance - Code Snippets

```
				window.performance.mark("filtering");
				var c = searchInput.value;
				if (c.trim())
					self.filter(c);
				else {
					var ls = note_list.children;
					for (l = ls.length; l--;) {
						ls[l].classList.remove('hidden');
					}
				}
				window.performance.mark("filtered");
				window.performance.measure("durationFilter", 'filtering', 'filtered');
				console.log(window.performance.getEntriesByName('durationFilter')[0].duration);
				window.performance.clearMarks();
				window.performance.clearMeasures();
```