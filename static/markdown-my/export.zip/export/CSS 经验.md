# CSS 经验



## 水平居中

```
.center-horizontal {
    position: relative;
    left: 50%;
    transform: translateX(-50%); 
}
```