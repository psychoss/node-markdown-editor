# Object - Javascript

## Properties of the Object constructor

- **Object.length**

 Has a value of 1.

- **Object.prototype**

 Allows the addition of properties to all objects of type Object.


## Methods of the Object constructor

- **Object.assign()**

 Creates a new object by copying the values of all enumerable own properties from one or more source objects to a target object.

- **Object.create()**

 Creates a new object with the specified prototype object and properties.

- **Object.defineProperty()**

 Adds the named property described by a given descriptor to an object.

- **Object.defineProperties()**

 Adds the named properties described by the given descriptors to an object.

- **Object.freeze()**

 Freezes an object: other code can't delete or change any properties.

- **Object.getOwnPropertyDescriptor()**

 Returns a property descriptor for a named property on an object.

- **Object.getOwnPropertyNames()**

 Returns an array containing the names of all of the given object's own enumerable and non-enumerable properties.

- **Object.getOwnPropertySymbols()**

 Returns an array of all symbol properties found directly upon a given object.

- **Object.getPrototypeOf()**

 Returns the prototype of the specified object.

- **Object.is()**

 Compares if two values are distinguishable (ie. the same)

- **Object.isExtensible()**

 Determines if extending of an object is allowed.

- **Object.isFrozen()**

 Determines if an object was frozen.

- **Object.isSealed()**

 Determines if an object is sealed.

- **Object.keys()**

 Returns an array containing the names of all of the given object's own enumerable properties.

- **Object.observe()**

 Asynchronously observes changes to an object.

- **Object.getNotifier()**

 Get a notifier with which to create object changes manually.

- **Object.preventExtensions()**

 Prevents any extensions of an object.

- **Object.seal()**

 Prevents other code from deleting properties of an object.

- **Object.setPrototypeOf()**

 Sets the prototype (i.e., the internal [[Prototype]] property)


## Properties

- **Object.prototype.constructor**

 Specifies the function that creates an object's prototype.

- **Object.prototype. `__proto__` **

 Points to the object which was used as prototype when the object was instantiated.

- **Object.prototype. `__noSuchMethod__` **

 Allows a function to be defined that will be executed when an undefined object member is called as a method.

- **Object.prototype. `__count__` **

 Used to return the number of enumerable properties directly on a user-defined object, but has been removed.

- **Object.prototype. `__parent__` **

 Used to point to an object's context, but has been removed.

## Methods

- **Object.prototype. `__defineGetter__` ()**

 Associates a function with a property that, when accessed, executes that function and returns its return value.

- **Object.prototype. `__defineSetter__` ()**

 Associates a function with a property that, when set, executes that function which modifies the property.

- **Object.prototype. `__lookupGetter__` ()**

 Returns the function associated with the specified property by the  `__defineGetter__`  method.

- **Object.prototype. `__lookupSetter__` ()**

 Returns the function associated with the specified property by the  `__defineSetter__`  method.

- **Object.prototype.hasOwnProperty()**

 Returns a boolean indicating whether an object contains the specified property as a direct property of that object and not inherited through the prototype chain.

- **Object.prototype.isPrototypeOf()**

 Returns a boolean indication whether the specified object is in the prototype chain of the object this method is called upon.

- **Object.prototype.propertyIsEnumerable()**

 Returns a boolean indicating if the internal ECMAScript DontEnum attribute is set.

- **Object.prototype.toSource()**

 Returns string containing the source of an object literal representing the object that this method is called upon; you can use this value to create a new object.

- **Object.prototype.toLocaleString()**

 Calls toString().

- **Object.prototype.toString()**

 Returns a string representation of the object.

- **Object.prototype.unwatch()**

 Removes a watchpoint from a property of the object.

- **Object.prototype.valueOf()**

 Returns the primitive value of the specified object.

- **Object.prototype.watch()**

 Adds a watchpoint to a property of the object.

- **Object.prototype.eval()**

 Used to evaluate a string of JavaScript code in the context of the specified object, but has been removed.