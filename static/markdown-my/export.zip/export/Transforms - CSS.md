# Transforms - CSS

<table responsive="true">
<tbody><tr><th>Property</th><th>Description</th></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772262(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">backface-visibility</strong></a>
</p>
</td><td data-th="Description">
<p>Gets or sets a value  that specifies whether the back face (reverse side) of an  object is visible. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772272(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">perspective</strong></a>
</p>
</td><td data-th="Description">
<p>Gets or sets a value  that represents the perspective from which all child elements of the object are viewed. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772275(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">perspective-origin</strong></a>
</p>
</td><td data-th="Description">
<p>Gets or sets one or two values  that represent the origin (the vanishing point for the 3-D space) of an object with an <a href="https://msdn.microsoft.com/en-us/library/hh772272(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">perspective</strong></a> property declaration. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127312(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">transform</strong></a>
</p>
</td><td data-th="Description">
<p>Gets or sets a list of one or more transform functions that specify how to translate, rotate, or scale an element in 2-D or 3-D space.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127313(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">transform-origin</strong></a>
</p>
</td><td data-th="Description">
<p>Gets or sets one or two values that establish the origin of transformation for an element.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772282(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">transform-style</strong></a>
</p>
</td><td data-th="Description">
<p>Gets or sets a value  that specifies how child elements of the object are rendered in 3-D space. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772390(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">MSCSSMatrix</strong></a>
</p>
</td><td data-th="Description">
<p>Represents a 4×4 homogeneous matrix that enables Document Object Model (DOM) scripting access to CSS&nbsp;2-D and  3-D Transforms functionality.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj200285(v=vs.85).aspx">Transform Functions</a>
</p>
</td><td data-th="Description">
<p>This section contains reference documentation for the CSS transform functions that are supported in Windows Internet Explorer.</p>
</td></tr>
</tbody></table>

## 2-D Transform functions
<table responsive="true">
<tbody><tr><th>Function</th><th>Description</th></tr>
<tr><td data-th="Function">
<p><a id="matrix__"></a><a id="MATRIX__"></a><a href="https://msdn.microsoft.com/en-us/library/jj200270(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">matrix()</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a 2-D transformation in the form of a transformation matrix of six values.</p>
</td></tr>
<tr><td data-th="Function">
<p><a id="rotate__"></a><a id="ROTATE__"></a><a href="https://msdn.microsoft.com/en-us/library/jj200276(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">rotate()</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a 2-D rotation by the angle specified in the parameter about the origin of the element.</p>
</td></tr>
<tr><td data-th="Function">
<p><a id="scale__"></a><a id="SCALE__"></a><a href="https://msdn.microsoft.com/en-us/library/jj200281(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scale()</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a 2-D scale operation by the [<em>sx</em>,<em>sy</em>] scaling vector that is described by the two parameters.</p>
</td></tr>
<tr><td data-th="Function">
<p><a id="scaleX__"></a><a id="scalex__"></a><a id="SCALEX__"></a><a href="https://msdn.microsoft.com/en-us/library/jj200278(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scaleX()</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a scale operation by using the [<em>sx</em>,1] scaling vector, where <em>sx</em> is given as the parameter.</p>
</td></tr>
<tr><td data-th="Function">
<p><a id="scaleY__"></a><a id="scaley__"></a><a id="SCALEY__"></a><a href="https://msdn.microsoft.com/en-us/library/jj200279(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scaleY()</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a scale operation by using the [1,<em>sy</em>] scaling vector, where <em>sy</em> is given as the parameter.</p>
</td></tr>
<tr><td data-th="Function">
<p><a id="skew__"></a><a id="SKEW__"></a><a href="https://msdn.microsoft.com/en-us/library/jj200284(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">skew()</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a skew transformation along the <em>x</em>- and <em>y</em>-axes. The first angle parameter specifies the skew on the <em>x</em>-axis. The second angle parameter specifies the skew on the <em>y</em>-axis.</p>
</td></tr>
<tr><td data-th="Function">
<p><a id="skewX__"></a><a id="skewx__"></a><a id="SKEWX__"></a><a href="https://msdn.microsoft.com/en-us/library/jj200282(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">skewX()</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a skew transformation along the <em>x</em>-axis by the given angle.</p>
</td></tr>
<tr><td data-th="Function">
<p><a id="skewY__"></a><a id="skewy__"></a><a id="SKEWY__"></a><a href="https://msdn.microsoft.com/en-us/library/jj200283(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">skewY()</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a skew transformation along the <em>y</em>-axis by the given angle.</p>
</td></tr>
<tr><td data-th="Function">
<p><a id="translate__"></a><a id="TRANSLATE__"></a><a href="https://msdn.microsoft.com/en-us/library/jj200290(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">translate()</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a 2-D translation by the vector [<em>tx</em>,<em>ty</em>], where <em>tx</em> is the first translation-value parameter and <em>ty</em> is the optional second translation-value parameter.</p>
</td></tr>
<tr><td data-th="Function">
<p><a id="translateX__"></a><a id="translatex__"></a><a id="TRANSLATEX__"></a><a href="https://msdn.microsoft.com/en-us/library/jj200287(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">translateX()</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a translation by the given amount in the <em>x</em> direction.</p>
</td></tr>
<tr><td data-th="Function">
<p><a id="translateY__"></a><a id="translatey__"></a><a id="TRANSLATEY__"></a><a href="https://msdn.microsoft.com/en-us/library/jj200288(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">translateY()</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a translation by the given amount in the <em>y</em> direction.</p>
</td></tr>
</tbody></table>

## 3-D Transform functions

<table responsive="true">
<tbody><tr><th>Function</th><th>Description</th></tr>
<tr><td data-th="Function">
<p><a id="matrix3d__"></a><a id="MATRIX3D__"></a><a href="https://msdn.microsoft.com/en-us/library/jj200269(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">matrix3d()</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a 3-D transformation as a 4×4 homogeneous matrix of sixteen values in column-major order.</p>
</td></tr>
<tr><td data-th="Function">
<p><a id="perspective__"></a><a id="PERSPECTIVE__"></a><a href="https://msdn.microsoft.com/en-us/library/jj200271(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">perspective()</strong></a>
</p>
</td><td data-th="Description">
<p>Changes the perspective through which an element is viewed, giving an illusion of depth.</p>
</td></tr>
<tr><td data-th="Function">
<p><a id="rotate3d__"></a><a id="ROTATE3D__"></a><a href="https://msdn.microsoft.com/en-us/library/jj200272(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">rotate3d()</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a clockwise 3-D rotation.</p>
</td></tr>
<tr><td data-th="Function">
<p><a id="rotateX__"></a><a id="rotatex__"></a><a id="ROTATEX__"></a><a href="https://msdn.microsoft.com/en-us/library/jj200273(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">rotateX()</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a clockwise rotation by the given angle about the <em>x</em>-axis.</p>
</td></tr>
<tr><td data-th="Function">
<p><a id="rotateY__"></a><a id="rotatey__"></a><a id="ROTATEY__"></a><a href="https://msdn.microsoft.com/en-us/library/jj200283(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">rotateY()</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a clockwise rotation by the given angle about the <em>y</em>-axis.</p>
</td></tr>
<tr><td data-th="Function">
<p><a id="rotateZ__"></a><a id="rotatez__"></a><a id="ROTATEZ__"></a><a href="https://msdn.microsoft.com/en-us/library/jj200290(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">rotateZ()</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a clockwise rotation by the given angle about the <em>z</em>-axis.</p>
</td></tr>
<tr><td data-th="Function">
<p><a id="scale3d__"></a><a id="SCALE3D__"></a><a href="https://msdn.microsoft.com/en-us/library/jj200277(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scale3d()</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a 3-D scale operation by the [<em>sx</em>,<em>sy</em>,<em>sz</em>] scaling vector described by the three parameters.</p>
</td></tr>
<tr><td data-th="Function">
<p><a id="scaleZ__"></a><a id="scalez__"></a><a id="SCALEZ__"></a><a href="https://msdn.microsoft.com/en-us/library/jj200280(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scaleZ()</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a scale operation using the [1,1,<em>sz</em>] scaling vector, where <em>sz</em> is given as the parameter.</p>
</td></tr>
<tr><td data-th="Function">
<p><a id="translate3d__"></a><a id="TRANSLATE3D__"></a><a href="https://msdn.microsoft.com/en-us/library/jj200286(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">translate3d()</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a 3-D translation by the vector [<em>tx</em>,<em>ty</em>,<em>tz</em>], where <em>tx</em>, <em>ty</em>, and <em>tz</em> are the first, second, and third translation-value parameters respectively.</p>
</td></tr>
<tr><td data-th="Function">
<p><a id="translateZ__"></a><a id="translatez__"></a><a id="TRANSLATEZ__"></a><a href="https://msdn.microsoft.com/en-us/library/jj200289(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">translateZ()</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a translation by a given amount in the <em>z</em>-direction.</p>
</td></tr>
</tbody></table>


## transform-origin property

Gets or sets one or two values that establish the origin of transformation for an element.

This property is read/write.

 
### Syntax
 **transform-origin** : [ [ [  `<percentage>`  |  `<length>`  | left | center | right ] [  `<percentage>`  |  `<length>`  | top | center | bottom ] ? ]  `<length>`  ] | [ [ [ left | center | right ] || [ top | center | bottom ] ]  `<length>`  ]

### Property values
One or two of the following origin values, separated by whitespace.

- **length**

 A floating-point number, followed by a supported length unit, that indicates the origin of transformation.

- **percentage**

 An integer, followed by a %. The value is a percentage of the total box length (for the first value) or the total box height (for the second value, if specified).

- **left**

 First value only. Equal to 0% or a zero length.

- **center**

 First value only. Equal to 50% or half the length of the box.

- **right**

 First value only. Equal to 100% or the full box length.

- **top**

 Second value only. Equal to 0% or a zero height.

- **center**

 Second value only. Equal to 50% or a half the height of the box.

- **bottom**

 Second value only. Equal to 100% or the full box height.
 
 

### Remarks
As of Microsoft Edge, the "-ms-" prefixed version of this property is not supported.

The version of this property using a vendor prefix, -ms-transform-origin, has been deprecated in Internet Explorer 10 and later. However, be aware that -ms-transform-origin is the only form of this property that is recognized by Windows Internet Explorer 9, which supports 2-D Cascading Style Sheets (CSS) transforms. To ensure maximum compatibility, specify a cascade such as the following, where the prefixed versions of the property come before the unprefixed version.


```
#mytransform {
  ...
  -ms-transform-origin: 60% 100%;
  -webkit-transform-origin: 60% 100%;
  -moz-transform-origin: 60% 100%;
  transform-origin: 60% 100%;
}
```

If the transform-origin property is not set, the transform begins in the center (equal to a transform-origin value of "50% 50%").

If only one value is specified, the second value is assumed to be  **center** .

3-D transforms are only supported in Internet Explorer 10 and later.

To learn more about CSS transforms in Windows Internet Explorer, see How to bring your webpage to life with CSS transforms, transitions, and animations.

As of Internet Explorer for Windows Phone 8.1 Update, Internet Explorer for Windows Phone supports "-webkit-transform-origin" as an alias for this property.