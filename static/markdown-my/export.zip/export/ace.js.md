# ace.js

[ace.js](https://github.com/ajaxorg/ace)


## Example

### AutoComplete


```
<html>
<body>
  <div id="editor" style="height: 500px; width: 800px">Type in a word like "will" below and press ctrl+space or alt+space to get "rhyme completion"</div>
  <div id="commandline" style="position: absolute; bottom: 10px; height: 20px; width: 800px;"></div>
</body>
  <script src="https://rawgithub.com/ajaxorg/ace-builds/master/src/ace.js" type="text/javascript" charset="utf-8"></script>
  <script src="https://rawgithub.com/ajaxorg/ace-builds/master/src/ext-language_tools.js" type="text/javascript" charset="utf-8"></script>
  <script src="http://code.jquery.com/jquery-2.0.3.min.js"></script>
<script>
    var langTools = ace.require("ace/ext/language_tools");
    var editor = ace.edit("editor");
    editor.setOptions({enableBasicAutocompletion: true});
    // uses http://rhymebrain.com/api.html
    var rhymeCompleter = {
        getCompletions: function(editor, session, pos, prefix, callback) {
            if (prefix.length === 0) { callback(null, []); return }
            $.getJSON(
                "http://rhymebrain.com/talk?function=getRhymes&word=" + prefix,
                function(wordList) {
                    // wordList like [{"word":"flow","freq":24,"score":300,"flags":"bc","syllables":"1"}]
                    callback(null, wordList.map(function(ea) {
                        return {name: ea.word, value: ea.word, score: ea.score, meta: "rhyme"}
                    }));
                })
        }
    }
    langTools.addCompleter(rhymeCompleter);
</script>
</html>
```


### keyboard_shortcuts

```
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>Editor</title>
  <style type="text/css" media="screen">
    body {
        overflow: hidden;
    }    
    #editor { 
        margin: 0;
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
    }
  </style>
</head>
<body>

<pre id="editor"></pre>
    
<script src="kitchen-sink/require.js"></script>
<script>
// setup paths
require.config({paths: { "ace" : "../lib/ace"}});
require(["ace/ace"], function(ace) {
    var editor = ace.edit("editor")
    editor.setTheme("ace/theme/twilight")
    editor.session.setMode("ace/mode/html")
    
    // add command to lazy-load keybinding_menu extension
    editor.commands.addCommand({
        name: "showKeyboardShortcuts",
        bindKey: {win: "Ctrl-Alt-h", mac: "Command-Alt-h"},
        exec: function(editor) {
            ace.config.loadModule("ace/ext/keybinding_menu", function(module) {
                module.init(editor);
                editor.showKeyboardShortcuts()
            })
        }
    })
    editor.execCommand("showKeyboardShortcuts")
})
</script>

<script src="./show_own_source.js"></script>
</body>
</html>
```
