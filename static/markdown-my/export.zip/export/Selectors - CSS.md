Selectors - CSS

<table responsive="true">
<tbody><tr><th>Topic</th><th>Description</th></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/aa358820(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">Class</strong></a>
</p>
</td><td data-th="Description">
<p>Matches the class attribute of the specified element. </p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/aa358826(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">ID</strong></a>
</p>
</td><td data-th="Description">
<p>
      Matches the id attribute of the specified element.
    </p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh869601(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">Namespaced</strong></a>
</p>
</td><td data-th="Description">
<p>Matches the elements within the namespace specified by the given namespace prefix.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/aa358830(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">Type</strong></a>
</p>
</td><td data-th="Description">
<p>
        Matches any element of the specified type.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/aa358831(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">Universal</strong></a>
</p>
</td><td data-th="Description">
<p>
      Matches any element type.
    </p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh869405(v=vs.85).aspx">Attribute Selectors</a>
</p>
</td><td data-th="Description">
<p>
          This section contains reference topics for all supported CSS
        attribute selectors.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh869407(v=vs.85).aspx">Combinators</a>
</p>
</td><td data-th="Description">
<p>
          This section contains reference topics for all supported CSS
        combinators.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh869602(v=vs.85).aspx">Pseudo-classes</a>
</p>
</td><td data-th="Description">
<p>
          This section contains reference topics for all supported CSS
        pseudo-classes.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh869604(v=vs.85).aspx">Pseudo-elements</a>
</p>
</td><td data-th="Description">
<p>
          This section contains reference topics for all supported CSS
        pseudo-elements.</p>
</td></tr>
</tbody></table>


## Attribute Selectors

<table responsive="true">
<tbody><tr><th>Topic</th><th>Description</th></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/aa358822(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">Equality [=] Attribute Selector</strong></a>
</p>
</td><td data-th="Description">
<p>Exactly matches the specified attribute value.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/aa358823(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">Existence [] Attribute Selector</strong></a>
</p>
</td><td data-th="Description">
<p>Matches the attribute, whatever its value.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/aa358825(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">Hyphen [|=] Attribute Selector</strong></a>
</p>
</td><td data-th="Description">
<p>Matches any attribute value that is exactly equal, or optionally, followed by a hyphen.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/aa358827(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">Prefix [^=] Attribute Selector</strong></a>
</p>
</td><td data-th="Description">
<p>Matches the specified prefix of an attribute value.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/aa358828(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">Substring [*=] Attribute Selector</strong></a>
</p>
</td><td data-th="Description">
<p>Matches the specified substring of an attribute value.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/aa358829(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">Suffix [$=] Attribute Selector</strong></a>
</p>
</td><td data-th="Description">
<p>Matches the specified suffix of an attribute value.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/aa358832(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">Whitespace [~=] Attribute Selector</strong></a>
</p>
</td><td data-th="Description">
<p>Exactly matches the specified attribute value in a space-delimited list of values.</p>
</td></tr>
</tbody></table>

## Combinators

<table responsive="true">
<tbody><tr><th>Topic</th><th>Description</th></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/aa358818(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">Adjacent Sibling (+) Combinator</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies an adjacent sibling relationship between selector elements.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/aa358819(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">Child (&gt;) Combinator</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies an child relationship between selector elements.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/aa358821(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">Descendant Combinator</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies an arbitrary ancestral relationship between selector elements.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/aa358824(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">General Sibling (~) Combinator</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies an adjacent sibling relationship between selector elements.</p>
</td></tr>
</tbody></table>

## Pseudo-classes


<table responsive="true">
<tbody><tr><th>Topic</th><th>Description</th></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/cc848864(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:active</strong></a>
</p>
</td><td data-th="Description">
<p>Sets the style of an element when it is engaged or active.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127296(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:checked</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the form control element that is selected.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127307(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:disabled</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the form control element that is disabled.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127309(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:empty</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the element that has no child elements (including text nodes).</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127310(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:enabled</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the form control element that is enabled.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/cc848865(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:first-child</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to any element that is the first child of its parent.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127311(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:first-of-type</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the element that is the first sibling element of its type.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/cc304080(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:focus</strong></a>
</p>
</td><td data-th="Description">
<p>Sets the style of an element when it gains focus.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/cc848866(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:hover</strong></a>
</p>
</td><td data-th="Description">
<p>Sets the style of an element when the user hovers the mouse pointer over the element.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127327(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:indeterminate</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to radio buttons and check boxes whose toggle states cannot be determined—they are neither checked (selected) nor unchecked (cleared).</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/mt574720(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:in-range</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to specified input fields when the fields are in range.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772367(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:invalid</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to specified <a href="http://go.microsoft.com/fwlink/p/?LinkID=219805">input</a> fields when the fields are invalid.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/cc848867(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:lang(C)</strong></a>
</p>
</td><td data-th="Description">
<p>In a document, selects the elements that are in a given language.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127328(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:last-child</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the element that is the last child element of its parent element.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127329(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:last-of-type</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the element that is the last sibling element of its type.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/cc848868(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:link</strong></a>
</p>
</td><td data-th="Description">
<p>
      Sets the style of an <a href="https://msdn.microsoft.com/en-us/library/ms535173(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">a</strong></a> element when the link has not been visited recently.
    </p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772745(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:-ms-input-placeholder</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to placeholder text in an <a href="http://go.microsoft.com/fwlink/p/?LinkID=219805">input</a> element.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dn336891(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:-ms-keyboard-active</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to an element when it has focus and the user presses the space bar.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127341(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:not(s)</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to elements that do not match the simple selector <strong>s</strong>.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127342(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:nth-child(n)</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the element that is the n-th child of its parent element.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127343(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:nth-last-child(n)</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the element that is the n-th child of its parent element, counting from the last one.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127344(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:nth-last-of-type(n)</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the element that is the n-th sibling of its type, counting from the last one.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127345(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:nth-of-type(n)</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the element that is the n-th sibling of its type.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127346(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:only-child</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the element that is the only child element of its parent.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127347(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:only-of-type</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the element that is the only sibling element of its type.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772709(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:optional</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to specified <a href="http://go.microsoft.com/fwlink/p/?LinkID=219805">input</a> fields when the fields are optional.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/mt574721(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:out-of-range</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to specified input fields when the fields are out of range.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/mt574722(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:read-only</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to specified input fields when the fields are read-only.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/mt574723(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:read-write</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to specified input fields when the fields are editable.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772720(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:required</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to specified <a href="http://go.microsoft.com/fwlink/p/?LinkID=219805">input</a> fields when the fields are required.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127348(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:root</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the element that is the root element of the document.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127352(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:target</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the target element of the referring Uniform Resource Identifier (URI).</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772727(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:valid</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to specified <a href="http://go.microsoft.com/fwlink/p/?LinkID=219805">input</a> fields when the fields are valid.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/cc848869(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">:visited</strong></a>
</p>
</td><td data-th="Description">
<p>
      Specifies the style of an <a href="https://msdn.microsoft.com/en-us/library/ms535173(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">a</strong></a> element if the link has been visited recently.
    </p>
</td></tr>
</tbody></table>


## Pseudo-elements

<table responsive="true">
<tbody><tr><th>Topic</th><th>Description</th></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/cc304076(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">::after</strong></a>
</p>
</td><td data-th="Description">
<p>Defines generated content that functions as a virtual last-child of the matched element.
</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/cc304078(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">::before</strong></a>
</p>
</td><td data-th="Description">
<p>Defines generated content that functions as a virtual first-child of the matched element.
</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530753(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">::first-letter</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the first letter of the object.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530754(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">::first-line</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the first line of the object.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dn336890(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">::-ms-browse</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the browse button of an <a href="https://msdn.microsoft.com/en-us/library/ms535263(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">input type=file</strong></a> control. </p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771816(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">::-ms-check</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the check of a checkbox or radio button <a href="https://msdn.microsoft.com/en-us/library/ms535260(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">input</strong></a> control. </p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771818(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">::-ms-clear</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the clear button of a text input control. The clear button is shown only when the text input control has focus and is not empty. </p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771821(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">::-ms-expand</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the drop-down button of a <a href="https://msdn.microsoft.com/en-us/library/ms535893(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">select</strong></a> control. </p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771827(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">::-ms-fill</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the <a href="https://msdn.microsoft.com/en-us/library/hh441310.aspx"><strong xmlns="http://www.w3.org/1999/xhtml">progress</strong></a> control. All styles are applied to the bar portion of the determinate progress bar, except for the <a href="https://msdn.microsoft.com/en-us/library/hh772236(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">animation-name</strong></a> style property, which controls the animation of the indeterminate progress control. </p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771824(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">::-ms-fill-lower</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to portion of the track of a <a href="https://msdn.microsoft.com/en-us/library/hh466182.aspx"><strong xmlns="http://www.w3.org/1999/xhtml">input type=range</strong></a> control (also known as a slider control). The styles are applied to the   control's track from its smallest value up to the value currently selected by the thumb.  In a left-to-right layout, this is the portion of the   track to the left of the thumb.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771826(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">::-ms-fill-upper</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to portion of the track of a <a href="https://msdn.microsoft.com/en-us/library/hh466182.aspx"><strong xmlns="http://www.w3.org/1999/xhtml">input type=range</strong></a> control (also known as a slider control). The styles are applied to the  control's track from the value currently selected by the thumb up to the slider's largest value.  In a left-to-right layout, this is the portion of the track to the right of the thumb.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771833(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">::-ms-reveal</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the password reveal button of an <a href="https://msdn.microsoft.com/en-us/library/hh466170.aspx"><strong xmlns="http://www.w3.org/1999/xhtml">input type=password</strong></a> control.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771835(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">::-ms-thumb</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to portion of the <a href="https://msdn.microsoft.com/en-us/library/hh466182.aspx"><strong xmlns="http://www.w3.org/1999/xhtml">input type=range</strong></a> control (also known as a slider control) that the user drags. </p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771836(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">::-ms-ticks-after</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the tick marks after the slider track of an <a href="https://msdn.microsoft.com/en-us/library/hh466182.aspx"><strong xmlns="http://www.w3.org/1999/xhtml">input type=range</strong></a> (also known as a slider) control.  In a left-to-right layout, these are the ticks below the track. In a top-to-bottom  layout, these are the ticks to the right of a track.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771838(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">::-ms-ticks-before</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the tick marks before the slider track of an <a href="https://msdn.microsoft.com/en-us/library/hh466182.aspx"><strong xmlns="http://www.w3.org/1999/xhtml">input type=range</strong></a> control (also known as a slider control).  In a left-to-right layout, these are the ticks above the track. In a top-to-bottom  layout, these are the ticks to the left of a track.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771839(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">::-ms-tooltip</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the tooltip of a slider (<a href="https://msdn.microsoft.com/en-us/library/hh773065(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">input type=range</strong></a>). </p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771840(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">::-ms-track</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the track of an <a href="https://msdn.microsoft.com/en-us/library/hh466182.aspx"><strong xmlns="http://www.w3.org/1999/xhtml">input type=range</strong></a>  control (also known as a slider control).</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771841(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">::-ms-value</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to the content of a text or password <a href="https://msdn.microsoft.com/en-us/library/ms535260(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">input</strong></a> control, or a <a href="https://msdn.microsoft.com/en-us/library/ms535893(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">select</strong></a> control. </p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127349(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">::selection</strong></a>
</p>
</td><td data-th="Description">
<p>Applies one or more styles to any text on the page that the user has highlighted.</p>
</td></tr>
</tbody></table>