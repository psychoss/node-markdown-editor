# Cascading Style Sheets
<table responsive="true">
<tbody><tr><th>Topic</th><th>Description</th></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh869403(v=vs.85).aspx">Alphabetical Index</a>
</p>
</td><td data-th="Description">
<p>This index lists all supported CSS properties, selectors, functions, at-rules, and so on. Windows Internet Explorer. </p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dn254934(v=vs.85).aspx">Animation and transition properties</a>
</p>
</td><td data-th="Description">
<p>The following is a list of CSS properties that you can animate using animations and transitions.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530769(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">!important</strong></a>
</p>
</td><td data-th="Description">
<p>This CSS feature improves accessibility of documents by giving users with special requirements (large fonts, color combinations, and so on) control over presentation.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771874(v=vs.85).aspx">Animations</a>
</p>
</td><td data-th="Description">
<p>This section describes CSS features to enable animation.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/aa358815(v=vs.85).aspx">At-rules</a>
</p>
</td><td data-th="Description">
<p>This section describes CSS at-rules.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772046(v=vs.85).aspx">Backgrounds and Borders</a>
</p>
</td><td data-th="Description">
<p>
This section describes CSS features related to backgrounds and borders.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772047(v=vs.85).aspx">Basic Box Model</a>
</p>
</td><td data-th="Description">
<p>
This section describes CSS features related to the basic box model.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772048(v=vs.85).aspx">Basic UI</a>
</p>
</td><td data-th="Description">
<p>
This section describes CSS features related to basic user interface.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772049(v=vs.85).aspx">Color</a>
</p>
</td><td data-th="Description">
<p>
This section describes CSS features related to color.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771881(v=vs.85).aspx">CSSOM View</a>
</p>
</td><td data-th="Description">
<p>
This section describes features related to CSS Object Model (CSSOM) View.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh869463(v=vs.85).aspx">Device Adaptation</a>
</p>
</td><td data-th="Description">
<p>
This section describes features related to CSS Device Adaptation.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772065(v=vs.85).aspx">DOM Style APIs</a>
</p>
</td><td data-th="Description">
<p>This section describes CSS-related Document Object Model (DOM) Collections, Methods, Objects, and Properties.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772711(v=vs.85).aspx">Exclusions</a>
</p>
</td><td data-th="Description">
<p>
This section describes features related to CSS Exclusions.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772069(v=vs.85).aspx">Flexible Box ("Flexbox") Layout</a>
</p>
</td><td data-th="Description">
<p>
This section describes features related to Flexible Box ("Flexbox") layout.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772050(v=vs.85).aspx">Fonts</a>
</p>
</td><td data-th="Description">
<p>
This section describes CSS features related to fonts.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dn913792(v=vs.85).aspx">Fullscreen</a>
</p>
</td><td data-th="Description">
<p>
This section describes CSS features related to the <a href="https://msdn.microsoft.com/en-us/library/dn265028(v=vs.85).aspx">Fullscreen API</a>.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772051(v=vs.85).aspx">Generated and Replaced Content</a>
</p>
</td><td data-th="Description">
<p>
This section describes CSS features related to generated and replaced content.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771876(v=vs.85).aspx">Gradients</a>
</p>
</td><td data-th="Description">
<p>
This section describes CSS features related to gradients.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772052(v=vs.85).aspx">Grid Layout</a>
</p>
</td><td data-th="Description">
<p>
This section describes features related to Grid Layout.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772071(v=vs.85).aspx">High Contrast Mode</a>
</p>
</td><td data-th="Description">
<p>
This section describes features that enable the styling of webpages and Windows Store apps using JavaScript for High Contrast Mode in Windows.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772370(v=vs.85).aspx">Media Queries</a>
</p>
</td><td data-th="Description">
<p>
This section describes CSS features related to media queries.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772373(v=vs.85).aspx">Microsoft Extensions to CSS</a>
</p>
</td><td data-th="Description">
<p>
This section describes Microsoft extensions to the CSS standard.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771877(v=vs.85).aspx">Multi-column Layout</a>
</p>
</td><td data-th="Description">
<p>
This section describes CSS features related to multiple column layout.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772053(v=vs.85).aspx">Paged Media</a>
</p>
</td><td data-th="Description">
<p>
This section describes CSS features related to paged media.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772715(v=vs.85).aspx">Regions</a>
</p>
</td><td data-th="Description">
<p>
This section describes CSS features related to Regions.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772055(v=vs.85).aspx">Ruby</a>
</p>
</td><td data-th="Description">
<p>
This section describes CSS features related to ruby text.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772056(v=vs.85).aspx">Selectors</a>
</p>
</td><td data-th="Description">
<p>
This section describes CSS features related to selectors.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772725(v=vs.85).aspx">Selectors API</a>
</p>
</td><td data-th="Description">
<p>This section describes methods that you can use to select objects by using CSS selector syntax. </p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772057(v=vs.85).aspx">Tables</a>
</p>
</td><td data-th="Description">
<p>
This section describes CSS features related to table layout.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772058(v=vs.85).aspx">Text</a>
</p>
</td><td data-th="Description">
<p>
This section describes CSS features related to text.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772726(v=vs.85).aspx">Touch: Zooming and Panning</a>
</p>
</td><td data-th="Description">
<p>
This section describes features that enable programmatic control of touch input and gesture recognition.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772059(v=vs.85).aspx">Transforms</a>
</p>
</td><td data-th="Description">
<p>
This section describes CSS features related to transforms.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772060(v=vs.85).aspx">Transitions</a>
</p>
</td><td data-th="Description">
<p>
This section describes CSS features related to transitions.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771857(v=vs.85).aspx">Visual Effects</a>
</p>
</td><td data-th="Description">
<p>
This section describes CSS features related to visual effects.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771859(v=vs.85).aspx">Visual Formatting Model</a>
</p>
</td><td data-th="Description">
<p>
This section describes CSS features related to the visual formatting model.</p>
</td></tr>
<tr><td data-th="Topic">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772061(v=vs.85).aspx">Writing Modes</a>
</p>
</td><td data-th="Description">
<p>
This section describes CSS features related to writing modes.</p>
</td></tr>
</tbody></table>