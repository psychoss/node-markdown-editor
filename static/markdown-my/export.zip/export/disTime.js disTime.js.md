# disTime.js disTime.js


```
var disTimeRepeater, disTimeObject, disTime;
disTimeObject = {
  parseTimestamp: function (language, thisTime, systemTime, detailed) {
    "use strict";
    var insert, distime, years, month, weeks, days, hours, minute, second;

    function pInt(string) {
      return parseInt(string, 10);
    }

    if (detailed === undefined) {
      detailed = false;
    }

    distime = (systemTime > thisTime) ? systemTime - thisTime : thisTime - systemTime;
    if (systemTime > thisTime) {
      insert = ' ' + language.words.preAgo + ' ';
    } else {
      insert = ' ' + language.words.inFuture + ' ';
    }

    if (distime > 31536000) {
      //years
      years = pInt(pInt(distime) / pInt(31536000));
      insert += years + ' ' + languages.declOfNum(language.mode, years, language.year);
    }

    if (((distime < 60 * 60 * 24 * 365) && (distime > 60 * 60 * 24 * 7 * 4)) || ((distime > 60 * 60 * 24 * 365) && detailed && (pInt(distime % 31536000 / 2419200) !== 0))) {
      //months
      insert += checkForAnd(detailed, insert, language);
      month = pInt(distime % 31536000 / 2419200);
      insert += month + ' ' + languages.declOfNum(language.mode, month, language.month);

      if (((distime < 60 * 60 * 24 * 365) && detailed && (pInt(distime % 2419200 / 86400) !== 0))) {
        //days
        insert += checkForAnd(detailed, insert, language);
        days = pInt(distime % 2419200 / 86400);
        insert += days + ' ' + languages.declOfNum(language.mode, days, language.day);
      }
    }

    if (((distime < 60 * 60 * 24 * 7 * 4) && (distime > 60 * 60 * 24 * 7)) || ((distime < 10368000) && (distime > 2419199) && detailed && (pInt(distime % 2592000 / 2419200) !== 0))) {
      //weeks
      insert += checkForAnd(detailed, insert, language);

      weeks = pInt(distime % 2419200 / 604800);
      insert += weeks + ' ' + languages.declOfNum(language.mode, weeks, language.week);
    }

    if (((distime < 60 * 60 * 24 * 7) && (distime > 86399)) || ((distime < 2419200) && (distime > 604799) && detailed && (pInt(distime % 604800 / 86400) !== 0))) {
      //days
      insert += checkForAnd(detailed, insert, language);

      days = pInt(distime % 2419200 / 86400);
      insert += days + ' ' + languages.declOfNum(language.mode, days, language.day);
    }

    if (((distime < 86400) && (distime > 3599)) || ((distime < 604800) && (distime > 86399) && detailed && (pInt(distime % 86400 / 3600) !== 0))) {
      //hours
      insert += checkForAnd(detailed, insert, language);

      hours = pInt(distime % 86400 / 3600);
      insert += hours + ' ' + languages.declOfNum(language.mode, hours, language.hour);
    }

    if (((distime < 3600) && (distime > 59)) || ((distime < 86400) && (distime > 3599) && detailed && (pInt(distime % 3600 / 60) !== 0))) {
      //minutes
      insert += checkForAnd(detailed, insert, language);

      minute = pInt(distime % 3600 / 60);
      insert += minute + ' ' + languages.declOfNum(language.mode, minute, language.minute);
    }

    if ((distime < 60) || ((distime < 3600) && (distime > 59) && detailed && (distime % 60 !== 0))) {
      //seconds
      insert += checkForAnd(detailed, insert, language);

      second = distime % 60;
      insert += second + ' ' + languages.declOfNum(language.mode, second, language.second);
    }

    if (systemTime > thisTime) {
      insert += ' ' + language.words.postAgo;
    }

    return insert;
  }
};

disTime = function (timedifference, language, detailed) {
  "use strict";
  var elements,
    elementcount,
    smallest,
    i,
    distime,
    timestamp,
    elementtime;

  if (detailed === undefined) {
    detailed = false;
  }
  if (language === undefined) {
    language = navigator.language || navigator.userLanguage;
  }
  if (languages[language] === undefined) {
    if (languages[language.split('-')[0]] !== undefined) {
      language = language.split('-')[0];
    } else {
      language = 'en';
    }
  }

  timestamp = parseInt(Date.now() / 1000, 10) + timedifference;
  elements = document.getElementsByClassName('distime');
  elementcount = elements.length;
  smallest = timestamp;
  for (i = 0; i < elementcount; i += 1) {
    elementtime = parseInt(elements[i].getAttribute('data-time'), 10);
    elements[i].innerHTML = disTimeObject.parseTimestamp(languages[language], elementtime, timestamp, detailed);
    distime = (timestamp > elementtime) ? timestamp - elementtime : elementtime - timestamp;
    if (!elements[i].hasAttribute('alt')) {
      elements[i].setAttribute('title', new Date(elementtime * 1000).toString());
    }
    if (distime < smallest) {
      smallest = distime;
    }
  }
  window.clearTimeout(disTimeRepeater);
  if ((smallest < 61) || (detailed && smallest < 3601)) {
    disTimeRepeater = setTimeout(disTime, 1000, timedifference, language, detailed);
  } else if ((smallest < 3601) || (detailed && smallest < 86400)) {
    disTimeRepeater = setTimeout(disTime, 60000, timedifference, language, detailed);
  } else if ((smallest < 86400) || detailed) {
    disTimeRepeater = setTimeout(disTime, 3600001, timedifference, language, detailed);
  } else {
    disTimeRepeater = setTimeout(disTime, 86400001, timedifference, language, detailed);
  }
};
```


```
<html>
<head>
  <meta charset="utf-8">
  <title>disTime.js</title>
  <style>
    #config {
      font-family: monospace;
      font-size: 17px;
    }
    #examples {
      font-family: "Lucida Grande", "Lucida Sans Unicode", Geneva, sans-serif;
      font-size: 14px;
    }
  </style>
  <script src="disTime.js" type="text/javascript"></script>
  <script src="disTime.i18n.js" type="text/javascript"></script>
  <script>

/*global disTime, disTimeRepeater */
/*jslint browser: true, indent: 2 */
function random(min, max) {
  "use strict";
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function generateExamples(config) {
  "use strict";
  var i,
    time = new Date(),
    examplesElement = document.getElementById('examples'),
    examples = '',
    timestamp;

  i = random(-10, 0);
  while (i < 15) {
    timestamp = parseInt(time.getTime() / 1000 - i * (100 + random(0, 42)), 10);
    examples += '<p class="distime" data-time="' + timestamp + '">' + timestamp + '</p>';
    i += 1;
  }
  examplesElement.innerHTML += '<p class="distime" data-time="' + parseInt(time.getTime() / 1000 - parseInt(eval(config.time), 10), 10) + '">' + parseInt(time.getTime() / 1000 - parseInt(eval(config.time), 10), 10) + '</p>' + examples;
}

function init() {
  "use strict";
  var config,
    hash,
    i,
    userLang = navigator.language || navigator.userLanguage;

  config = {'lang' : userLang, 'time' : '60*60*24', 'detail' : 1};
  hash = window.location.hash.replace('#', '').split('&');
  for (i = 0; i < hash.length; i += 1) {
    config[hash[i].split('=')[0]] = hash[i].split('=')[1];
  }
  generateExamples(config);
  //disTime(<?php echo time(); ?>-parseInt(Date.now()/1000),config.lang,parseInt(config.detail,10));
  disTime(0, config.lang, parseInt(config.detail, 10));
}

function changeDemo() {
  "use strict";
  var lang,
    detail;
  lang = document.getElementById('lang').value;
  detail = document.getElementById('detail').value === 'on' ? true : false;
  window.clearTimeout(disTimeRepeater);
  disTime(0, lang, detail);
}

  </script>
</head>
<body onload="javascript:init();">
  <div id="config">Langauge (ISO 639-1):
    <select id="lang" name="lang" size="1" onchange="changeDemo()">
      <optgroup label="autodetected">
        <option><script>document.write((navigator.language) ? navigator.language : navigator.userLanguage);</script></option>
      </optgroup>
      <optgroup label="supported">
        <option>en</option>
        <option>ru</option>
        <option>de</option>
        <option>it</option>
        <option>es</option>
        <option>fr</option>
        <option>pt</option>
        <option>nl</option>
        <option>int</option>
      </optgroup>
    </select>
    Details:
    <select id="detail" name="detail" size="1" onchange="changeDemo()">
      <option>on</option>
      <option>off</option>
    </select>
  </div><div id="examples">
    <p class="distime" data-time="1563410000">1563410000</p>
    <p class="distime" data-time="1503410000">1503410000</p>
    <p class="distime" data-time="1473410000">1473410000</p>
    <p class="distime" data-time="1443410000">1443410000</p>
    <p class="distime" data-time="1413410000">1413410000</p>
    <p class="distime" data-time="613112400">613112400</p>
    <p class="distime" data-time="1363410000">1363410000</p>
  </div>
</body>
</html>
```



        