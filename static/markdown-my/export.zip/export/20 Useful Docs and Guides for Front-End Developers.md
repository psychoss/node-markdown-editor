# 20 Useful Docs and Guides for Front-End Developers

I come across so many interesting info-apps and documents in my daily research, so I thought I’d provide a list of those here.

True, not everyone likes the “list post” or roundup, but hey, we can’t please everyone. And we don’t do these types of posts too often anyhow.

In this case, this is a great way to bookmark a few things maybe for some evening or weekend reading. I guarantee you’ll find at least a few links in here that you’ll want to come back to.

Enjoy!

## [1. CSS Vocabulary](http://pumpula.net/p/apps/css-vocabulary/)
A great point-and-click little app to get you up to speed with all the different parts of CSS syntax and what the proper name for them is.


## [2. Liquidapsive](http://liquidapsive.com/)
A very simple informational layout that, by means of a select box, lets you choose between Responsive, Adaptive, Liquid, and Static, so you can see what is the difference between the four layout types.

## [3. Superhero.js](http://superherojs.com/)
A collection of the best articles, videos, and presentations on helping to maintain a large JavaScript code base.

Included are some general principle-type stuff, sources on testing, tools, performance, security, and more.

## [4. HowToCoffeeScript.com](http://howtocoffeescript.com/)
A cheat sheet for learning and remembering CoffeScript syntax.

## [5. The HTML Landscape](http://www.w3.org/html/landscape/)
This is pretty interesting. It’s a W3C document that describes the “perceptible differences” between three HTML specifications: WHATWG, W3C’s HTML5.0, and W3C’s HTML5.1.

Might be a little overly technical, but you might be able to find some interesting new stuff here.

## [6. The Elements of HTML](http://rawgithub.com/w3c/elements-of-html/master/index.html)
A nice comprehensive one-page chart of HTML and XHTML elements that indicates which specification the elements belong to.


This looks really good for doing research to find out when and/if an element has been deprecated or made obsolete in HTML5.

## [7. JavaScript Equality Table](http://dorey.github.io/JavaScript-Equality-Table/)
A nice little 3-tiered chart that helps you understand JavaScript’s double- and triple-equals operators.

The conclusion? “Use three equals unless you fully understand the conversions that take place for two-equals.”

## [8. Web Accessibility Checklist](http://a11yproject.com/checklist.html)
A useful but not overwhelming reference to help you check off various items on your projects for accessiblity.

A lot of this is pretty simple, but it doesn’t hurt to always take a final look, in addition to doing accessibility validating.

## [9. Static Web Apps — A Field Guide](http://www.staticapps.org/)
According to the description: “This guide will introduce you to the world of static web applications and offer solutions to common challenges encountered while building them.”


The idea here is to promote an architecture that eases common development problems.

## [10. Learn regular expressions in about 55 minutes](http://qntm.org/files/re/re.html)
An extensive doc/tutorial introducing regular expressions.
I’m guessing it would take much longer than the claimed “55 minutes” to really get something out of this, but certainly worth a look.

## [11. Open Web CSS Reference](http://ref.openweb.io/CSS/)
This is a really comprehensive and little-known CSS property and feature reference.