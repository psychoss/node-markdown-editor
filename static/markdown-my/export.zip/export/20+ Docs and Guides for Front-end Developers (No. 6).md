# 20+ Docs and Guides for Front-end Developers (No. 6)

It’s that time again to choose the tool or technology that you want to brush up on. If you feel like you’ve been working hard at building but maybe not learning as much as you’d like, I’ve got your back.

Please enjoy the sixth installment of our Docs and Guides series and don’t forget to let us know of any others that we haven’t yet included in this or a previous post.

## [1. DevTools Challenger](http://devtoolschallenger.com/)

![](images/2015-12-11/1447180289dg-01.png)

## [2. The HTML & CSS Workmanship Manual](http://workmanship.io/)

A good HTML/CSS styleguide to help developers write “durable, reliable” code, loosely inspired by NASA’s Workmanship Standards Program.

![](images/2015-12-11/1447180293dg-02.png)

## [3. ECMAScript 6 Cheatsheet](http://help.wtf/es6)

I don’t think we can have too many ES6 learning resources, so here’s another one. ES6 is a huge step forward in JavaScript’s history and this reference will give you ‘everything about the latest version of the ECMAScript standard’.

 ![](/images/2015-12-11/1447180298dg-03.png)
 
## [4. React Cheat Sheet](http://reactcheatsheet.com/)
React is officially the “current big thing” so this quick reference should be a big help. The page is filterable using a search form at the top and each feature includes a link to the official docs.

![](/images/2015-12-11/1447180302dg-04.png) 

## [5. Six Speed](http://kpdecker.github.io/six-speed/)

A chart that displays performance report information for different ES6 features relative to the ES5 baseline operations as rendered by various transpilers (Babel, Traceur, etc).

![](/images/2015-12-11/1447180306dg-05.png) 


## [6. U.S. Web Design Standards](https://playbook.cio.gov/designstandards/)
“Open source UI components and visual style guide to create consistency and beautiful user experiences across U.S. federal government websites.”


![](/images/2015-12-11/1447180310dg-06.png) 


## [7. ECMAScript 6 — New Features: Overview & Comparison](http://es6-features.org/)
Another nice ES6 learning resource. What’s really great about this one is the fact that it has two code examples for each feature, including how the same thing is accomplished in ES5.

![](/images/2015-12-11/1447180314dg-07.png) 

## [8. Interactive WCAG 2.0](http://code.viget.com/interactive-wcag/)
A list of Web Content Accessibility Guidelines for various UI elements, filterable by WCAG level, responsibility (Front-end, design, UX, etc.). It also includes recommendations from both the W3C and WebAIM.

![](/images/2015-12-11/1447180318dg-08.png) 


## [9. Mac OS X Dev Setup Reference](https://github.com/donnemartin/dev-setup)


“Setting up a new developer machine can be an ad-hoc, manual, and time-consuming process. [This reference] aims to simplify the process with easy-to-understand instructions and dotfiles/scripts to automate the setup” of a number of different tasks.

![](/images/2015-12-11/1447180238dg-09.jpg) 


## [10. Kinetic Email CSS Support](http://freshinbox.com/resources/css.php)

The following table lists the major HTML & CSS features that are commonly used by interactive and dynamic CSS techniques and their support among the major email clients.

![](/images/2015-12-11/1447180242dg-10.png) 


## [11. HTMLBook](http://oreillymedia.github.io/HTMLBook/)


An unofficial specification initiated by O’Reilly Media for outlining an XHTML5-based standard for authoring and producing digital and print books. Lea Verou’s book CSS Secrets was written using this standard.

![](/images/2015-12-11/1447180246dg-11.png) 

## [12. ECMAScript® 2016 Language Specification](http://tc39.github.io/ecma262/)
The official ECMAScript specification, which is now edited on GitHub, in a single-page, easy to use HTML format, with filter option.
![](/images/2015-12-11/1447180250dg-12.png) 
## [13. How DNS works](https://howdns.works/)
“A fun and colorful explanation of how DNS works… We made this comic to explain what happens when you type a website address in your browser.”

![](/images/2015-12-11/1447180254dg-13.png) 

## [14. StaticGen](http://www.staticgen.com/)
A filterable “leaderboard of the top open-source static site generators.” Lets you filter by language, GitHub stars, forks, and open issues.

![](/images/2015-12-11/1447180258dg-14.jpg) 

## [15. doiuse…?](http://doiuse.com/)
Paste in some CSS or a website URL and this site will tell you what browsers the CSS is compatible/incompatible with. You can do a general search or filter using the list keywords that Autoprefixer permits.

![](/images/2015-12-11/1447180262dg-15.png) 
## [16. Font Family Reunion](http://fontfamily.io/)

a filterable compatibility chart for default local fonts on just about any OS. The table informs you if the font is supported, aliased, or will revert to the default font for the OS.
![](/images/2015-12-11/1447180267dg-16.png) 


## [17. Perf.Rocks](http://perf.rocks/)
A single resource for finding articles, tools, videos, talks, slides, and books covering web performance. It’s well maintained and you can contribute your own stuff.

![](/images/2015-12-11/1447180271dg-17.png) 

## [18. Website Style Guide Resources](http://styleguides.io/)
Style guides have been a pretty big thing for a couple of years now. This is a single resource that has compiled tools, articles, books, podcasts, and more just on the topic of style guides.

![](/images/2015-12-11/1447180276dg-18.png) 


## [19. package.json](http://browsenpm.org/package.json)
“This is an interactive guide for exploring various important properties of the package.json packaging format for node.js applications. You can access information about properties by mousing over or clicking the property name.”
![](/images/2015-12-11/1447180281dg-19.png) 

## [20. Promise Cookbook](https://github.com/mattdesl/promise-cookbook)
A brief introduction to using Promises in JavaScript.

![](/images/2015-12-11/1447180285dg-20.png) 


## Honorable Mentions…

* [An alt Decision Tree](http://www.w3.org/WAI/tutorials/images/decision-tree/)
* [Google Ranking Factors](https://northcutt.com/wr/google-ranking-factors/)
* [w3viewer](http://www.simevidas.com/specs/)
* [Checklist / collection of SEO tips](https://github.com/marcobiedermann/search-engine-optimization)
* [Pragmatic Standards: JavaScript Coding Standards and Best Practices](https://github.com/stevekwan/best-practices/blob/master/javascript/best-practices.md)

## Suggest Yours

Here are the previous posts in this series:

* [20 Docs and Guides for Front-end Developers (No. 1)](http://www.sitepoint.com/20-docs-guides-front-end-developers/)
* [20 Docs and Guides for Front-end Developers (No. 2)](http://www.sitepoint.com/20-more-docs-guides-front-end-developers/)
* [20 Docs and Guides for Front-end Developers (No. 3)](http://www.sitepoint.com/another-20-docs-guides-front-end-developers/)
* [20 Docs and Guides for Front-end Developers (No. 4)](http://www.sitepoint.com/20-docs-guides-front-end-developers-4/)
* [20 Docs and Guides for Front-end Developers (No. 5)](http://www.sitepoint.com/20-docs-guides-front-end-developers-5/)

If you’ve built or know of another learning resource for front-end developers, drop it in the comments and I’ll consider it for a future post.