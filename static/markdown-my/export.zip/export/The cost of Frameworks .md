# The cost of Frameworks 

## THE BENEFITS OF FRAMEWORKS

Earlier in the year I wrote about [React’s performance characteristics](https://aerotwist.com/blog/react-plus-performance-equals-what/) as the tree size it has to manage gets larger (TL;DR the bigger the tree, the more computation work it has to do). The responses I got to that post really varied, from appreciative and constructive to, well, the other end of the spectrum. The responses gave me some additional insight, though, which I think applies to all frameworks (to a greater or lesser extent), and which I’ll now try and summarize:

* Frameworks are fun to use. I don’t think I know any developer who actively seeks out a more challenging and less fun experience! And yes, absolutely, ergonomics are important.
* Frameworks make it quicker to build an MVP. This one is important, particularly for smaller, fledgling organizations or companies. Having a fast bootstrap may be the difference between shipping and not shipping.
* Frameworks work around lumps / bugs in the platform. I think this is less of an issue these days (though not irrelevant) as browsers have rallied around standards very well in the past few years. Certainly this is less painful compared to my early career, where we were dealing with IEs 5 and 6, and early versions of Firefox, Safari and, of course, Chrome.
* Knowing [insert framework] means I get paid. If you’re looking to get hired, saying that you know the latest and greatest framework(s) may be the difference maker.


The key message I heard over and over, sometimes explicitly, and often implicitly, is that ergonomics are the most important factor for many developers. If I can paraphrase, the sentiment was “if I have an easier time I’ll build something better for my users”. At face value that sounds appealing, but I think it misses a lot of important points.


## DEVELOPER ERGONOMICS VS USER NEEDS
Users have needs, too, though. Here are a few of them that come to mind:

Sites and apps should load quickly.

* They should have smooth interactions.
* They shouldn’t slow down my phone.
* They shouldn’t crash.
* They should have features I want.

So immediately we’re into a potential trade-off situation: on the one hand we have our convenience, our ergonomics, and on the other hand we have our users’ needs. And we have to trade, whether we like it or not, since frameworks aren’t free.

## A QUICK SIDE STEP

At this point I’m going to park libraries, and leave them out of this discussion. The reason is that, in my view at least, libraries can be swapped out and replaced if they prove problematic. Don’t like the way a library does date formatting? No problem, just switch it for something else. Frameworks, on the other hand, tend to be a lot more difficult to swap, often requiring a rebuild of the app in question. And, by their nature, they’re a lot bigger and more involved.

## THE COST OF CODE

All code has costs, but I think there are particular costs that are unique to frameworks.

![](images/2015-12-08/deprecated.jpg)

 *That magical moment where an framework tells you something is deprecated. Apparently it was superseded by Java. Weird.*
 
* **Learning it** . You have to take time out to learn any new framework: what it means to write “idiomatic” code for that framework; its patterns, practices, and ways of doing things. This is no different to the web platform itself. There’s no free ride, you’re just swapping one set of issues for another.
*  **Re-learning it** . One day you’re just bimbling along, developing your app, and in the console you see a warning telling you that there’s been a deprecation, and that you need to update your code. That often requires figuring out what the latest version of the framework needs you to do differently, and that may also mean updating projects that shipped with older versions of the framework.
*  **Debugging it** . Frameworks, like any software, have bugs. That’s to be expected, and it wouldn’t be any different if you went vanilla and wrote your own. Debugging a framework, however, often ranges from difficult to impossible. If you find the issue, you may have to keep your own frankensteined version around with a monkey patch applied until the real fix lands in the framework’s production build.

Aside from the developer costs, there are costs to the user, too:

*  **Time** . How long does it take to bootstrap the thing we sent down the wire?
*  **Bandwidth** . How much bandwidth does it use up?
*  **CPU usage (battery)** . How CPU intensive is it? CPU utilization is going to correlate to battery usage: burn the CPU and the battery will get drained.
*  **Frame rate** . How well does the code update the screen? (We know that [users like smooth interactions](https://paul.kinlan.me/what-news-readers-want/).)
*  **Memory usage** . How much memory does it use? Will it cause other apps to be evicted from memory? Perhaps even crash a tab?

## BRINGING DATA TO THE TABLE

So with all that in mind, I wanted to start off a conversation about measuring some of those costs, and my hope is that together we can build up more of a picture about the trade-offs we choose to make.

I decided to take a look at the bootstrapping time for frameworks on mobile. The theory being that, given a like-for-like app, one should be able to see how long it takes each framework to boot. I opted to use TodoMVC for the test, because in my view it’s an MVP web app, and from a user’s point of view, each variant is functionally identical.