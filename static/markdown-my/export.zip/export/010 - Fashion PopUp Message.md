# 010 - Fashion PopUp Message


```
<div class="background"></div>
<div class="wrapper">
    <div class="container">
        <header><h1>Melange</h1></header>
        <section>
            <div class="overlay">
                <h2>Uh oh.</h2>
                <p>
                    We are unable to process that purchase request. <br />Please check if you have enough funds on your <br />credit card and try again.
                </p>
            </div>
            <img src="http://s30.postimg.org/w6o0f9sht/image.png" class="bg rotate" alt="" />
            <a href="javascript:;" class="btn">go back</a>
        </section>
    </div>
</div>
```

```
@import 'compass/css3';
@import url(https://fonts.googleapis.com/css?family=Josefin+Sans:400,700);
@import url(https://fonts.googleapis.com/css?family=Prata);
@mixin placeholder {
    &::-webkit-input-placeholder {
        @content;
    }
    &:-moz-placeholder {
        @content;
    }
    &::-moz-placeholder {
        @content;
    }
    &:-ms-input-placeholder {
        @content;
    }
}
* {
    @include box-sizing(border-box);
}
$josefin: 'Josefin Sans', sans-serif;
$prata: 'Prata', serif;
$white: #fff;
$dark: #1a1a1a;
$bg: #ffcdd2;
$wrapper: 500px;
body {
    overflow: hidden;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-rendering: optimizeLegibility;
}
.background {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    background-color: $bg;
    &:after {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        content: '';
        opacity: .1;
        background-image: url('http://s12.postimg.org/cd5xydly5/011.jpg');
        background-position: center bottom;
        background-size: 100% auto;
        //z-index: -1;
    }
}
.wrapper {
    position: absolute;
    z-index: 999;
    left: 50%;
    width: $wrapper;
    margin-top: 35px;
    margin-left: - $wrapper /2;
    @include border-radius(5px);
}
header {
    h1 {
        font-family: $josefin;
        font-size: 36px;
        font-weight: 700;
        margin-bottom: 19px;
        text-align: center;
        text-transform: lowercase;
        color: $white;
    }
}
section {
    position: relative;
    width: 100%;
    height: 300px;
    .bg {
        position: absolute;
        z-index: -1;
        top: 0;
        right: -15px;
        @include animation(blureIn 1s cubic-bezier(.37, .82, .2, 1));
    }
    h2 {
        font-family: $prata;
        font-size: 48px;
        margin-bottom: 24px;
        color: $dark;
    }
    p {
        font-family: $josefin;
        line-height: 24px;
    }
    .btn {
        font-family: $josefin;
        font-size: 12px;
        font-weight: 700;
        line-height: 45px;
        position: absolute;
        bottom: -122px;
        left: 50%;
        width: 170px;
        height: 42px;
        margin-left: -85px;
        text-align: center;
        text-decoration: none;
        letter-spacing: 2px;
        text-transform: uppercase;
        color: $dark;
        background-color: white;
    }
    .overlay {
        position: absolute;
        top: 38%;
        left: 6px;
        @include animation(slideIn 2s cubic-bezier(.37, .82, .2, 1));
    }
}
@keyframes blureIn {
    0% {
        right: -2000px;
        @include opacity(0);
        @include filter(blur(15px));
    }
    100% {
        right: -15px;
        @include opacity(1);
        @include filter(blur(0px));
    }
}
@-webkit-keyframes blureIn {
    0% {
        right: -2000px;
        @include opacity(0);
        @include filter(blur(15px));
    }
    100% {
        right: -15px;
        @include opacity(1);
        @include filter(blur(0px));
    }
}
@keyframes slideIn {
    0% {
        z-index: -1;
        top: 38%;
        left: 6px;
        @include opacity(0);
    }
    50% {
        z-index: -1;
        top: 38%;
        left: 6px;
        @include opacity(0);
    }
    75% {
        z-index: -1;
        top: -10%;
        left: 6px;
    }
    100% {
        z-index: 1;
        top: 38%;
        left: 6px;
    }
}
@-webkit-keyframes slideIn {
    0% {
        z-index: -1;
        top: 38%;
        left: 6px;
        @include opacity(0);
    }
    50% {
        z-index: -1;
        top: 38%;
        left: 6px;
        @include opacity(0);
    }
    75% {
        z-index: -1;
        top: -10%;
        left: 6px;
    }
    100% {
        z-index: 1;
        top: 38%;
        left: 6px;
    }
}
```