# Function - Javascript

## Properties

- **Function.arguments**

 An array corresponding to the arguments passed to a function. This is deprecated as property of Function, use the arguments object available within the function instead.

- **Function.arity**

 Used to specifiy the number of arguments expected by the function, but has been removed. Use the length property instead.

- **Function.caller**

 Specifies the function that invoked the currently executing function.

- **Function.length**

 Specifies the number of arguments expected by the function.

- **Function.name**

 The name of the function.

- **Function.displayName**

 The display name of the function.

- **Function.prototype.constructor**

 Specifies the function that creates an object's prototype. See Object.prototype.constructor for more details.

## Methods

- **Function.prototype.apply()**

 Applies the method of another object in the context of a different object (the calling object); arguments can be passed as an Array object.

- **Function.prototype.bind()**

 Creates a new function which, when called, itself calls this function in the context of the provided value, with a given sequence of arguments preceding any provided when the new function was called.

- **Function.prototype.call()**

 Calls (executes) a method of another object in the context of a different object (the calling object); arguments can be passed as they are.

- **Function.prototype.isGenerator()**

 Returns true if the function is a generator; otherwise returns false.

- **Function.prototype.toSource()**

 Returns a string representing the source code of the function. Overrides the Object.prototype.toSource method.

- **Function.prototype.toString()**

 Returns a string representing the source code of the function. Overrides the Object.prototype.toString method.