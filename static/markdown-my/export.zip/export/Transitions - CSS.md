# Transitions - CSS

<table responsive="true">
<tbody><tr><th>Property</th><th>Description</th></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772284(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">transition</strong></a>
</p>
</td><td data-th="Description">
<p>Gets or sets one or more shorthand values  that specify the transition properties  for a set of corresponding object properties  identified in the <a href="https://msdn.microsoft.com/en-us/library/hh772287(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">transition-property</strong></a> property.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772285(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">transition-delay</strong></a>
</p>
</td><td data-th="Description">
<p>Gets or sets one or more values  that specify the offset within a transition (the amount of time from the start of a transition) before  the transition  is displayed  for a set of corresponding object properties  identified in the <a href="https://msdn.microsoft.com/en-us/library/hh772287(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">transition</strong></a> property.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772286(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">transition-duration</strong></a>
</p>
</td><td data-th="Description">
<p>Gets or sets one or more values  that specify the durations of transitions on a set of corresponding object properties  identified in the <a href="https://msdn.microsoft.com/en-us/library/hh772287(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">transition-property</strong></a> property.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772287(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">transition-property</strong></a>
</p>
</td><td data-th="Description">
<p>Gets or sets a value  that identifies the CSS property name or names to which the transition effect (defined by the <a href="https://msdn.microsoft.com/en-us/library/hh772286(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">transition-duration</strong></a>, <a href="https://msdn.microsoft.com/en-us/library/hh772288(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">transition-timing-function</strong></a>, and <a href="https://msdn.microsoft.com/en-us/library/hh772285(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">transition-delay</strong></a> properties) is applied when a new property value is specified. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772288(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">transition-timing-function</strong></a>
</p>
</td><td data-th="Description">
<p>Gets or sets one or more values  that specify the intermediate property values to be used during a transition on a set of corresponding object properties  identified in the <a href="https://msdn.microsoft.com/en-us/library/hh772287(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">transition-property</strong></a> property.</p>
</td></tr>
</tbody></table>


##  **transition-timing-function**  property

Gets or sets one or more values that specify the intermediate property values to be used during a transition on a set of corresponding object properties identified in the transition-property property.

This property is read/write.

### Syntax

 **transition-timing-function** : cubic-bezier | ease | linear | ease-in | ease-out | ease-in-out | steps | step-start | step-end [ , cubic-bezier | ease | linear | ease-in | ease-out | ease-in-out | steps | step-start | step-end ] *
 
### Property values

One or more animation timing functions, separated by commas.

-  **cubic-bezier** 

 A timing function, based on a cubic Bézier curve, that takes four parameters. The four values specify the x- and y-coordinates as (x₁, y₁, x₂, y₂) of the P₁ and P₂ points of the curve, respectively.

  **Note**   For properties other than opacity and color, the cubic-bezier curve function accepts y-coordinates outside the standard range of [0, 1]. This allows the ability to specify "elastic" effects for properties such as length and width, as shown in the following image.

 ![](images/css/IC536351.png)
 
-  **ease** 

 Default. A timing function, based on a cubic Bézier curve, that gradually increases in speed at the start, animates at full speed, and then gradually decreases in speed at the end. This function is equivalent to "cubic-bezier(0.25,0.1,0.25,1)".

 ![](images/css/IC536352.png)
-  **linear** 

 A timing function, based on a cubic Bézier curve, that has a consistent speed from start to end. This function is equivalent to "cubic-bezier(0,0,1,1)".

 ![](images/css/IC536353.png)

-  **ease-in** 

 A timing function, based on a cubic Bézier curve, that gradually increases in speed at the start. This function is equivalent to "cubic-bezier(0.42,0,1,1)".

 ![](images/css/IC536354.png)

-  **ease-out** 

 A timing function, based on a cubic Bézier curve, that gradually decreases in speed at the end. This function is equivalent to "cubic-bezier(0,0,0.58,1)".

 ![](images/css/IC536355.png)

-  **ease-in-out** 

 A timing function, based on a cubic Bézier curve, that gradually increases in speed at the start and then gradually decreases in speed at the end. This function is equivalent to "cubic-bezier(0.42,0,0.58,1)".

 ![](images/css/IC536356.png)

-  **steps** 

 A stepped timing function that takes two parameters. The first parameter specifies the number of intervals; the optional second parameter specifies the point in the interval where the property value changes. The second parameter is constrained to the values "start" or "end", which is the default.

-  **step-start** 

 A stepped timing function that is equivalent to "steps(1, start)".

-  **step-end** 

 A stepped timing function that is equivalent to "steps(1, end)".