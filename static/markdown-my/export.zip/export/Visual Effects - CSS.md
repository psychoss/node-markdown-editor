# Visual Effects - CSS

<table responsive="true">
<tbody><tr><th>Property</th><th>Description</th></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530748(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">clip</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies which part of a positioned object is visible. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dn858632(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">filter</strong></a>
</p>
</td><td data-th="Description">
<p> Specifies a visual effect on an element using filter functions like grayscale, sepia, blur, etc. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530824(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">overflow</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  a value indicating how to manage the content of the object when the content exceeds the height or width of the object.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531180(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">visibility</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  whether the content of the object is displayed. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dn793580(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-webkit-appearance</strong></a>
</p>
</td><td data-th="Description">
<p>Changes the appearance of an element to resemble native user interface controls.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dn806275(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-webkit-tap-highlight-color</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the highlight color when a user taps a link.</p>
</td></tr>
</tbody></table>