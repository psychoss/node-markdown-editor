# Basic Box Model - CSS


<table responsive="true">
<tbody><tr><th>Property</th><th>Description</th></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530747(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">clear</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  whether the object allows floating objects on its left side, right side, or both, so that the next text displays past the floating objects.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530751(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">display</strong></a>
</p>
</td><td data-th="Description">
<p>Gets or sets a value that indicates  whether and how the object is rendered.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530755(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">float</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  on which side of the object the text will flow.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530765(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">height</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  the height of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530799(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">margin</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  the width of the top, right, bottom, and left margins of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530802(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">margin-bottom</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  the height of the bottom margin of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530804(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">margin-left</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  the width of the left margin of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530806(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">margin-right</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  the width of the right margin of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530808(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">margin-top</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  the height of the top margin of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530809(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">max-height</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves the maximum height for an element.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530811(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">max-width</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves the maximum width for an element.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530815(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">min-height</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the minimum height for an element.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530820(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">min-width</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves the minimum width for an element.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530826(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">overflow-x</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  how to manage the content of the object when the content exceeds the width of the object.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530829(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">overflow-y</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  how to manage the content of the object when the content exceeds the height of the object.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530824(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">overflow</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  a value indicating how to manage the content of the object when the content exceeds the height or width of the object.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530830(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">padding</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves the amount of space to insert between the object and its margin or, if there is a border, between the object and its border. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530832(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">padding-bottom</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  the amount of space to insert between the bottom border of the object and the content. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530835(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">padding-left</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  the amount of space to insert between the left border of the object and the content. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530837(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">padding-right</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  the amount of space to insert between the right border of the object and the content. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530839(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">padding-top</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  the amount of space to insert between the top border of the object and the content. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531180(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">visibility</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  whether the content of the object is displayed. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531183(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">width</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the width of the object. </p>
</td></tr>
</tbody></table>