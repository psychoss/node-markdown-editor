# window.requestAnimationFrame


The Window.requestAnimationFrame() method tells the browser that you wish to perform an animation and requests that the browser call a specified function to update an animation before the next repaint. The method takes as an argument a callback to be invoked before the repaint.
Note: Your callback routine must itself call requestAnimationFrame() if you want to animate another frame at the next repaint.
You should call this method whenever you're ready to update your animation onscreen. This will request that your animation function be called before the browser performs the next repaint. The number of callbacks is usually 60 times per second, but will generally match the display refresh rate in most web browsers as per W3C recommendation. The callback rate may be reduced to a lower rate when running in background tabs or in hidden  `<iframe>` s in order to improve performance and battery life.

The callback method is passed a single argument, a DOMHighResTimeStamp, which indicates the current time when callbacks queued by requestAnimationFrame begin to fire. Multiple callbacks in a single frame, therefore, each receive the same timestamp even though time has passed during the computation of every previous callback's workload. This timestamp is a decimal number, in milliseconds, but with a minimal precision of 1ms (1000 µs).

## Syntax

```
window.requestAnimationFrame(callback);
```
### Parameters

 **callback** 
 
A parameter specifying a function to call when it's time to update your animation for the next repaint. The callback has one single argument, a [DOMHighResTimeStamp](http://devdocs.io/dom/domhighrestimestamp), which indicates the current time (the time returned from [Performance.now()](http://devdocs.io/dom/performance/now) ) for when requestAnimationFrame starts to fire callbacks.
### Return value

A long integer value, the request id, that uniquely identifies the entry in the callback list. This is a non-zero value, but you may not make any other assumptions about its value. You can pass this value to [Window.cancelAnimationFrame()](http://devdocs.io/dom/window/cancelanimationframe) to cancel the refresh callback request.

## Example

```
var start = null;
var element = document.getElementById("SomeElementYouWantToAnimate");

function step(timestamp) {
  if (!start) start = timestamp;
  var progress = timestamp - start;
  element.style.left = Math.min(progress/10, 200) + "px";
  if (progress < 2000) {
    window.requestAnimationFrame(step);
  }
}

window.requestAnimationFrame(step);
```