# Backgrounds and Borders - CSS

<table responsive="true">
<tbody><tr><th>Property</th><th>Description</th></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530722(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">background</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies up to five separate background properties of an object.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530715(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">background-attachment</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies how the background image (or images) is attached to the object within the document.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127314(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">background-clip</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the background painting area or areas relative to the element's bounding boxes.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530716(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">background-color</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the color behind the content of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530717(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">background-image</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the background image or images of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127315(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">background-origin</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the positioning area of an element or multiple elements.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530718(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">background-position</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the position of the background of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530721(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">background-repeat</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  whether and how the background image (or images) is tiled.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127316(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">background-size</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the size of the background images.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530744(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the properties of a border drawn around an object.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530724(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-bottom</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the properties of the bottom border of the object.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530725(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-bottom-color</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the foreground color of the bottom border of an object.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127317(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-bottom-left-radius</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the radii of the quarter ellipse that defines the shape of the lower-left corner for the outer border edge of the current box.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127318(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-bottom-right-radius</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves one or two values that define the radii of the quarter ellipse that defines the shape of the lower-right corner for the outer border edge of the current box.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530726(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-bottom-style</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the style of the bottom border of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530727(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-bottom-width</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the thickness of the bottom border of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530728(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-collapse</strong></a>
</p>
</td><td data-th="Description">
<p>Indicates whether the row and cell borders of a table are joined in a single border or detached as in standard HTML.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530729(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-color</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the border color of the object.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dn336997(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-image</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies how an image is to be used in place of the border styles.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dn336998(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-image-outset</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the amount by which the border image area  extends beyond the border box.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dn337001(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-image-repeat</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies if the sides of the border image are scaled or tiled. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dn337002(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-image-slice</strong></a>
</p>
</td><td data-th="Description">
<p>Using four inward offsets, this property slices the specified border image into a three by three grid: four corners, four edges, and a center.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dn337003(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-image-source</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the location of the image to be used for the border.
</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dn337004(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-image-width</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the width/height of the border image by defining inward offsets from the edges of the border image area.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530730(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-left</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the properties of the left border of the object.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530731(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-left-color</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the foreground color of the left border of an object.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530732(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-left-style</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  the style of the left border of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530733(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-left-width</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the thickness of the left border of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127319(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-radius</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the radii of a quarter ellipse that defines the shape of the corners for the outer border edge of the current box.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530734(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-right</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the properties of the right border of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530735(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-right-color</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the foreground color of the right border of an object.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530736(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-right-style</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the style of the right border of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530737(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-right-width</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the thickness of the right border of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/cc304069(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-spacing</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies 
			the distance between the borders of adjoining cells in a table.
  </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530738(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-style</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the style of the left, right, top, and bottom borders of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530739(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-top</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the properties of the top border of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530740(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-top-color</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the foreground color of the top border of an object.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127320(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-top-left-radius</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves one or two values that define the radii of the quarter ellipse that defines the shape of the upper-left corner for the outer border edge of the current box.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127321(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-top-right-radius</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves one or two values that define the radii of the quarter ellipse that defines the shape of the upper-right corner for the outer border edge of the current box.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530741(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-top-style</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the style of the top border of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530742(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-top-width</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the thickness of the top border of the object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530743(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-width</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies  the thicknesses of the left, right, top, and bottom borders of an object. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127322(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">box-shadow</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies one or more set of shadow values that attaches one or more drop shadows to the current box.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530719(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">background-position-x</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the <em>x</em>-coordinate of the <a href="https://msdn.microsoft.com/en-us/library/ms530718(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">background-position</strong></a> property. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530720(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">background-position-y</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the <em>y</em>-coordinate of the <a href="https://msdn.microsoft.com/en-us/library/ms530718(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">background-position</strong></a> property. </p>
</td></tr>
</tbody></table>