# Go REST API Server Shows Poor JSON Performance (in JSON + memcached) 

>mysql library of Go needs to be improvement

? This benchmark needs to be improvement

- 1) This claim, unless I misread (highly likely) is unfounded. Looking at the benchmark, it's clear that the following 3 tests have the same timings: Go + msgpack + memcached, Go + json + memcached, Go + json + mysql. IMHO, the only conclusion that be drawn from this is that the entire benchmark is flawed. Especially given the small times(milliseconds), which might very well be dominated by constant overheads.
also.

- 2) These contenders don't do the same thing. One uses a prepared statement, the other concats strings to make the sql:

        .pl:
        "select name,mail from user where id = ?"`
        .go:
        "SELECT name,mail FROM user WHERE id=%d" 
    
- 3) The code is buggy. The following copy-pasta work together to yield a data race
- 
        id++
        if id > 10000 {
            id = 0
        }
- 4) The Go handlers don't do the same thing. One uses strconv.Itoa(), the other uses fmt.

        BenchmarkItoa        10000000    217 ns/op
        BenchmarkSprintf    5000000      765 ns/op

Go's json/encoding does perform poorly compared to Oj (C + ruby). 18s vs 6s for encoding a small map 10 million times. Most of the time is spent in runtime.mallocgc
Gist with source, running time and profiling results: https://gist.github.com/tuxychandru/7053961


Not that such a benchmark proves anything at all... but observe what happens when you start to make things more realistic by simply changing that map of interface{} to a struct. I think everyone know that the json pkg could be optimized some more. But let's not get carried way with flawed benchmarks


I've found Go's JSON performance to be the bottleneck in a couple of my applications now, which was somewhat disappointing, however it was still plenty fast.