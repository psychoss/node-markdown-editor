# MSCSSMatrix object - CSS

<table id="memberListMethods" class="members" responsive="true">
<tbody><tr><th>Method</th><th>Description</th></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/hh772397(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">inverse</strong></a>
</td><td data-th="Description">
<p>Returns a new matrix that is the inverse of the current matrix.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/hh772422(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">multiply</strong></a>
</td><td data-th="Description">
<p>Returns a new matrix that is the result of current matrix multiplied by the input matrix.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/hh772424(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">multiplyLeft</strong></a>
</td><td data-th="Description">
<p>Returns a new matrix that is the result of input matrix multiplied by the current matrix.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/hh772429(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">rotate</strong></a>
</td><td data-th="Description">
<p>Returns a new matrix that is the result of the current matrix multiplied by the rotation matrix corresponding to the input parameters.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/hh772434(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">rotateAxisAngle</strong></a>
</td><td data-th="Description">
<p>Returns a new matrix that is the result of the current matrix multiplied by the rotation matrix with the given axis and angle.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/hh772441(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scale</strong></a>
</td><td data-th="Description">
<p>Returns a new matrix that is the result of the current matrix multiplied by the scale matrix that corresponds to the input parameters.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/hh772445(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">setMatrixValue</strong></a>
</td><td data-th="Description">
<p>Replaces an existing matrix with the computed matrix that corresponds to the input.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/hh772448(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">skew</strong></a>
</td><td data-th="Description">
<p>Returns a new matrix that is the result of the current matrix multiplied by the skew matrix that corresponds to the input parameters.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/jj127334(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">skewX</strong></a>
</td><td data-th="Description">
<p> Specifies a 2-D skew transformation along the <em>x</em>-axis by the given angle.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/jj127335(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">skewY</strong></a>
</td><td data-th="Description">
<p>Specifies a 2-D skew transformation along the <em>y</em>-axis by the given angle.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/hh772451(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">toString</strong></a>
</td><td data-th="Description">
<p>Returns a string that corresponds to the matrix.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/hh772453(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">translate</strong></a>
</td><td data-th="Description">
<p>Returns a new matrix that is the result of the current matrix multiplied by a translation matrix that contains the input parameters.</p>
</td></tr>
</tbody></table>


<table id="memberListProperties" class="members" responsive="true">
<tbody><tr><th>Property</th><th>Access type</th><th>Description</th></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772391(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">a</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read/write</td><td data-th="Description">
<p>Gets or sets the same value as the <a href="https://msdn.microsoft.com/en-us/library/hh772399(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">m11</strong></a> property.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772392(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">b</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read/write</td><td data-th="Description">
<p>Gets or sets the same value as the <a href="https://msdn.microsoft.com/en-us/library/hh772407(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">m21</strong></a> property.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772393(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">c</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read/write</td><td data-th="Description">
<p>Gets or sets the same value as the <a href="https://msdn.microsoft.com/en-us/library/hh772400(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">m12</strong></a> property.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772394(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">d</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read/write</td><td data-th="Description">
<p>Gets or sets the same value as the <a href="https://msdn.microsoft.com/en-us/library/hh772409(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">m22</strong></a> property.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772395(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">e</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read/write</td><td data-th="Description">
<p>Gets or sets the same value as the <a href="https://msdn.microsoft.com/en-us/library/hh772403(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">m13</strong></a> property.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772396(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">f</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read/write</td><td data-th="Description">
<p>Gets or sets the same value as the <a href="https://msdn.microsoft.com/en-us/library/hh772410(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">m23</strong></a> property.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772399(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">m11</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read/write</td><td data-th="Description">
<p>Gets or sets the value in the first column of the first row of the 4×4 matrix.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772400(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">m12</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read/write</td><td data-th="Description">
<p>Gets or sets the value in the second column of the first row of the 4×4 matrix.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772403(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">m13</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read/write</td><td data-th="Description">
<p>Gets or sets the value in the third column of the first row of the 4×4 matrix.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772405(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">m14</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read/write</td><td data-th="Description">
<p>Gets or sets the value in the fourth column of the first row of the 4×4 matrix.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772407(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">m21</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read/write</td><td data-th="Description">
<p>Gets or sets the value in the first column of the second row of the 4×4 matrix.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772409(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">m22</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read/write</td><td data-th="Description">
<p>Gets or sets the value in the second column of the second row of the 4×4 matrix.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772410(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">m23</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read/write</td><td data-th="Description">
<p>Gets or sets the value in the third column of the second row of the 4×4 matrix.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772411(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">m24</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read/write</td><td data-th="Description">
<p>Gets or sets the value in the fourth column of the second row of the 4×4 matrix.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772412(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">m31</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read/write</td><td data-th="Description">
<p>Gets or sets the value in the first column of the third row of the 4×4 matrix.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772413(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">m32</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read/write</td><td data-th="Description">
<p>Gets or sets the value in the second column of the third row of the 4×4 matrix.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772414(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">m33</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read/write</td><td data-th="Description">
<p>Gets or sets the value in the third column of the third row of the 4×4 matrix.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772415(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">m34</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read/write</td><td data-th="Description">
<p>Gets or sets the value in the fourth column of the third row of the 4×4 matrix.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772416(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">m41</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read/write</td><td data-th="Description">
<p>Gets or sets the value in the first column of the fourth row of the 4×4 matrix.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772417(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">m42</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read/write</td><td data-th="Description">
<p>Gets or sets the value in the second column of the fourth row of the 4×4 matrix.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772419(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">m43</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read/write</td><td data-th="Description">
<p>Gets or sets the value in the third column of the fourth row of the 4×4 matrix.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772420(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">m44</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read/write</td><td data-th="Description">
<p>Gets or sets the value in the fourth column of the fourth row of the 4×4 matrix.</p>
</td></tr>
</tbody></table>