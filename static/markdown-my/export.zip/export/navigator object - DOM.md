# navigator object - DOM

## Methods

<table id="memberListMethods" class="members" responsive="true">
<tbody><tr><th>Method</th><th>Description</th></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/dn254977(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">confirmSiteSpecificTrackingException</strong></a>
</td><td data-th="Description">
<p>Indicates whether an exception exists for a given domain.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/dn254978(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">confirmWebWideTrackingException</strong></a>
</td><td data-th="Description">
<p>Indicates whether an exception exists for services from a given domain.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/dn743639(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">getGamepads</strong></a>
</td><td data-th="Description">
<p>Returns an array of <a href="https://msdn.microsoft.com/en-us/library/dn743624(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">gamepad</strong></a> objects that describe the state of each active gamepad device.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536610(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">javaEnabled</strong></a>
</td><td data-th="Description">
<p>Returns whether Java is enabled.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/jj154912(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msLaunchUri</strong></a>
</td><td data-th="Description">
<p>This method is used to start a service or app, such as an email client, that handles a given protocol.  The URI contains the  protocol for the default service or app, such as <strong>mailto:</strong>//john@contoso.com. </p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/hh772331(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msSaveBlob</strong></a>
</td><td data-th="Description">
<p>Saves the <a href="https://msdn.microsoft.com/en-us/library/hh772305(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">File</strong></a> or <a href="https://msdn.microsoft.com/en-us/library/hh772298(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">Blob</strong></a> to disk.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/hh772332(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msSaveOrOpenBlob</strong></a>
</td><td data-th="Description">
<p>Launches the associated application for a <a href="https://msdn.microsoft.com/en-us/library/hh772305(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">File</strong></a> or <a href="https://msdn.microsoft.com/en-us/library/hh772298(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">Blob</strong></a>.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/dn254979(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">removeSiteSpecificTrackingException</strong></a>
</td><td data-th="Description">
<p>Removes a previously-granted tracking exception for a domain.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/dn254980(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">removeWebWideTrackingException</strong></a>
</td><td data-th="Description">
<p>Removes a previously-granted tracking exception for a service host.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/mt573145(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">requestMediaKeySystemAccess</strong></a>
</td><td data-th="Description">
<p>Requests access to the specified <a href="http://go.microsoft.com/fwlink/p/?LinkId=624108">Key System</a>.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/dn254981(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">storeSiteSpecificTrackingException</strong></a>
</td><td data-th="Description">
<p>Requests an exemption to the "Do not Track" (DNT)  rule for a given website.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/dn254982(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">storeWebWideTrackingException</strong></a>
</td><td data-th="Description">
<p>Requests an exemption to the "Do not Track" (DNT)  rule for services used by other websites.</p>
</td></tr>
<tr data="declared;"><td data-th="Method">
<a href="https://msdn.microsoft.com/en-us/library/ms536778(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">taintEnabled</strong></a>
</td><td data-th="Description">
<p>Returns whether data tainting is enabled. </p>
</td></tr>
</tbody></table>

## Properties

<table id="memberListProperties" class="members" responsive="true">
<tbody><tr><th>Property</th><th>Access type</th><th>Description</th></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533077(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">appCodeName</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves the code name.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533078(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">appMinorVersion</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves the application's minor version value. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533079(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">appName</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves the name of the client. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533080(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">appVersion</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves the platform and version of the application. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533542(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">browserLanguage</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves the current operating system language. </p>
<div class="alert"><strong>Note</strong>&nbsp;&nbsp;This property does not indicate the language or languages set by the user in Language Preferences, located in the <strong>Internet Options</strong> dialog box.</div>
<div>&nbsp;</div>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533694(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">cookieEnabled</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves whether client-side persistent cookies are enabled.  Persistent cookies are those that are stored on the client-side computer.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms533697(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">cpuClass</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves a string denoting the CPU class. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/gg699483(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">doNotTrack</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Returns a <strong>String</strong> indicating whether the  user set a preference not to be tracked .</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/gg593001(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">geolocation</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Gets a reference to 
       a <a href="https://msdn.microsoft.com/en-us/library/gg593041(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">geolocation</strong></a> object, 
       which reports the geographic location of the device running the application.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh772144(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">maxTouchPoints</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read-only</td><td data-th="Description">
<p>The maximum number of simultaneous touch contacts supported by the device.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh972894(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">msManipulationViewsEnabled</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read-only</td><td data-th="Description">
<p>Returns whether manipulation feature support is available, such as  <a href="https://msdn.microsoft.com/en-us/library/hh673536(v=vs.85).aspx">touch panning and zooming</a> using CSS rules. </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534307(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">onLine</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>
		Retrieves a value indicating whether the system is online.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534340(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">platform</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves the name of the user's operating system.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/dn384065(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">plugins</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Provides information about registered plug-ins.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/hh972895(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">pointerEnabled</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read-only</td><td data-th="Description">
<p>Deprecated. Indicates if  pointer events are fired  for pointing input.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/dn508363(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">product</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type">Read-only</td><td data-th="Description">
<p>Returns the <a href="https://msdn.microsoft.com/en-us/library/ms537503(v=vs.85).aspx">product token</a> associated with a user-agent.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534653(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">systemLanguage</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves the default language used by the operating system. 
		   </p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534712(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">userAgent</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves a string equivalent to the HTTP user-agent request header.</p>
</td></tr>
<tr data="declared;"><td data-th="Property">
                                      <p>
                                        <a href="https://msdn.microsoft.com/en-us/library/ms534713(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">userLanguage</strong></a>
                                        
                                      </p>
                                  </td><td data-th="Access type"></td><td data-th="Description">
<p>Retrieves the operating system's natural language setting.   </p>
</td></tr>
</tbody></table>