# PostgreSQL


### 创建数据库

    /usr/lib/postgresql/9.4/bin/createdb mydb
    
### 访问数据库

    psql mydb