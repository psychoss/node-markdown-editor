# CSS Blend Modes - Code Snippets


```

<h1>CSS Blend Modes</h1>
<p>Pick page color, background layer color, and foreground layer color to see the different effects. Works best in current version of Chrome. <br> Learn more about blend modes by <a href="http://webdesign.tutsplus.com/tutorials/blending-modes-in-css-color-theory-and-practical-application--cms-25201">checking out the tutorial on Envato Tuts+</a>.</p>
<div class='color-pickers'>
  <div>
    <p>Background color:</p>
    <input name='bg' type='color' value='#f95858'>
  </div>
  <div>
    <p>Foreground color:</p>
    <input name='fg' type='color' value='#5d7dba'>
  </div>
  <div>
    <p>Page color:</p>
    <input name='pbg' type='color' value='#eaeaea'>
  </div>
</div>
<input class='text-input' name='backgroundImage' placeholder='Enter background image url'>
<div class='circles'>
  <div class='mode-comparison mode-comparison--multiply'>
    <h2>Multiply</h2>
    <div class='bg'></div>
    <div class='fg'></div>
  </div>
  <div class='mode-comparison mode-comparison--screen'>
    <h2>Screen</h2>
    <div class='bg'></div>
    <div class='fg'></div>
  </div>
  <div class='mode-comparison mode-comparison--overlay'>
    <h2>Overlay</h2>
    <div class='bg'></div>
    <div class='fg'></div>
  </div>
  <div class='mode-comparison mode-comparison--darken'>
    <h2>Darken</h2>
    <div class='bg'></div>
    <div class='fg'></div>
  </div>
  <div class='mode-comparison mode-comparison--lighten'>
    <h2>Lighten</h2>
    <div class='bg'></div>
    <div class='fg'></div>
  </div>
  <div class='mode-comparison mode-comparison--color-dodge'>
    <h2>Color-dodge</h2>
    <div class='bg'></div>
    <div class='fg'></div>
  </div>
  <div class='mode-comparison mode-comparison--color-burn'>
    <h2>Color-burn</h2>
    <div class='bg'></div>
    <div class='fg'></div>
  </div>
  <div class='mode-comparison mode-comparison--hard-light'>
    <h2>Hard-light</h2>
    <div class='bg'></div>
    <div class='fg'></div>
  </div>
  <div class='mode-comparison mode-comparison--soft-light'>
    <h2>Soft-light</h2>
    <div class='bg'></div>
    <div class='fg'></div>
  </div>
  <div class='mode-comparison mode-comparison--difference'>
    <h2>Difference</h2>
    <div class='bg'></div>
    <div class='fg'></div>
  </div>
  <div class='mode-comparison mode-comparison--exclusion'>
    <h2>Exclusion</h2>
    <div class='bg'></div>
    <div class='fg'></div>
  </div>
  <div class='mode-comparison mode-comparison--hue'>
    <h2>Hue</h2>
    <div class='bg'></div>
    <div class='fg'></div>
  </div>
  <div class='mode-comparison mode-comparison--saturation'>
    <h2>Saturation</h2>
    <div class='bg'></div>
    <div class='fg'></div>
  </div>
  <div class='mode-comparison mode-comparison--color'>
    <h2>Color</h2>
    <div class='bg'></div>
    <div class='fg'></div>
  </div>
  <div class='mode-comparison mode-comparison--luminosity'>
    <h2>Luminosity</h2>
    <div class='bg'></div>
    <div class='fg'></div>
  </div>
</div>

```

```

body {
  background-size: cover;
  background-position: center;
  line-height: 1.8;
  font-family: sans-serif;
  font-weight: 200;
  color: #4b4b4b;
  text-align: center;
  background-color: #eaeaea;
  -webkit-transition: color .2s;
  transition: color .2s;
}
body.dark {
  color: #fafafa;
}
body.middle {
  color: #fafafa;
  text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.3);
}

a {
  color: #136fd2;
}
a:hover {
  text-decoration: none;
}

h2 {
  font-size: 18px;
}

input[type=color] {
  cursor: pointer;
}

.text-input {
  padding: 6px 12px;
  line-height: 2;
  width: 300px;
  text-align: center;
  color: #444;
}

.mode-comparison {
  overflow: auto;
  width: 100%;
  float: left;
  margin: 20px auto;
}
@media only screen and (min-width: 500px) {
  .mode-comparison {
    width: 33.333%;
  }
}
@media only screen and (min-width: 1000px) {
  .mode-comparison {
    width: 25%;
  }
}
@media only screen and (min-width: 1280px) {
  .mode-comparison {
    width: 20%;
  }
}
.mode-comparison--multiply .fg {
  mix-blend-mode: multiply;
}

.mode-comparison {
  overflow: auto;
  width: 100%;
  float: left;
  margin: 20px auto;
}
@media only screen and (min-width: 500px) {
  .mode-comparison {
    width: 33.333%;
  }
}
@media only screen and (min-width: 1000px) {
  .mode-comparison {
    width: 25%;
  }
}
@media only screen and (min-width: 1280px) {
  .mode-comparison {
    width: 20%;
  }
}
.mode-comparison--screen .fg {
  mix-blend-mode: screen;
}

.mode-comparison {
  overflow: auto;
  width: 100%;
  float: left;
  margin: 20px auto;
}
@media only screen and (min-width: 500px) {
  .mode-comparison {
    width: 33.333%;
  }
}
@media only screen and (min-width: 1000px) {
  .mode-comparison {
    width: 25%;
  }
}
@media only screen and (min-width: 1280px) {
  .mode-comparison {
    width: 20%;
  }
}
.mode-comparison--overlay .fg {
  mix-blend-mode: overlay;
}

.mode-comparison {
  overflow: auto;
  width: 100%;
  float: left;
  margin: 20px auto;
}
@media only screen and (min-width: 500px) {
  .mode-comparison {
    width: 33.333%;
  }
}
@media only screen and (min-width: 1000px) {
  .mode-comparison {
    width: 25%;
  }
}
@media only screen and (min-width: 1280px) {
  .mode-comparison {
    width: 20%;
  }
}
.mode-comparison--darken .fg {
  mix-blend-mode: darken;
}

.mode-comparison {
  overflow: auto;
  width: 100%;
  float: left;
  margin: 20px auto;
}
@media only screen and (min-width: 500px) {
  .mode-comparison {
    width: 33.333%;
  }
}
@media only screen and (min-width: 1000px) {
  .mode-comparison {
    width: 25%;
  }
}
@media only screen and (min-width: 1280px) {
  .mode-comparison {
    width: 20%;
  }
}
.mode-comparison--lighten .fg {
  mix-blend-mode: lighten;
}

.mode-comparison {
  overflow: auto;
  width: 100%;
  float: left;
  margin: 20px auto;
}
@media only screen and (min-width: 500px) {
  .mode-comparison {
    width: 33.333%;
  }
}
@media only screen and (min-width: 1000px) {
  .mode-comparison {
    width: 25%;
  }
}
@media only screen and (min-width: 1280px) {
  .mode-comparison {
    width: 20%;
  }
}
.mode-comparison--color-dodge .fg {
  mix-blend-mode: color-dodge;
}

.mode-comparison {
  overflow: auto;
  width: 100%;
  float: left;
  margin: 20px auto;
}
@media only screen and (min-width: 500px) {
  .mode-comparison {
    width: 33.333%;
  }
}
@media only screen and (min-width: 1000px) {
  .mode-comparison {
    width: 25%;
  }
}
@media only screen and (min-width: 1280px) {
  .mode-comparison {
    width: 20%;
  }
}
.mode-comparison--color-burn .fg {
  mix-blend-mode: color-burn;
}

.mode-comparison {
  overflow: auto;
  width: 100%;
  float: left;
  margin: 20px auto;
}
@media only screen and (min-width: 500px) {
  .mode-comparison {
    width: 33.333%;
  }
}
@media only screen and (min-width: 1000px) {
  .mode-comparison {
    width: 25%;
  }
}
@media only screen and (min-width: 1280px) {
  .mode-comparison {
    width: 20%;
  }
}
.mode-comparison--hard-light .fg {
  mix-blend-mode: hard-light;
}

.mode-comparison {
  overflow: auto;
  width: 100%;
  float: left;
  margin: 20px auto;
}
@media only screen and (min-width: 500px) {
  .mode-comparison {
    width: 33.333%;
  }
}
@media only screen and (min-width: 1000px) {
  .mode-comparison {
    width: 25%;
  }
}
@media only screen and (min-width: 1280px) {
  .mode-comparison {
    width: 20%;
  }
}
.mode-comparison--soft-light .fg {
  mix-blend-mode: soft-light;
}

.mode-comparison {
  overflow: auto;
  width: 100%;
  float: left;
  margin: 20px auto;
}
@media only screen and (min-width: 500px) {
  .mode-comparison {
    width: 33.333%;
  }
}
@media only screen and (min-width: 1000px) {
  .mode-comparison {
    width: 25%;
  }
}
@media only screen and (min-width: 1280px) {
  .mode-comparison {
    width: 20%;
  }
}
.mode-comparison--difference .fg {
  mix-blend-mode: difference;
}

.mode-comparison {
  overflow: auto;
  width: 100%;
  float: left;
  margin: 20px auto;
}
@media only screen and (min-width: 500px) {
  .mode-comparison {
    width: 33.333%;
  }
}
@media only screen and (min-width: 1000px) {
  .mode-comparison {
    width: 25%;
  }
}
@media only screen and (min-width: 1280px) {
  .mode-comparison {
    width: 20%;
  }
}
.mode-comparison--exclusion .fg {
  mix-blend-mode: exclusion;
}

.mode-comparison {
  overflow: auto;
  width: 100%;
  float: left;
  margin: 20px auto;
}
@media only screen and (min-width: 500px) {
  .mode-comparison {
    width: 33.333%;
  }
}
@media only screen and (min-width: 1000px) {
  .mode-comparison {
    width: 25%;
  }
}
@media only screen and (min-width: 1280px) {
  .mode-comparison {
    width: 20%;
  }
}
.mode-comparison--hue .fg {
  mix-blend-mode: hue;
}

.mode-comparison {
  overflow: auto;
  width: 100%;
  float: left;
  margin: 20px auto;
}
@media only screen and (min-width: 500px) {
  .mode-comparison {
    width: 33.333%;
  }
}
@media only screen and (min-width: 1000px) {
  .mode-comparison {
    width: 25%;
  }
}
@media only screen and (min-width: 1280px) {
  .mode-comparison {
    width: 20%;
  }
}
.mode-comparison--saturation .fg {
  mix-blend-mode: saturation;
}

.mode-comparison {
  overflow: auto;
  width: 100%;
  float: left;
  margin: 20px auto;
}
@media only screen and (min-width: 500px) {
  .mode-comparison {
    width: 33.333%;
  }
}
@media only screen and (min-width: 1000px) {
  .mode-comparison {
    width: 25%;
  }
}
@media only screen and (min-width: 1280px) {
  .mode-comparison {
    width: 20%;
  }
}
.mode-comparison--color .fg {
  mix-blend-mode: color;
}

.mode-comparison {
  overflow: auto;
  width: 100%;
  float: left;
  margin: 20px auto;
}
@media only screen and (min-width: 500px) {
  .mode-comparison {
    width: 33.333%;
  }
}
@media only screen and (min-width: 1000px) {
  .mode-comparison {
    width: 25%;
  }
}
@media only screen and (min-width: 1280px) {
  .mode-comparison {
    width: 20%;
  }
}
.mode-comparison--luminosity .fg {
  mix-blend-mode: luminosity;
}

.bg {
  position: relative;
  width: 50%;
  padding-bottom: 50%;
  background: #f95858;
  margin: 0 auto;
  left: -15%;
  border-radius: 50%;
}

.fg {
  position: relative;
  width: 50%;
  padding-bottom: 50%;
  right: -15%;
  margin: -50% auto 0;
  border-radius: 50%;
  background: #5d7dba;
}

.color-pickers {
  width: 80%;
  position: relative;
  text-align: center;
  padding: 30px;
  overflow: auto;
  margin: 0 auto;
}
.color-pickers div {
  width: 33%;
  display: block;
  float: left;
}

.circles {
  padding: 20px 0;
  overflow: auto;
}

```

```

$("body").addClass("pbg");
$(".color-pickers").on('change', 'input', function(e){
  var pos = $(this).attr("name");
  $("." + pos).css("background-color", $(this).val());
  if (pos == "pbg"){
    var color = hexToRgb($(this).val());
    var luminance = getLum(color);
    console.log(luminance);
    if (luminance < 255 && luminance > 170){
      $("body").removeClass("dark middle").addClass("light");
    } else if (luminance < 170 && luminance > 85) {
      $("body").removeClass("light dark").addClass("middle");
    } else {
      $("body").removeClass("light middle").addClass("dark");
    }
  }
});


function hexToRgb(hex) {
    var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}

function getLum(color){
  var { r, g, b } = color;
  return (0.2126*r + 0.7152*g + 0.0722*b);
}

$("input[name='backgroundImage']").on('keyup', function(){
  $("body").css("background-image", `url(${$(this).val()})`);
})
VIEW COMPILED
```