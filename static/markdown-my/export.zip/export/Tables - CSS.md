# Tables - CSS

<table responsive="true">
<tbody><tr><th>Property</th><th>Description</th></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530728(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-collapse</strong></a>
</p>
</td><td data-th="Description">
<p>Indicates whether the row and cell borders of a table are joined in a single border or detached as in standard HTML.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/cc304069(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">border-spacing</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies 
			the distance between the borders of adjoining cells in a table.
  </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/cc304060(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">caption-side</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves 
			where the <a href="https://msdn.microsoft.com/en-us/library/ms535213(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">caption</strong></a>
			of a <a href="https://msdn.microsoft.com/en-us/library/ms535901(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">table</strong></a> is located.
  </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/cc848860(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">empty-cells</strong></a>
</p>
</td><td data-th="Description">
<p>Determines whether to show or hide a cell without content.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms531161(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">table-layout</strong></a>
</p>
</td><td data-th="Description">
<p>Sets or retrieves  a string that indicates whether the table layout is fixed.</p>
</td></tr>
</tbody></table>