# Touch: Zooming and Panning - CSS

<table responsive="true">
<tbody><tr><th>Property</th><th>Description</th></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771889(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-content-zoom-chaining</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the zoom behavior that occurs when a user hits the zoom limit during a manipulation.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771891(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-content-zooming</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies whether zooming is enabled.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127330(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-content-zoom-limit</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies values for the <a href="https://msdn.microsoft.com/en-us/library/jj127332(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-content-zoom-limit-min</strong></a> and the <a href="https://msdn.microsoft.com/en-us/library/jj127331(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-content-zoom-limit-max</strong></a> properties.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127331(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-content-zoom-limit-max</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the maximum zoom factor.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127332(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-content-zoom-limit-min</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the minimum zoom factor.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771893(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-content-zoom-snap</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies values for the <a href="https://msdn.microsoft.com/en-us/library/hh771896(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-content-zoom-snap-type</strong></a> and the <a href="https://msdn.microsoft.com/en-us/library/hh771895(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-content-zoom-snap-points</strong></a> properties.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771895(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-content-zoom-snap-points</strong></a>
</p>
</td><td data-th="Description">
<p>Defines where zoom snap-points are located.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771896(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-content-zoom-snap-type</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies how zooming is affected by defined snap-points.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh771902(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-overflow-style</strong></a>
</p>
</td><td data-th="Description">
<p>Gets or sets the scrolling behavior for elements that overflow. </p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772034(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-scroll-chaining</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the scrolling behavior that occurs when a user hits the scroll limit during a manipulation.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127336(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-scroll-limit</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies values for the <a href="https://msdn.microsoft.com/en-us/library/jj127338(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-scroll-limit-x-min</strong></a>, <a href="https://msdn.microsoft.com/en-us/library/jj127340(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-scroll-limit-y-min</strong></a>, <a href="https://msdn.microsoft.com/en-us/library/jj127337(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-scroll-limit-x-max</strong></a>, and <a href="https://msdn.microsoft.com/en-us/library/jj127339(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-scroll-limit-y-max</strong></a> properties.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127337(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-scroll-limit-x-max</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the maximum value for the <a href="https://msdn.microsoft.com/en-us/library/ms534617(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scrollLeft</strong></a> property.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127338(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-scroll-limit-x-min</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the minimum value for the <a href="https://msdn.microsoft.com/en-us/library/ms534617(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scrollLeft</strong></a> property.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127339(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-scroll-limit-y-max</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the maximum value for the <a href="https://msdn.microsoft.com/en-us/library/ms534618(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scrollTop</strong></a> property.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/jj127340(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-scroll-limit-y-min</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies the minimum value for the <a href="https://msdn.microsoft.com/en-us/library/ms534618(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">scrollTop</strong></a> property.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772035(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-scroll-rails</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies whether scrolling locks to the primary axis of motion.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772036(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-scroll-snap-points-x</strong></a>
</p>
</td><td data-th="Description">
<p>Defines  where  snap-points  will  be  located  along  the  <em>x</em>-axis.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772037(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-scroll-snap-points-y</strong></a>
</p>
</td><td data-th="Description">
<p>Defines where snap-points will be located along the <em>y</em>-axis.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772038(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-scroll-snap-type</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies what type of snap-point should be used for the current element.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772039(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-scroll-snap-x</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies values for the <a href="https://msdn.microsoft.com/en-us/library/hh772038(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-scroll-snap-type</strong></a> and <a href="https://msdn.microsoft.com/en-us/library/hh772036(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-scroll-snap-points-x</strong></a> properties.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772040(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-scroll-snap-y</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies values for the <a href="https://msdn.microsoft.com/en-us/library/hh772038(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-scroll-snap-type</strong></a> and <a href="https://msdn.microsoft.com/en-us/library/hh772037(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-scroll-snap-points-y</strong></a> properties.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh973361(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-scroll-translation</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies whether vertical-to-horizontal scroll wheel translation occurs on the specified element.</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772044(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">touch-action</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies whether and how a given region can be manipulated by the user (for instance, by panning or zooming).</p>
</td></tr>
<tr><td data-th="Property">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh975292(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">-ms-touch-select</strong></a>
</p>
</td><td data-th="Description">
<p>Toggles the "gripper" visual elements that enable touch text selection.</p>
</td></tr>
</tbody></table>