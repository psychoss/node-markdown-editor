# At-rules - CSS

<table responsive="true">
<tbody><tr><th>Rule</th><th>Description</th></tr>
<tr><td data-th="Rule">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530746(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">@charset</strong></a>
</p>
</td><td data-th="Description">
<p>Sets the character set for an external style sheet.</p>
</td></tr>
<tr><td data-th="Rule">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530757(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">@font-face</strong></a>
</p>
</td><td data-th="Description">
<p>
      Sets a font to embed in the HTML document.
    </p>
</td></tr>
<tr><td data-th="Rule">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530768(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">@import</strong></a>
</p>
</td><td data-th="Description">
<p>Imports an external style sheet.</p>
</td></tr>
<tr><td data-th="Rule">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530813(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">@media</strong></a>
</p>
</td><td data-th="Description">
<p>
      Sets the media types for a set of rules in a <a href="https://msdn.microsoft.com/en-us/library/ms535871(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">styleSheet</strong></a> object.
    </p>
</td></tr>
<tr><td data-th="Rule">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh772747(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">@keyframes</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies a list of property animation keyframes for an object in the HTML document.</p>
</td></tr>
<tr><td data-th="Rule">
<p>
<a href="https://msdn.microsoft.com/en-us/library/hh869615(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">@-ms-viewport</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies properties that describe the viewport.</p>
</td></tr>
<tr><td data-th="Rule">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ff974080(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">@namespace</strong></a>
</p>
</td><td data-th="Description">
<p>
      Declares an XML namespace (and, optionally, its prefix) and associates it with a string that represents a namespace name.
    </p>
</td></tr>
<tr><td data-th="Rule">
<p>
<a href="https://msdn.microsoft.com/en-us/library/ms530841(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">@page</strong></a>
</p>
</td><td data-th="Description">
<p>
       Sets the dimensions, orientation, and margins of a page box in a <a href="https://msdn.microsoft.com/en-us/library/ms535871(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">styleSheet</strong></a>.
    </p>
</td></tr>
<tr><td data-th="Rule">
<p>
<a href="https://msdn.microsoft.com/en-us/library/dn894031(v=vs.85).aspx"><strong xmlns="http://www.w3.org/1999/xhtml">@supports</strong></a>
</p>
</td><td data-th="Description">
<p>Specifies CSS to be conditioned on browser support of the feature.</p>
</td></tr>
</tbody></table>