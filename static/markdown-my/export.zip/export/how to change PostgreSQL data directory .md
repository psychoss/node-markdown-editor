# how to change PostgreSQL data directory?

I am having a problem changing the data directory on postgresql 9.2 on windows7:

i`m trying to change my data directory:

how can i change data directory on postgreSQL with pgAdmin?

This not possible from within pgAdmin (or any other SQL client because you need to stop the Postgres server in order to move the data directory)

To move the directory, use these steps:

1. Stop Postgres (you can use the control panel to find the correct service name)

        net stop <name_of_the_service>
    
2. Make sure Postgres is not running (e.g. using ProcessMonitor)
3. Remove the Windows service using

        pg_ctl unregister -N <name_of_the_service>
4. make sure Postgres is not running
5. move the data directory to the new location (or maybe only copy it, so that you have a backup)
6. re-create the service using (this assigns postgres as the service name)

        pg_ctl register -N postgres -D c:\new\path\to\datadir
7. start the service

        net start postgres 
8. run psql to verify that Postgres is up and running

        psql -U postgres

9. Verify the running server is using the new data directory

        show data_directory;
Details on how to use pg_ctl can be found in the manual:
<http://www.postgresql.org/docs/current/static/app-pg-ctl.html>